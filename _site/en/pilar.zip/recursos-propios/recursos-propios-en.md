---
layout: default
title: Recursos propios
lang: en
permalink: /recursos-propios/
submenu: recursos-propios
---

# 2. Eligible capital

{% include dropdown.html %}

## 2.1. Characteristics of the eligible capital

Considered for the purpose of calculating the minimum capital requirements, under the solvency regulations, are the elements and instruments corresponding to Tier 1 capital, which is defined as the sum of Common Equity Tier 1 capital (CET1) and additional Tier 1 capital (AT1) as defined in Part Two, Title I, Chapters I to III of the CRR, as well as their corresponding deductions, in accordance with articles 36 and 56, respectively.

Also considered are the elements of Tier 2 capital defined in Part Two of Chapter IV, section I of the CRR, and the deductions to be those defined as such in section II of the same Chapter.

In line with the stipulations of the solvency regulation, the level of Common Equity Tier 1 capital essentially comprises the following elements:

**a) Capital and share premium:** this includes the elements described in article 26 section 1, articles 27, 28 and 29 of the CRR and the EBA list referred to in article 26 section 3 of the CRR.

**b) Accumulated gains:** in accordance with article 26, section 1, letter c), the gains that may be used immediately and with no restriction to hedge any risks or losses are included (mainly reserves, including the reserves of the consolidated companies).

**c) Other accumulated income and other reserves:** the exchange-rate variations, the valuation adjustments associated with the available-for-sale portfolio and the balance of the equity account that contains remuneration based on capital instruments will be classified mainly under this item.

**d) Minority shareholdings:** includes the sum of the Common Equity Tier 1 capital balances of a subsidiary that arise in the process of its global consolidation and are attributable to natural or legal persons other than those included within the scope of prudential consolidation.

**e) Temporary benefits:** the net income referring to the perimeter of credit institutions, deducting the amount corresponding to interim and final dividend payments, is included, as set out in article 26, section 2 of the CRR.

Capital is, moreover, adjusted mainly through the following deductions:

**f) Additional value adjustments:** the adjustments originated by the prudent valuation of the positions at fair value are included, as set out in article 105 of the CRR.

**g) Intangible assets:** these are included net of the corresponding liabilities for taxes, as set out in article 36, section 1, letter b) and article 37 of the CRR.

**h) ADeferred tax assets:** these are assets for deferred taxes that depend on future returns, excluding those deriving from temporary differences (net of the corresponding liabilities for taxes when the conditions established in article 38, section 3 of the CRR are met), as per article 36, section 1, letter c) and article 38 of the CRR.

**i) Expected losses in equity instruments:** the losses arising from the calculation of risk-weighted exposures through the method based on internal ratings are included, as set out in article 36, section 1, letter d) of the CRR.

**j) Profit or losses for liabilities valued at fair value:** those derived from changes in credit quality, in accordance with article 33, letter b) of the CRR (DVA).

**k) Direct and indirect holdings of own instruments (treasury stock):** the shares and other securities booked as own funds that are held by any of the Group's consolidated entities are considered, together with those held by non-consolidated entities belonging to the economic Group, as set out in article 33, section 1, letter f) and article 42 of the CRR.

**l) Securitization:** securitizations that receive a risk weighting of 1.250% are included, as set out in article 36, section 1, letter k), subsection ii) of the CRR.

**m) Temporary adjustments of Common Equity Tier 1 capital:**
this includes unrealized profit and losses valued at fair value, as set out in article 467 and 468 of the CRR.

**n) Qualifying deductions of Common Equity Tier 1 capital:**
this includes the deductions that exceed the additional Tier 1 capital, as described in article 36, section 1, letter b) of the CRR.

The application of some of the above deductions (mainly intangible assets and LCFs) shall be carried out gradually over a transition period of 5 years starting in 2014 (phased in), as set out in the current regulation.

Other deductions that may be applicable could comprise significant stakes in financial institutions and assets for deferred taxes arising from temporary differences that exceed the 10% limit of the CET1, and the deduction for exceeding the overall 17.65% limit of the CET1 according to article 48, section 2 of the CRR.

In addition, the Group includes as total eligible capital the additional Tier 1 capital instruments defined in article 51, 85 and 484 of the CRR, including the corresponding adjustments, in accordance with article 472 of the CRR:

**o) Equity instruments and issue premiums classified as liabilities:** this heading includes the perpetual contingent convertible securities that meet the conditions set out in article 52, section 1 of the CRR.

**p) Elements referred to in article 484, section 4 of the CRR:** this section includes the preferred securities issued by the Group.

**q) Temporary adjustments of additional Tier 1 capital:** this includes the adjustments considered in article 472 of the CRR as measures established for gradual adoption of the new capital ratios.

Finally, the entity also includes additional capital as total eligible Tier 2 capital. Combined with what is indicated in Article 87 of the CRR, it is made up of the following elements:

**r) Subordinated debt received by the Group:**
understood as the funding that, for credit seniority purposes, comes behind all the common creditors. The issues moreover, have to fulfill a number of conditions which are laid out in article 63 of the CRR.

**s) Instruments and elements issued or considered acceptable as capital before December 31, 2011:** Tier 2 capital includes the subordinated debt received by the Group that does not meet the conditions set out in article 63 of the CRR, but is acceptable in the transitional regulatory capital under article 484 of the CRR.

**t) Qualifying capital instruments included in the consolidated Tier 2 capital, issued by affiliates and held by third parties:** these instruments are included as set out in articles 87 and 88 of the CRR.

**u) Surplus resulting between value adjustments for asset impairment plus allowances for losses calculated as per the IRB method on the expected losses:** a calculation is made of the surplus resulting between the allowances for impairment losses on assets and provisions for risks related to exposures calculated as per the IRB Method and expected losses corresponding to them, for the part that is below 0.6% of the risk-weighted exposures calculated according to this method.

Annex VI to this Report presents the Group's issues of perpetual contingent convertible securities and issues of preference shares, which as explained above, form part of additional Tier 1 capital.

This annex also details the Group's issues of subordinated debt as of December 31, 2016, calculated as Tier 2 capital.


## 2.2. Amount of capital

The table below shows the amount of total eligible capital, net of deductions, for the different items making up the capital base as of December 31, 2016 and December 31, 2015, in accordance with the disclosure requirements for information relating to temporary capital set out by Implementing Regulation (EU) No. 1423/2013 of the Commission dated December 20, 2013:

**TABLE 5: Amount of capital**


<table>
    <thead>
	<tr class="m">
 <th colspan="2">(Millions of euros)</th>
 <th></th>
</tr>
        <tr class="m">
            <th></th>
            <th>Eligible capital resources</th>
        </tr>
        <tr>
            <th></th>
            <th>12/31/2016</th>
            <th>13/31/2015</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>a) Capital and share premium</td>
            <td>27,210</td>
            <td>27,112</td>
        </tr>
        <tr>
            <td>b) Retained earnings</td>
            <td>23,688</td>
            <td>22,588</td>
        </tr>
        <tr>
            <td>c) Other accumulated earnings (and reserves)</td>
            <td>(5,760)</td>
            <td>(3,470)</td>
        </tr>
        <tr>
            <td>d) Minority interests</td>
            <td>6,969</td>
            <td>7,143</td>
        </tr>
        <tr>
            <td>e) Net attrib, profit and interim and final Group dividends</td>
            <td>2,232</td>
            <td>1,456</td>
        </tr>
        <tr class="b2">
            <td>Ordinary Tier 1 Capital before other reglamentary adjustments</td>
            <td>54,339</td>
            <td>54,829</td>
        </tr>
        <tr>
            <td>f) Additional value adjustments</td>
            <td>(250)</td>
            <td>(195)</td>
        </tr>
        <tr>
            <td>g) Intangible assets</td>
            <td>(5,675)</td>
            <td>(3,901)</td>
        </tr>
        <tr>
            <td>h) Deferred tax assets</td>
            <td>(453)</td>
            <td>(75)</td>
        </tr>
        <tr>
            <td>i) Expected losses in equity</td>
            <td>(16)</td>
            <td>(31)</td>
        </tr>
        <tr>
            <td>j) Profit or losses on liabilities measured at fair value</td>
            <td>(202)</td>
            <td>(136)</td>
        </tr>
        <tr>
            <td>k) Direct and indirect holdings of own instruments</td>
            <td>(181)</td>
            <td>(511)</td>
        </tr>
        <tr>
            <td>l) Securitizations tranches at 1250%</td>
            <td>(62)</td>
            <td>(89)</td>
        </tr>
        <tr>
            <td>m) Temporary CET1 adjustments</td>
            <td>(129)</td>
            <td>(788)</td>
        </tr>
        <tr>
            <td>n) Admisible CET1 deductions</td>
            <td>-</td>
            <td>(549)</td>
        </tr>
        <tr class="b">
            <td>Total Common Equity Tier 1 regulatory adjustments</td>
            <td>(6,969)</td>
            <td>(6,275)</td>
        </tr>
        <tr class="b2">
            <td>Common Equity Tier 1 (CET1)</td>
            <td>47,370</td>
            <td>48,554</td>
        </tr>
        <tr>
            <td>o) Equity instruments and share premium classified as liabilities</td>
            <td>5,806</td>
            <td>4,439</td>
        </tr>
        <tr>
            <td>p) Items referred in Article 484 (4) of the CRR</td>
            <td>691</td>
            <td>862</td>
        </tr>
        <tr class="b2">
            <td>Additional Tier 1 before reglamentary adjustments</td>
            <td>6,497</td>
            <td>5,302</td>
        </tr>
        <tr>
            <td>q) Temporary adjustments Tier 1</td>
            <td>(3,783)</td>
            <td>(5,302)</td>
        </tr>
        <tr class="b2">
            <td>Total reglamentary adjustments of Additional Tier 1</td>
            <td>(3,783)</td>
            <td>(5,302)</td>
        </tr>
        <tr class="b2">
            <td>Additional Tier 1 (AT1)</td>
            <td>2,713</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>Tier 1 (Common Equity Tier 1+Additional Tier 1)</td>
            <td>50,083</td>
            <td>48,554</td>
        </tr>
        <tr>
            <td>r) Equity instruments and share premium</td>
            <td>1,935</td>
            <td>2,006</td>
        </tr>
        <tr>
            <td>s) Amount of the admissible items, pursuant to Article 484</td>
            <td>421</td>
            <td>429</td>
        </tr>
        <tr>
            <td>t) Admissible shareholders' funds instruments included in consolidated Tier 2 issued by subsidiaries and held by third parties</td>
            <td>5,915</td>
            <td>5,716</td>
        </tr>
        <tr>
            <td>-Of which: instruments issued by subsidiaries subject to ex-subsidiary stage</td>
            <td>350</td>
            <td>(99)</td>
        </tr>
        <tr>
            <td>u) Credit risk adjustments</td>
            <td>538</td>
            <td>3,496</td>
        </tr>
        <tr class="b2">
            <td>Tier 2 before reglamentary adjustments</td>
            <td>8,810</td>
            <td>11,646</td>
        </tr>
        <tr class="b2">
            <td>Tier 2 reglamentary adjustments</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>Tier 2</td>
            <td>8,810</td>
            <td>11,646</td>
        </tr>
        <tr class="b2">
            <td>Total Capital (Total capital = Tier 1 + Tier 2)</td>
            <td>58,893</td>
            <td>60,200</td>
        </tr>
        <tr class="b2">
            <td>Total RWA's</td>
            <td>388,951</td>
            <td>401,285</td>
        </tr>
        <tr>
            <td>CET 1 (phased-in)</td>
            <td>12,18%</td>
            <td>12,10%</td>
        </tr>
        <tr>
            <td>CET 1 (fully loaded)</td>
            <td>10,90%</td>
            <td>10,34%</td>
        </tr>
        <tr>
            <td>Tier 1 (phased-in)</td>
            <td>12,88%</td>
            <td>12,10%</td>
        </tr>
        <tr>
            <td>Tier 1 (fully-loaded)</td>
            <td>12,46%</td>
            <td>11,61%</td>
        </tr>
        <tr>
            <td>Total Capital (phased-in)</td>
            <td>15,14%</td>
            <td>15,00%</td>
        </tr>
        <tr>
            <td>Total Capital (fully-loaded)</td>
            <td>14,71%</td>
            <td>14,39%</td>
        </tr>
    </tbody>
</table>

The variations in the Common Equity Tier 1 (CET1) in the above table are mainly explained by the generation of capital, net of dividends paid and remunerations; and the efficient management and allocation of capital in line with the strategic objectives of the Group.

Additionally, there is a negative effect on the minority interests and deductions due to the regulatory phase-in calendar of 60% in 2016 compared with 40% in 2015.

During 2016, the Group has completed the additional Tier 1 capital recommended by the solvency regulation (1.5% of the risk-weighted assets), with the issuance of perpetual securities eventually convertible into shares, classified as additional Tier 1 equity instruments (contingent convertible) under the solvency rules and contributing to the ratio of Tier 1 stood at 12.88%.

As regards to Tier 2 capital, the reduction over the previous year is due to the fact that as of December 31, 2016 credit risk adjustment in the part related to standard credit risk models is no longer included as Tier 2.

Finally, the total capital ratio stands at 15.14% reflecting the effects explained above.

Annex V to this document shows the main features of the capital instruments with the aim of reflecting, with the level of detail required by regulations, the characteristics of an entity's capital instruments, in accordance with Implementing Regulation (EU) No. 1423/2013 of the Commission dated December 20, 2013.

The process followed is shown below, according to the recommendations issued by the EBA. Based on the shareholders' equity reported in the Group's Annual Consolidated Financial Statements and by applying the deductions and adjustments shown in the table below, the regulatory capital figure eligible for solvency purposes is arrived at:

**TABLE 6: Reconciliation of shareholders ‘equity with regulatory capital**

<table class="tableizer-table">
    <thead>
	<tr class="m">
 <th colspan="2">(Millions of euros)</th>
 <th></th>
</tr>
        <tr class="tableizer-firstrow">
            <th>Elegible capital resources</th>
            <th>12/31/2016</th>
            <th>12/31/2015</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Capital</td>
            <td>3,218</td>
            <td>3,120</td>
        </tr>
        <tr>
            <td>Share premium</td>
            <td>23,992</td>
            <td>23,992</td>
        </tr>
        <tr>
            <td>Retained earnings, revaluation reserves and other reserves</td>
            <td>23,641</td>
            <td>22,512</td>
        </tr>
        <tr>
            <td>Other equity instruments (net)</td>
            <td>54</td>
            <td>35</td>
        </tr>
        <tr>
            <td>Treasury shares</td>
            <td>(48)</td>
            <td>(309)</td>
        </tr>
        <tr>
            <td>Attributable to the parent company</td>
            <td>3,475</td>
            <td>2,642</td>
        </tr>
        <tr>
            <td>Attributed dividend</td>
            <td>(1,510)</td>
            <td>(1,352)</td>
        </tr>
        <tr class="b2">
            <td>Total Equity</td>
            <td>52,821</td>
            <td>50,640</td>
        </tr>
        <tr>
            <td>Accumulated other comprehensive income</td>
            <td>(5,458)</td>
            <td>(3,349)</td>
        </tr>
        <tr>
            <td>Non-controlling interests</td>
            <td>8,064</td>
            <td>8,149</td>
        </tr>
        <tr class="b2">
            <td>Shareholders´ equity</td>
            <td>55,428</td>
            <td>55,440</td>
        </tr>
        <tr>
            <td>Intangible assets</td>
            <td>(5,675)</td>
            <td>(3,901)</td>
        </tr>
        <tr>
            <td>Fin, treasury shares</td>
            <td>(82)</td>
            <td>(95)</td>
        </tr>
        <tr>
            <td>Indirect treasury shares</td>
            <td>(51)</td>
            <td>(415)</td>
        </tr>
        <tr class="b2">
            <td>Deductions</td>
            <td>(5,808)</td>
            <td>(4,411)</td>
        </tr>
        <tr>
            <td>Temporary CET 1 adjustments</td>
            <td>(129)</td>
            <td>(788)</td>
        </tr>
        <tr>
            <td>Capital gains from the Available-for-sale debt instruments portfolio</td>
            <td>(402)</td>
            <td>(796)</td>
        </tr>
        <tr>
            <td>Capital gains from the Available-for-sale equity portfolio</td>
            <td>273</td>
            <td>8</td>
        </tr>
        <tr>
            <td>Differences from solvency and accounting level</td>
            <td>(120)</td>
            <td>(40)</td>
        </tr>
        <tr class="b2">
            <td>Equity not eligible at solvency level</td>
            <td>(249)</td>
            <td>(828)</td>
        </tr>
        <tr class="b2">
            <td>Other adjustments and deductions</td>
            <td>(2,001)</td>
            <td>(1,647)</td>
        </tr>
        <tr class="b2">
            <td>Common Equity Tier 1 (CET 1)</td>
            <td>47,370</td>
            <td>48,554</td>
        </tr>
        <tr class="b2">
            <td>Additional Tier 1 before Regulatory Adjustments</td>
            <td>6,114</td>
            <td>5,302</td>
        </tr>
        <tr class="b2">
            <td>Total Regulatory Adjustments of Aditional Tier 1</td>
            <td>(3,401)</td>
            <td>(5,302)</td>
        </tr>
        <tr class="b2">
            <td>Tier 1</td>
            <td>50,083</td>
            <td>48,554</td>
        </tr>
        <tr class="b2">
            <td>Tier 2</td>
            <td>8,810</td>
            <td>11,646</td>
        </tr>
        <tr class="b2">
            <td>Total Capital (Tier 1 + Tier 2)</td>
            <td>58,893</td>
            <td>60,200</td>
        </tr>
        <tr class="b2">
            <td>Total Minimum capital requirements</td>
            <td>37,923</td>
            <td>38,125</td>
        </tr>
    </tbody>
</table>




## 2.3. Risk profile

BBVA Group has a General Risk Management and control model (hereinafter, the "Model") tailored to its business model, organization and the geographical areas in which it operates, allowing them to develop their activity in accordance with their strategy and policy control and risk management defined by the Bank's governing bodies and adapt to a changing economic and regulatory environment, addressing management globally and adapted to the circumstances at any particular time. The Model establishes a system of risk management that is adapted to the entity's risk profile and strategy.

The risks inherent in the business that make up the risk profile of BBVA Group are as follows:

- **Credit risk:** credit risk arises from the probability that one party to a financial instrument will fail to meet its contractual obligations for reasons of insolvency or inability to pay and cause a financial loss for the other party. This includes counterparty credit risk, issuer credit risk, liquidation risk and country risk.

- **Counterparty credit risk:** counterparty credit risk originates in the possibility of losses derived from positions in derivatives and repos.

- **Credit valuation adjustment (CVA) risk:** its aim is to reflect the impact on the fair value of the counterparty's credit risk.

- **Market risk:** market risk originates in the possibility that there may be losses in the value of positions held due to movements in the market variables that affect the valuation of financial products and assets in trading activity.

- **Operational risk:** operational risk is defined as the one that could potentially cause losses due to human errors, inadequate or faulty internal processes, system failures or external events. This definition includes legal risk, but excludes strategic and/or business risk and reputational risk.

- **Structural risks:** these are divided into structural interest-rate risk (movements in interest rates that cause alterations in an entity's net interest income and book value) and structural exchange-rate risk (exposure to variations in exchange rates originated in the Group's foreign companies and in the provision of funds to foreign branches financed in a different currency to that of the investment).

- **Liquidity risk:** risk of an entity having difficulties in duly meeting its payment commitments, and where it does not have to resort to funding under burdensome terms which may harm the bank's image or reputation.

The chart below shows the total risk-weighted assets broken down by type of risk (where the credit risk encompasses the counterparty credit risk) as of December 31 2016 and December 31 2015:

**CHART 1: Distribution of RWAs by risk type**

<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA5kAAAGLCAYAAABN11afAAAYJWlDQ1BJQ0MgUHJvZmlsZQAAWIWVeQdUFE3Tbs/OBliWJeeck+QMknPOGYEl55xRiSJJEQQUARVUEFQwkERURBBBRFABAyLBQFJBBUVA/iHo+33vf8+95/aemXmorq5+uqu6e4oBgI2eFB4ejKIGICQ0OtLaQJvb0cmZGzcJIOTHCKgABckrKlzL0tIUIOXP87/Lygiii5Rn4lu2/nf9/7XQePtEeQEAWSLY0zvKKwTBjQCgmb3CI6MBwPQjcr646PAtvIhg+kiEIABY9Bb228HMW9hzB+/Z1rG11kGwJgBkBBIp0g8A4hZv7lgvP8QOEeGIpQ31DghFVFMQrO7lT/IGgLUD0dkTEhK2hRcQLOz5H3b8/sum51+bJJLfX7wzlu1CphsQFR5MSvj/nI7/dwkJjvnTBy9yEfwjDa23xozM28WgMJMtTEBwe6inuQWCaRH8MMB7W38Lv/KPMbTb1V/witJB5gzxM0ABb5KuCYLZEcwYE2SntYtlSJHbbRF9lHlAtJHtLvaMDLPetY+KDQ02N921k+XvY/QHn/aJ0rP5o+MboG+EYCTSUI2J/rYOOzxRXbEB9uYIJiJ4MCrIxmS37Xiiv475H53IGOstzvwI/u4bqW+9owMzh0T9GRcs4UXa7guJBVgz2t/WcKct7OgT5Wj6h4O3j67eDgfY2yfUbpcbjESXtvVu28zwYMtdffi0T7CB9c48w1ejYm3+tH0ajQTYzjzAU4EkY8vdvlbCoy1td7ihUcAU6ABdwA1ikMsThIFAEDCw0LKA/LVTow9IIBL4AR8gviv508JhuyYUuduARPAJQT4g6m877e1aHxCLyDf+Snfu4sB3uzZ2u0UQ+IDgEDQrWh2tijZF7prIJYNWQiv/acdN9adXrB5WF2uI1ceK/OXhhbAORq5IEPB/kJkgTx9kdFtcQv+M4R97mA+YIcwUZhgzgXkJ7MG7bSu7Wu4BaZH/Ys4NzMAEYk1/d3SeiM3ZPzpoQYS1PFobrYbwR7ijGdGsQBwth4xEC62BjE0ekf4nw5i/3P6Zy3/3t8X6P8ezKyeKEuV3WXj+9YzOX61/W9H5jznyRp4m/9aEs+AbcA98D+6F2+EWwA3fhVvhfvj2Fv4bCe+2I+FPb9bb3IIQOwF/dKQuSc1Krf+rb9Ju/1vzFRXtEx+9tRh0wsITIgP8/KO5tZDd2IfbKNRLYg+3jJS0IgBbe/vO1vHNenvPhhif/CPzmQFgLxLf5IP/yAKPA1DXDQBTzj8yQRcAWJB99tpTr5jI2B3Z1nYMMACPnBj0gAVwAj4gjIxHBigAVaAJ9IAxsAC2wAm4ITPuD0IQznFgP0gFmSAXHAPF4BQ4A86Bi+AKuA5aQDu4Bx6AR2AQDIPXSFy8B/NgEayANQiCcBAlRAexQFyQACQGyUBKkDqkB5lC1pAT5AH5QaFQDLQfSodyoULoFFQJ1ULXoJvQPagXGoJeQpPQLPQV+oWCUQQUPYoDJYiSRCmhtFAmKFvUPpQfKgKViMpAHUWdRFWhLqOaUfdQj1DDqAnUPGoZBjAFzAjzwOKwEqwDW8DOsC8cCR+Ec+ASuAquh9sQPz+DJ+AFeBWNRdOhudHiSGwaou3QXugI9EF0HvoU+iK6Gd2FfoaeRC+if2MoMewYMYwKxgjjiPHDxGEyMSWYakwTphtZN+8xK1gslhErhFVE1qUTNhCbhM3DVmAbsB3YIew0dhmHw7HgxHBqOAscCReNy8SV4i7j7uKe4t7jfpJRkHGRyZDpkzmThZKlkZWQ1ZHdIXtK9pFsjZyaXIBchdyC3Js8gTyf/Dx5G/kT8vfka3gavBBeDW+LD8Sn4k/i6/Hd+DH8NwoKCl4KZQorigCKFIqTFFcpHlJMUqwSaAmiBB2CKyGGcJRQQ+ggvCR8o6SkFKTUpHSmjKY8SllLeZ9ynPInkY4oQTQiehOTiWXEZuJT4mcqcioBKi0qN6pEqhKqG1RPqBaoyakFqXWoSdQHqcuob1KPUi/T0NFI01jQhNDk0dTR9NLM0OJoBWn1aL1pM2jP0d6nnaaD6fjodOi86NLpztN1072nx9IL0RvRB9Ln0l+hH6BfZKBlkGOwZ4hnKGO4zTDBCDMKMhoxBjPmM15nHGH8xcTBpMXkw5TNVM/0lOkHMxuzJrMPcw5zA/Mw8y8WbhY9liCWApYWljesaFZRVivWONbTrN2sC2z0bKpsXmw5bNfZXrGj2EXZrdmT2M+x97Mvc3ByGHCEc5Ry3OdY4GTk1OQM5CzivMM5y0XHpc4VwFXEdZdrjpuBW4s7mPskdxf3Ig87jyFPDE8lzwDPGq8Qrx1vGm8D7xs+PJ8Sny9fEV8n3yI/F78Z/37+S/yvBMgFlAT8BU4I9Aj8EBQSdBA8LNgiOCPELGQklCh0SWhMmFJYQzhCuEr4uQhWREkkSKRCZFAUJSov6i9aJvpEDCWmIBYgViE2tAezR3lP6J6qPaPiBHEt8VjxS+KTEowSphJpEi0SnyX5JZ0lCyR7JH9LyUsFS52Xei1NK20snSbdJv1VRlTGS6ZM5rkspay+bLJsq+ySnJicj9xpuRfydPJm8oflO+U3FBQVIhXqFWYV+RU9FMsVR5XolSyV8pQeKmOUtZWTlduVV1UUVKJVrqt8URVXDVKtU53ZK7TXZ+/5vdNqvGoktUq1CXVudQ/1s+oTGjwaJI0qjSlNPk1vzWrNj1oiWoFal7U+a0tpR2o3af/QUdE5oNOhC+sa6OboDujR6tnpndIb1+fV99O/pL9oIG+QZNBhiDE0MSwwHDXiMPIyqjVaNFY0PmDcZUIwsTE5ZTJlKmoaadpmhjIzNjtuNmYuYB5q3mIBLIwsjlu8sRSyjLC8ZYW1srQqs/pgLW2937rHhs7G3abOZsVW2zbf9rWdsF2MXac9lb2rfa39Dwddh0KHCUdJxwOOj5xYnQKcWp1xzvbO1c7LLnouxS7vXeVdM11H9gnti9/X68bqFux2253KneR+wwPj4eBR57FOsiBVkZY9jTzLPRe9dLxOeM17a3oXec/6qPkU+nz0VfMt9J3xU/M77jfrr+Ff4r8QoBNwKmAp0DDwTOCPIIugmqDNYIfghhCyEI+Qm6G0oUGhXWGcYfFhQ+Fi4ZnhExEqEcURi5EmkdVRUNS+qNZoeuQ1pz9GOOZQzGSsemxZ7M84+7gb8TTxofH9CaIJ2QkfE/UTLyShk7ySOvfz7E/dP3lA60DlQeig58HOZL7kjOT3KQYpF1PxqUGpj9Ok0grTvqc7pLdlcGSkZEwfMjh0KZOYGZk5elj18JksdFZA1kC2bHZp9u8c75y+XKncktz1PK+8viPSR04e2Tzqe3QgXyH/9DHssdBjIwUaBRcLaQoTC6ePmx1vLuIuyin6Xuxe3FsiV3LmBP5EzImJk6YnW0v5S4+Vrp/yPzVcpl3WUM5enl3+o8K74ulpzdP1ZzjO5J75dTbg7ItKg8rmKsGqknPYc7HnPpy3P99zQelCbTVrdW71Rk1ozcRF64tdtYq1tXXsdfmXUJdiLs1edr08eEX3Smu9eH1lA2ND7lVwNebq3DWPayPXTa533lC6Ud8o0FjeRNeU0ww1JzQvtvi3TLQ6tQ7dNL7Z2aba1nRL4lZNO0972W2G2/l38Hcy7mzeTby73BHesXDP7950p3vn6/uO9593WXUNdJt0P3yg/+B+j1bP3YdqD9t7VXpv9in1tTxSeNTcL9/f9Fj+cdOAwkDzE8UnrYPKg21De4fuPNV4eu+Z7rMHz42ePxo2Hx4asRt5Meo6OvHC+8XMy+CXS69iX629ThnDjOW8oX5TMs4+XvVW5G3DhMLE7Undyf4pm6nX017T8++i3q2/z/hA+aHkI9fH2hmZmfZZ/dnBOZe59/Ph82sLmZ9oPpV/Fv7c+EXzS/+i4+L7pcilza9531i+1XyX+965bLk8vhKysvYj5yfLz4urSqs9vxx+fVyLW8etn9wQ2Wj7bfJ7bDNkczOcFEnafhWAkQvl6wvA1xoAKJ0AoBsEAE/cyb12CwxtpRwA2EN6KC1YCc2MwWPJcFJkTuTp+LsELCWJ2EKNpwmm7aOXZyhnAsxBLANsCuzHOOa5NLnzeYb48PzKAk6CQUIhwq4i2qIcoktiD/aUigdJqElSSr6VapBOkbGS5ZH9JHdT/pCClSK74nuleuV4FS1VvOqzveVq3up71L9qtGju19LWJmi/1bmjW6dXoV9gcNCQZKRhzGy8ZNJvWm9WYV5p0W45bY2xYbFltaO2h+3XHdacgDO5C9GVch9637LblPugRwfphme1V6l3jk+Cr5+frb92gFygaBBPMEsIVSgc+j1sKnww4lbk+aij0ckxmbFN8egEn8SO/eCA4EGVZKMUl9SYtKPpxRlJh+QOTWfmH7bMEsimyAG5qDyaI8JH1fPNjzkUOBc6H3cssi+2LbE6YX7SpNTglHaZerlyhexp8TOiZ6UqTarSz01cMKq+XDNfS1MncEn6suoV3XqzBoer7tf8r4ffiGs82JTWfKglqzX3Zn5b8a3y9urbjXe67452TNwb6Wy479vF3PWwu+RBXI/vw329Dn1Wj0z6DR4bDtg+iRg8O/TyGcVzyWGdEaNRvRdKLwVeEV+tvp4Ze/Hm3vi5t+kTfpN2U+bTZu8s3lt8MP6oPMM0MzGbMyc3NzF/cSHxk+Fnss+1Xwy+TC+eW4r/6vbN4rvZcuBK58/Dv1o2dDc3d/0vDaPhWfQEZhq7SAaTK+D9KcoJE0RRqjjqB7QsdAn0zxllmNKY37DKs2WyD3KycjlyF/C0847xLfOvCMwJPhY6Jxwpoi5KJvpc7MyeQHF58d8SDySPSjlIc0l/lKmXjZVTk4fkuxVyFC2U6JRGlEtVXFQ5VMeQKHBVZ1Ef1Tih6aIlqLWmPaxzTTdPz0d/rwGNwQfDdqNi41gTH1NPM3/zMIsQS08rC2tVG1FbNjuiPcp+xeGj44jTfed6lzLXnH2JbgHujh66JElPZi/Ia8572KfLt8mv2r8kICMwLMgpWDNEKJQSiYTJ8PGI71E80e4xpbH34l7ETycsJK7upzjAeVA4mTsFm/I2tSktPz0yw+2QXabj4YCs9OyKnCu5TXnNRxqPXsu/cqy24ELh2eNlRcXF+SXZJ9JOJpSGnfIrCyhPqbh7RuTsxSqhc4Xnn11YrSFeZK3lqxNF4kDxinq9boPZVadrwdczb5xrvNM01DzeMtP6rQ2+xdQudlv1juZdxQ6ee6h7U50995u6arrLHhzrOfQwsTeyL/pRdn/7AOOTA4NvnrI+03huO+w7kjJ64cWTl99f046JvzEdD397YuLW5NOp8empd/MfMIj3U2eH5mkWpD7Jfxb8QvXl5+KHpdGvfd9ufq9cTl6x/yH0Y+Vn+2riL9U1wrruxuyu/yWgeVQF7IYWweAwS9hZ3BzZFPkSBZ4gQKlFdKZKpb5MM0S7SS/AoMcYyHSI+QxLI2s320P2Bxy3OCu54rm1uX/xnOc14Z3ny+IX4u8UcBNYFSwSkhLqE/YTwYnUiBqKfhTL3CO8p1vcSwJIVEjulXwhFYO83TTImMrMyKbLccq1ylvLLygcUuRSbEHeWmaUk1UYVS6paqk+3eu197NakjpOvUxDTmNEM1GLU6tV20L7pY6/zqZulZ6lPrn+fYP9hnKGc0ZVxq4mzCYjpsVmNuZU5r0W6Zaqlt+tGqyDbIRs3tlW2u2zZ7F/7pDvaOi46dTkHOzC7/LGtWSf+b4VtyJ3AfdGDy2PV6R4T17PF8g+4u9j4Kvop+xvFEAKDAkiBWuEUIeMhV4ICwmXD1+PuB+ZE2UZzRD9OuZMrHecYNyH+NMJegljicFJ9EnP9t86cOdgV/L9lJuptWkl6ekZYYdcMvUOi2Zhsp5nl+Y45/LnruVNHHl89Gb+2WMHC1wKVY6zHl8tGim+XnLixJGThaWVp26UPSh/UTF3eu0sZSV3lew5w/OuF8KqD9ZkX8yrTakjXVK8TLz89cqn+tWrhGuc12VuWDYmNTU2/2xVvhneVnrranvr7Vt3eu8u3zPovNll073cU9Ir2/e8/8iAx6DRU63n2iPBL4lj81MDc8vfV7f8v/M/uK2CVQDgeCqSoWYCYKcBQEEXkmcOI3knHgBLSgBslQFK0BegCP0AUpn8e35AyGmDBRSABjADLiAEpIAKkhlbAGfgC6KQ7DIfnAb14A54AibBdyRzZIekIQPIHYqDCqDL0EPoAwqLEkaZoqJQFUiet4nkdbHwTfg32gB9HD2FkcVkYd5iVbCl2DUkw+ojUySrIWcjL8BT4LMp8BTHCKyEGko5ynaiGrGNSonqFrUh9WuaaFpq2it0unRD9Lb0QwwWDE8Z3Rl/MpUyqzGPsxxgZWNtY3NjJ2dv54jllOP8xnWdO5JHnmedt4evhN9fYK8gUXBC6IZwloinqJaY4B7injXxzxLvJIelmqSTZKRlxmWz5OTlvsi3KhQqJih5K5uqSKky7SWqSaiXaYppHdHu1fmiR6bPYMBiyG7EbyxnYm4aYXbSvMviqxWftYPNUdsee7SDrmOmU78Lo6vnvjq3dx5YEo0n1nPZ6733mM+cH5W/SUBx4MfgvSFFoZ/DjSPqogjRETGv4vTjWxPFk6oPcB8sS2FMLUjHZ6QeWj4cmDWfk5sXcrSpgOY4a9GnktqT7qcYywYrjpwxOLtclX+e/kJW9crFoNqvl45d0Wugubp0/UPjTPN868e26falu0z3dO67dXv02PRqPJJ8LPJEYSj02c9R9CvysTNv6SbvvCfO7J/X+tTwZe2rwnf9FfyPIz/7Vmd+vV97ud64cey356bU9v6x5X8cIABawAJ4gCiQBWrAENgCDxACkkA2KAW14CZ4BN6ARQgDsUJS295PgIqgq9AA9AlFhZJFOaPSUddR72Eu2B0+Dy+gFdAZ6GGMCCYVM4b4vgwHcP64YTI9slZySfI6vAj+MoUcxV2CJWGaMp5ITiym4qG6iuSvr2niaBlpW+js6T7RH2DAM5xkFGfsYwpjZmLuYAlgpWftYAtj52cf4yjldORi5nrJXcHjzSvFB/ie818SyBB0FZJDcrk5kX7RG8gpli+eLrFfMlrKS1pThiAzIJsjZyLPJL+k8FKxR6lZuUolTzVxb6xatnqrxg8tWW1vnVzdar1m/VsGtwxvG/UaT5qizETN7S0OWbZYLdjw27rbVdiPO/I6BTo3u+L2Obidcu/2GCJ1etZ6ZXkH+Fj7Gvo5+acFdARRBnuGtIexhidGvInSjq6NpYoLj3+UyJMUu3/woHzy+VS2tKIM/KGkzIUsUvZUbuIRqXzUsTeF14piS+ROfC29VhZToXL619nqKplzFec/VgvV+F+8Wsd0qfyKWv2nq6XXlW8MNJGa11qr2qzawe3au6YdS51nujwfqDzk6UM/evw49gl2MOcp4VnVsPuo2cvg1zVvPk5wTVm+S/1wZ5Zp/thnwcXH34pW8laN1mTWT2+8+7206380IAfUyOrnAWJAAegAS+CG+P4AsvIrQSN4CMaRdU+ABCFNaB+UBJVBt6FJFDnidRKqGDUIM8A+8G00OzoFPYdxwjzG6mBv49Rw98hMyd6QR+Gp8Fcp7AkwoYUygihN/EnVTV1KE0PrRGdEb8xgxWjMpMgswiLP6s6WwB7N4clpy2XObcZjxmvKZ8ZvLeAuGCV0RLhO5KHo7B5KcUUJX8lTUiMyrLLecg3ya4qWSo9Vsvc6qWM0jmmua5vopCMebNFvN7hjOGC0ZmJi2mwuYXHZSsK62VbHbsQhxAnvfNnV3o3Gg8LT3dvF552fqn9uwIcg6+D+ULOwpxEukTPRSbGcceMJD5I6DlQk26X8SqvMsM/kOryYfTs374hvvkEBS+GjIt/ilRPppTSnqsoVKh6f8a2EqsrPK10YrompZat7eDm53uCq5HX9xuTmqtb8Nqd2ptujd8vuOd3HdV14INdzq1evb7Q/fkByEB5afDYzPDRa8FLoVcXr32/0xnPePpqkmrKbPvtu9oP0x6CZs7MP5+YWMJ/YP0t90V10WCJ99f5m+Z33+/LykRX2lbofyj9O/Vj96fCzeZVxNXK1eXXtl+avjF+9a8Q1m7UTa4PrZOua6/Hr19ZnN3g2nDYKN/o2Nn5L//b+feL3o9+/N6U3fTZPbvZv+T/KV1Zm+/iACNoAYMY3N78JAoArBGCjYHNzrWpzc+MckmyMAdARvPNdZ/usoQagfOtbEujjyVv89/eV/wHuccbRWVsF0AAAAZ1pVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDUuNC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+OTIxPC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjM5NTwvZXhpZjpQaXhlbFlEaW1lbnNpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgraLZAAAABAAElEQVR4AeydBVyUyRvHfyBhICLYrQhnB7Zn6xlne3ac3WedHaf+PeuMs049z7O7u1uxxTi7u0hBkOb9zywsLgviLizIwm/8rPvGzLwz3/dl531mnjBRRAITCZAACZAACZAACZAACZAACZAACRiAgKkB6mAVJEACJEACJEACJEACJEACJEACJKAiQCGTDwIJkAAJkAAJkAAJkAAJkAAJkIDBCFDINBhKVkQCJEACJEACJEACJEACJEACJEAhk88ACZAACZAACZAACZAACZAACZCAwQhQyDQYSlZEAiRAAiRAAiRAAiRAAiRAAiRAIZPPAAmQAAmQAAmQAAmQAAmQAAmQgMEIUMg0GEpWRAIkQAIkQAIkQAIkQAIkQAIkQCGTzwAJkAAJkAAJkAAJkAAJkAAJkIDBCFDINBhKVkQCJEACJEACJEACJEACJEACJEAhk88ACZAACZAACZAACZAACZAACZCAwQhQyDQYSlZEAiRAAiRAAiRAAiRAAiRAAiRAIZPPAAmQAAmQAAmQAAmQAAmQAAmQgMEIUMg0GEpWRAIkQAIkQAIkQAIkQAIkQAIkQCGTzwAJkAAJkAAJkAAJkAAJkAAJkIDBCFDINBhKVkQCJEACJEACJEACJEACJEACJEAhk88ACZAACZAACZAACZAACZAACZCAwQhQyDQYSlZEAiRAAiRAAiRAAiRAAiRAAiRAIZPPAAmQAAmQAAmQAAmQAAmQAAmQgMEIUMg0GEpWRAIkQAIkQAIkQAIkQAIkQAIkQCGTzwAJkAAJkAAJkAAJkAAJkAAJkIDBCFDINBhKVkQCJEACJEACJEACJEACJEACJEAhk88ACZAACZAACZAACZAACZAACZCAwQhQyDQYSlZEAiRAAiRAAiRAAiRAAiRAAiRAIZPPAAmQAAmQAAmQAAmQAAmQAAmQgMEIUMg0GEpWRAIkQAIkQAIkQAIkQAIkQAIkQCGTzwAJkAAJkAAJkAAJkAAJkAAJkIDBCFDINBhKVkQCJEACJEACJEACJEACJEACJEAhk88ACZAACZAACZAACZAACZAACZCAwQiYGawmVmSkBALhc+EsZm24i4N3PXEZ1ihS0gGdOlTDkFJWsIzsVRjw+Cr+WXkd66+/x6lAKzgUsUeXLjUwVDPfJzfcO38Ph049wrIXgQi1K4M1s8vBKbIeH7zecxZzjjzF6Xse4dcrWwQ9WldCP816IvNzgwRIgARIgARIIPkTSKz3EQVw2Yem81/hkYkWVcUMeVu2wN7GtuAqjBYb7pKAngRMFJH0LMPsyYbAB7xYsA7Vt3rhGcyQOW9GlA32xoG3QTALzYzOC7vi3xIWorehqh/kn0fdwJrgVLDOboey5r54+MIfL8NsUH9se+yoZ4vU8MXz6YuQ72DQZ0K2lXFiey3UUB15B5fxG9D8tB9epc+Mak6Z4RTijrMXPfC+5c+42ycn0nwuyS0SIAESIAESIIEUQSAx30fEpPmef2Ez2xXe0diaIF3tVnjxmyNso53jARIgAX0IcCVTH1rJLe+LK5i2yxPPs5fEwun10TefBUyEoOixYg3KrnTH+vX38VuJ4sj76RYWTRICZmBGDYFSQ/CccRBzi7XDqJyWsK5UGbNK50Kb9C7oPOoOjkcyC0bAxp1oeeoT3MvUxaWp5VA2tZxCFHMcrm9w1Sw7BcxIVtwgARIgARIggRREIFHfR8IQ5heCsND0aDK1N3ZVTZ2CQLOrJJB4BKgNkHisk96V8tTEgvmNsHpSA/RTCZiyiVawK5MVBZQw+D9ww1N56Px1zP9gijSVq+Nv1YqlPJgKKFMHs5pYwTTkBVYcd0cYzJGxehUMrZcPuay0dFCCHmD9Bje8Cc2FEUPVAqasR+TLkhNOtnwUJQ0mEiABEiABEkhxBBLzfQQh8HT9hGDFErkySW0tJhIggYQgwJXMhKBqNHWmglmR0ugYpb1ixfGOK56YmCKdWJEsgUC433bDfSFUOhbNhtxR8qZBliK2cMBLPL71Hu+RGdmjnNfYefkMhz2BYPuCaGTrDpc9/2Gnywc8SG+HihWKo1sVO2TQyM5NEiABEiABEiCBlEIgEd9HIpAGmIbg0eFd6P77Qyx/EwLrHLlRv9H3mNy6ABz4dpxSHjz2MwEJ8M8oAeEaX9V+cN+7F72Xu+GZWX5M6GSPjPDClaeBQqvVEjmypNUyhBerkJnTI6cw673/0FUIoviykPnMHddNTWAScg9/djiJDZ6fTYE3776IufWa4syYQshjfNDYYhIgARIgARIgAYMSSLj3EUWYBT2V7zWmAThy1Fz4hyiIX777gLtnn2HzP69w8lFzXB7P9xGD3k5WliIJUMhMkbddu9NC4HvzH9bMOYGxl/zgmqM4pk+qjxH5hEqsQZKo/1Mg3gmZNMw1CF4/t8KVpgVRxjoUgY9d8NeYoxh54CQmNSoQ4WjIIBdlJSRAAiRAAiRAAkZFIKHfR6SRTnp816YqfrMxQZkB36OpylxHXPfxYfTtfQmrDp/D4s6OmJaXZjxG9eiwsUmOAP+CktwtSewGhTvw6dFrL36+FIbMLZrh3PJmGOmQWlpLio8V8ucXgUxMQvBG2DAIn2waSfwou33EaxMTmDlkwXcaZ6JuipryZkKZMAVmTlWxvJOjEDDlo2cOS/uyGNLcFmamH3DmhrdW/VFr4R4JkAAJkAAJkEByJZAY7yOSnXBSWLEaJk2oGiFgymMmUOzLoFtxU/ibeuLCPX95kIkESCAeBChkxgOe8RcN/0H/edQ1LLcogJGze+LcoKJwihJHxBKZimYWAqSwXTjzGLejdNofrnc88VCEPylQLCuyRjmntZM3B6qZKQi59RzOAZrnTGGazgxpNQ9xmwRIgARIgARIIAURSMT3EeHVXnntA3ctuibCB8UnP6FFq5jDOq2hNLm0LsJdEkhBBChkpqCbHa2r7i6Y+rtQkw3Lj/F/tsb0sunF/J52EquQlUphoI2CsHtXMOKQJ8JlRDkgHMWw3b4IM8uDrrUyadlratWToQg6/5AO5h/v4o9drhF1iDzCM+3+ve7wEfE2q5bMEHsdWlVylwRIgARIgARIIBkQSMz3kZDn2D92FZouuw8XH7V+VjBCzpzFjHsivIlFTtQryrAmyeCpYhe+MQHaZH7jG/DtLi9+WF1uYZmXaIGlB9ZOWoot6t/aiEaZZiuPDdOdUCxtMfQb/xwXRolYmdP+RtaVdihr7ouHL/zxMkzGzqyPwTmlcm1syRr5elbFxIuHMXbRcuQ9UwD1swZDufYCazxNkEWEPhlZgq7EYyPIcyRAAiRAAiSQ/Agk8vuIWK50N/XFuTVbUHZTetjnsoSjvw8OvA0SaMU7zYha6Gab/CizRySQ2AQoZCY28SRzvSC43/cUoUpEg4I+4vGTj9Fb5iZCmYQAxcxkTEwRT/PvHKiy8jrWX3+P44FWKFLOCdM6VMOQUlYxrIBGrw6ZymHMsowoteo8/nV+jNU3TZDZIT86ta+Eyc3y0rNsDMh4iARIgARIgASSN4FEfh+xLorO/2RDpa2nMfPkS2F/6Y6D6cW7SaUy6NmxAroX1fGdJnnfFPaOBOJNwEQRKd61sAISIAESIAESIAESIAESIAESIAESEARok8nHgARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARIgARIgARKgkMlngARIgARIgARIgARIgARIgARIwGAEKGQaDCUrIgESIAESIAESIAESIAESIAESoJDJZ4AESIAESIAESIAESIAESIAESMBgBChkGgwlKyIBEiABEiABEiABEiABEiABEqCQyWeABEiABEiABEiABEiABEiABEjAYAQoZBoMJSsiARIgARIgARIgARJIkgS8jmHXwJr40d4WmWwLIW/z0Zh+xQtKbI31OoPDA75HrYJ2MHWohsp91+DEhzCtEsEIuz4XfzTJj5I22ZChXFu0+ec6XKPkCkDAgf7o62iD1EU7oOfe5wjQPO93FGtrtcDoq580j359O+gh7qwZiXH1K6DCn/8hOLYSBuvLA9wZ/j0qZs6JrM2nY81TzZ4INhfH4eeqC3Ey1sbE1lCeSy4EKGQmlzvJfpAACZAACZAACZAACUQn8H4Ffrdvg+GBHdD75Fu4P16DzZUvY1e1AfjjWUj0/PJI8CnsrNMCPQN7Y8Sp1wg7NgSD3UajYfOlOBcpQAkR9fp4dKqyDecabcJ29yd49Ud+5Bj3I+rMuQV/dc3vlmF86/sIWf0QASsyw7vdVCx3VQurPvg0fxT6ZumCPk5p1SW++q3gMa78VAU1N7vC6+Nt3HjhA3WN0QobrC9BwNoBqHCqKSY8uopbRTai3+jDeK6+YPB57Oy4Eq8GtEB1c/VBfqdYAgoTCZAACZAACZAACZAACSRbAq+V/7ZeU95H6d9pZYudteK07HmUo+E7AYqyrIaSpthM5XiwxumgQ8qqzJmVymteKGHicJhyU3Guk1nJ+7+ryqfIbOLMxf5KgzRdlD9fh4qj4rOxgZK6zW7ljarMI+Vy/VxKjY0RrXk+S+lr206Z9lTzQpGV6bDhqjzqk1mxHHRGEa2OIRmuL2HKM+V6i7yf2+6xUBlp2U1Z6CUv66+ELaul2P6wWlBhIgFF4Upmip1eYMdJgARIgARIgARIICUQyIHiP5VCFs2uKkEIUMxgnS615lHVtoKnOLfhBrJ0bIjqZhqnzSuicU9rXNh6CS/EYZP3R7D5eEm0+Kko0kRmMwHKNUcHix3YcuydOCrUad+8h5ItI2xlGVjDNhfg6uEn9h7ixq8LcGz4aAzKp3mhyMrivWHYvnjgzaVQZLaNWHHNkBnZ4AZXqUL8fjXGDTdH59ktUSzerWYFyYEAhczkcBfZBxIgARIgARIgARIgAR0I+OLDhfU4OHQIhtoMwOBGUURPVXkT5SluXzNFyeI5EPVF2QoZSzgiu/M93JPGnA9u45JZMTg5WES5rmJSECXqmeHB/bdCZdYMppkyCiHME54ilwIfuL9Mhdw5rIDjk9H1XC/MG1RcQ0iNUlW8dwzZl0CkQ2YhQbp5RtiOervhrUku5M7iheeTZmNd70mYUPyzuB3vxrMCoyYQ9W/HqLvCxpMACZAACZAACZAACZBATASE7eWWhnDMmAf2DQfg56XWqDSrG+qliyFvmC98fW1gaZ5K66R4bU5vhXS+PvCRQuZHH3iaWMBSaxHSBGmR1tZU1OEvhFRRR40G6LFnPsZfcIOJ8yxMPVsPTSrcxspup5BneTfUdxmG7nmsYGeXHTYN/sJB7y9aV2q1R4ddA/YlCPlRtlVBXP5zBQ54v8PrqQuxqFldNL07Ad02NsbkkXnhPakinDJmROaMJVF22iUtB0g6tJdZkg0BCpnJ5layIwlDQFj3X5uJhf0bolGZMiheuzWqjtuGEz6xDADB9/Hg318worHwvlamKsq2G4thp99G9STnfQanJ7ZGxxrlvlBnAIJO9se4OuXhVG8geh57HbW8/1HsavcLRt+KdCuQMN1nrSRAAiRAAiSQLAgISbDVPjzw8oSHx138t64csnf/CW33CVVW7f5JwdHCH4HBodpnVPuhsISl0IqFpSXSCLXbwJh8BykmsLAwF+qxIuXuhalrHWD2swNS9/ZB1h3D8PPKYRhQcT5mVzuFmU32w2PJM7h5nMf5LNPRftwZeKmuZID/DNiX1BArtp3m40yV3fhfwTJwetwZy6ZnhXPbnVAWD0HH84PQaG4V/PrUE26Ph6LZzO745ai3ATrBKoyRAIVMY7xrbHMiERBe1A63x0+9ruNI+QmYc/ESri1ughGec9Fw8E7cirEVj/FoVHtUOZ4P2Sdsx+mLy7G12Xv49huDMfci3HwLL29Hug1FpwAhZG5wxs3V7TDKcw7a9lmHc+qBym0Z5gzwwvsZB3F1hilSD1mA5R5qwdZHeKcbhY6ZmqBPMaqlxHgbeJAESIAESIAEvkggC7I1+R0zBvtiz1JnlX2lZlbFtACKlPDD3QeuWgKoPwJu3sOTmoVRWEqPjkVRIfghbj+PKowqeII7RwPhUCi7FMtESg/rZoux+MEHBNxehyWOuzFiliPGTv8R9i5HsN2vHlrWziRWPfOicIuySLfOGZeiSb6qivT+z+B9MS+O0rPP4oLba7zfMRCtjo1D9/zTML+1Nd4dvYD7bRqiqY0JFNs6aNX4PY6ffBR7aBW9e8QCxkKAQqax3Cm28xsQEEND+cFov2QhdnQuDwezVDBz7IjGv5RDh7PHsPddDCPA22PY9rg9/lo8FEPKZoWFmQPytvkNQ2pcwOo9DxEo/mHbRIwM6IGVk1uifnZLIGdzNJw3Hn+/XYLhu98KF+RCmLy4DxNrdMUkJ1soJQegV9kT2HI+Yl7z9VJMX1YJY0fUFsMREwmQAAmQAAmQQKwEvI5jxeEYViy/UMgEBVCpUV483eOsNaF8Gyc3v4JDvTKwl2VzVxdxN89h35FnUcKHmDw6gG3Pq6FulewxXCG6sx+TGFRuYygYp0MJ2pcozn7CZ8lNLM0jBOs4NZeFkhEBCpnJ6GayKwlAwOZ7/ORkE67uoq4+KBD+JulgnValBKM+Gv6dvRdG7hyK1hliOKfK8RTXDrjDs1HNaB7rajV8hwsHr+GlHKreicEwk02kJ7qMWX3hqjK0f4h7U7dgQ/f+GJRb21YkalO4RwIkQAIkQAL6ERCTp4/WYGGH4qiYMyPS5SqDop3/wOL/Pmit6GnWKsxKLszEtNaOKCls8UwdqqFy3zU4IT2OaiavMzg84HvUKmj3hTwBCDjQH30dbZC6aAf03Ps8qpmI31GsrdUCo69GOJ3RrDvW7QAEH5mPv1t0x88b7whfqDIJj6/X/8KUhR9RvX1l5FEduoETAydg2RMxGSwc3Fj+Mh5/Xh8mVFeP46EqLuYbvPu9P3q5D8SMno4RDoEqoOmSxsgwbAh6H40wa/E6iI19FuLQoBEY4agdLFIw0Xb2U7o6Gpntx7pD7mL0f46726/Ar0MVlP/Sa4Rsa6xJ3sPl+N/A3bilanfC9EXBWy1nPxmQrWpp5Fq+E1s+KDDxPIote7KiVo2C0KYQa/N5MvkQYBwXEiABHQkEPVIeHVqs/NuqkpJt8iXFU6diIl7W02nKxJItlI7nfURQrf3KpqJVlSbHxHaUJOJo7WmglK8yTzkoo29tq61Y/nI4MqbWje6VlHoHPRTF+WelYe35ygH/KIW5QwIkQAIkQALxJyBiNv6SrrRSc9Zh5YqXGJc8LykXZtRWKqQTMR9fhcRQf6Ci7GiplLeurTRdcEZ5EBSsBN9ao2z8KaeSpsGaz/ESg04qO5wyKXl6rlIOvBID2PPtyiaZp8bfytmgiGrf/qUMt6qt9DjvKuJMDlJaWfVSFr6XcSZl8lb8ppZRrNrsEpEa45J8lA87BilDy2VUMtnaKrbiY2rfRGm15Orn2Jnv/lKGpbZXamyS0SxlEmPxoxXKX3XsIspkUzLUGq8sfawdjdJH8d7ZS+max0pVr51NMaXYr7uVm+p+qeqK+E/E2VyZr7DS+oi7rF19UFHODFW65U4nyotr1F+gHPig7rc6T2zf2nEyxYXX1FHsU/dUFrqpr2Lovoj6RCzQGtlHK5s81deQbXylPP9fBaW0jY2YJy+hlJl68TPf2LrAc8mSAJJlr9gpEjAggTDliXKvfyGlXJkyqo9jvcnK0jdiYP1q+qj4Hx+ijK5aRymz5LbyQeYP2aysyF9baXXaL3rpY62UmkWmKJvl2PJ6ljKxeHulh4sQLC/1UXqXGKksfHdO2VqhjtL0hBiALw1VRlQtrZRzqqDYdFmuHPDW/JGPXjWPkAAJkAAJkEDsBMS4tqiCYlJxseKikTFMuaDsts+gOC17rnFUY9PDWdl6zkNDaBLnrg9RGpm0Vaa9lmOTEMqW1VDSFJupHA/WKCcErlWZMyuV17xQQsU/ZWMDJXWb3ZGTq5fr51JqbHwfXkAIv31t2ynTnmpWoFEXN0mABJIcAarLJp9FafYkgQiYCJfd3/11F5euXMGlY4uFB/Qr2NRmJtZ4xGCTqW5D8A38N6YRao/3h+uEFXDuVQQZ5Dlhd2FuEfxFj3UhaYRHO6kik6MXhs6yRtYR9eE0zhzKwl7osm0AupQbjrkVjuPfHrdw/3/HcMFlI67YzkX72Ze+7IlOOCV4uH06ZndrjQpL78VugP9Vr7eyE+/gtrF3hPfcOijRazqm/+etpUr1AI+mNUGLCt8ja++FWPNCqh+pk1AXujYOQ9uswkm1oyP1KX6TAAmQAAl8IwJCqdHREaVvXMDhp59/s03eXcGZN44oUtA25nbZCrOSSrZRzUoCA+GXykplVqLgKc5tuIEsHRtGMxNp3NMaF7ZeEmYioQh7I8xEsmWMNBOxzQW4eviJa0a3YYy5ITxKAiSQlAhQyExKd4NtSfoEMpRDiQG/YkiqnVh80jXm9nrvwbb2vfDDxz6YvG8h/q2dC6kjckovb/alvHD3qYeWUOaPoPv34FzMPtxjnfBEZ1V3MSYfvYSrh+ZjSf4dmBHh7CffzSM4GFQJLasI2xfh+se+nhCCj1/EpRhao+AxbvZvhTr73ODt8xQ33nyM4pwgShFdvN4KUfbjosaoty4HbFTec4VTJKfLuNJ11GfvuRBeeXcMQIvL9dHzyC7cK7gC/WaeEpYmESnkPA6PP41rnRpEfeFQn+c3CZAACZDANyAgZjhrT8OOCc+w3akWak5ajT0LWqNlyX9xdvIiEWrD6uttCnqMe7v+wNwhG3F3UGe0sxFzq8pT3L5mipLFc0TYMaqrsULGEo7I7nwP9xQzmGbKCLz3hKc4rcAH7i9TIXcOcU1tG0Z1cX6TAAkkaQIUMpP07WHjvi0BYTHvvAF73LWcF8TaKOGYZ+wE9MszAcfmtEVN66h/YtLLm1M1EzwVQmHUECi3ceGwGRyqlAz3WBflGjE5+zGHpQ5+f0xEbcX/uY7ny0ah53exRd0Ss9Zf8XqrWrd9sxxzFzmg0rQRGKPynvsd7Pssxb9tT2HenCNivlm+HLzFPREXy65bGzSwzoSMPbvht91HsM9HdioAyvbx6Gc7CPMbZYk68x2lz9whARIgARJIfAI5kKfdIAyv/Qyn183G/yafwpnaPTGiVXFkiaUxcrXyZptMsMteHt93m4Ffvbvj98HlIMRGIMwXvr42sDTXHrTE+JjeCul8feAjYkqiRgP02DMf4y+4wcR5FqaerYcmFW5jZbdTyLO8G+q7DEP3PFaws8sOmwZ/4aC3PmNzLI3nKRIggQQhEPUNOEEuwUpJwFgJPMLdzbPQY+AcLLrnE7Hy+A6ea6dj+Yfa6Fgjs+jYR/jtHo2B+1+Ge8G7PheTj9XEqDH1UUzEfY6e0sGiy3gsfzof7WeexUOVuugbuM8fjNE+HTGjfQGtmV4xiJ6djGH3O2Bet0JQRcUsWh11TJyx7pSXyhPd40NPcb9WBZSPfjGdj8gXhK95vX0h1JlwZhfW5PkBHaPE57SFzQ818dOp49irUiH2wPunFsicISKGZ/rMyBrsCVcf0Rf31Zg7PSeajG6IYjq3jhlJgARIgAQSnoCcWB2MdoUmY3HlTbh36wauvDyFY4U3YkqhVvjlgpeWBs7nFkmzkuKb3OHh4QGPRwdxqd15/FliHNa4it99GZ7Dwv+LZiKhsAw3E8ndC1PXOsDsZwek7u2DrDuG4eeVwzCg4nyxinoKM5vsh8eSZ3DzOI/zWaYLr69nvmwm8rlpBt0KCAxDaFgspjIGupqwUIVfWNTYmwaqmtWQQKIRiPE1ONGuzguRQJImIIItz16Jo3NnYE6fWqjgKxorVHrcCzdBr1XCzbqdqWrV7smePViauiYG/Zgd9jdd8ChtCB7UK48NWn37r/FieE8oB8u0LdBp/Ufgt2HoVEG4UYcZvL5rhZErfkHTtFqFgo9i+1AvpJvVEfXUOrfp2qLPyht4Oqw2Kg6zwMMSg7FhQvnwGWOt4rruSnWmhy4ZUbJzNi0h1woZCjmi7K5HuIfqsHr8Bs9LOUYXEB2cUDZ4L24+F6qydhlgmy0Qbt7+4vKiQx/d4GqWBbntvPFm6lLMa/sPbhRSd0bXFjIfCZAACZBAwhK4gl1d1+DWlLO4PKRwhJlHIRT7bS9OmtVEhl83o+u53ijztUZkLIeyY6fif7ObYs6hIejYqQCKlPDD3AeuUH7MoKHB4o+Am/fwpGbzSDMR62aLsVh+5DVezEa/No4Y6/Ij7F36YLtfPfSvnUmMUXYo3KIs0nV1xqX51VFP+jEwYAoODoNpKhOkMo1asatnAN56+OOjfwjuvRRjuEh3nvrgw6dw5wKevkHY9cAHH1fUwfOwQBR7+ujrrbKwRHvzzwE+6qULV0nObmmBHGYWyGIhJmwjzgu5EyYRTQoICkNqC64TfR0wc3xLAhQyvyV9XlsHAtLJzATMXHcLp9+kwacyddD+l74YWUJzoJJOZoZhxE4PnC3VHrPG9kCnPJYRdYtZ1GvjMXS6Axqv64wa+j7x5sVRfPgaLB/+paY6ovjSW5DilCp1uoALndQ7X/oWo0S+Lui0Rny+lEV93LwuWlwQH/W+6lsMSOVn4Y/TUQ7Gb0eoM336JGabY1JnSivUmTx9hYVMGD4JHwwmYvCz0L5aamtkUD7Cxy9UvEDkQvG6aeG2fBMOVGsJp7+WY1LTKXj28DcMPtAEk0/kwqd5tdBhtTdchQJWWPep2N+vdKyqWNqX4z4JkAAJkICBCYS54vX7VMiZP0ukH4HwK1ghbYGsyHnlDV4LQadMFNkrGMqhrdhbqg0aZ41Z6JFmIpUa5cXTPc64NdgBxSObfRsnN7+CQ6cyMZqJ3Ph1AY4N34Pr+cTA/VIKWGKM0ncMj7xWzBthYlXSVEuYfOH6CY9e+uClRwDO3RY2ohHCY8w1RD8aJITUAlY6TqSKuNvrxUed1vvJ2ezoaX7mLBiQNTuO3pEWq0A2awsUy/XZRlZRQkW0CIi+aKskR6+LR0ggsQjE/IuQWFfndZIPgeCbuDWjM/rWFWqbZaqiTPvR6L/rQUTQ45i6KX4Nn63B6sHN8FPlMij9fSMU/3URFkeqpcoydDITE7kEOaaL11shPpqJAV4JDJKufaKnMKkSJd8+hID/03xsdjqCpT80R4kX3bFsZCa4jP0Pr//XEx1dBqDbulpoe0J6622Hrv+OxS9nwmeFo1fKIyRAAiRAAolBQDGthBa9MuLYjFlYePNDhGpsMEKvL8ac+ZegDP8R1eVPvPCefmLgBCx7IoWjR/hvxQi0aT8Ri/5TlxGTw4un4c+g1uhYL5vIkw6Wv4zHn9eHCRXX43gotHKBN3j3e3/0ch+IGT0dtTRoxOSwtrOf0tXRyGw/1h1yV5mJ3N1+BX4dqqB8FIFX1ht7kquUmsn9QyAOXXiDPzc/QLcZV2DS9iAKDnVG/bn/oeeaB1hx1V21OqlZ5mvbL977IY2BhT27VOHC4/YbHqi3/RlKrnyAVJOvou2Ke5h+4IUQwMX5sPAVVXX7lNCo++rj/CaBxCJAITOxSCfr69zE1R6dUftVDXy/6CguumzDwS6pkG1WbzTf8UYMCDGk139iUrNNWFn0V4w5eBnX9k/A6kKncazD/zD3XUQJOpmJAVzCHNLJ662wCM1eMBOs7z9ROfiJ0pKnV3HVPD+K5o2YvRUrwEXG7cD2i2fx/p+uaHVuRLizn4ZW8Dh3Bcfr1ERTaxMoNnXQoOYTHL/wLPbQKlEuxh0SIAESIAFDEzAR+iTZpm3DhRpXsa9ZAWSysxNOdrLBouUuHGq0FUcnVggPxeXpjP1L12HtFbmqVhgl1+zHmQoXsbe5ukxpOGwrjqYnp6FvlojXTKsWGHBpNvpcbI3K2WS9ZVDoZH2MPzEaTdNp9USYiazqfhkOq3ujXoRpP6zaineFerDrnQ+Z7SqhkusorJ9cVSczkdBQMakdkbw+BmHLiRf49a/rcOx5DFn7nVQJlEO3P1EJlOp8Se27ZJpwSGfffIrStC2vP8E6dbgA+v7BJjxxHoO3d1bD+/U5BAd4ROYVARQREhLj21hkHm6QgKEJGFjxwNDNY31GQeDNPmx3LoVuR39Gx/zyxy49Mtcdi5GPK2DCrot43Lw5HKJ0RKyDHd+CBfb9cahnNTipzpVDqV5D0Hd7X4w4+Q5D2gqnOionM12xKiYnM8ukk5lGGGwXk5MZFzyVTmaCIpzMrKeTmSj4Y9iJ4vW2e74o6kwqr7cNpddbcW8r1kRbYa+z+0V7OOUJH9gglIVDTx7FtpIDsTtbDNPKamc/qvvgDznsxahyG0O7eIgESIAESCARCYgJwjJTD2H/1FiumbU/Zvr3/5xBlzLSEtO+C/ofEZ/PJWPeEmYinZ/eQecoZ4WZSJVZWPZCfKIcj74TIoRKM2FTqU7nb7vj2FVXHLvhjjNvI41b1KeN4ttW2GV+CgzFLf/ozoCqOqqicCPw40uEhX6Cn9tV1Ud2zNIqL3KXGYJP/qrlY6GNFG7sEhgYDEvLz7agRgGBjTQ6AlzJNLpblgQbnKkQCqV7gNMXX4V7WFU18QUeXAMyOuRFjmhNFj9sBRxR+ek1HH7xWfHSxO0KrrzKjSIFRGAt+MIjViczz3BbOpkR86qfncyIXU0nM/Okk5khmEAnM9HugOqAUHm68Ns8MWhLjrp5vVUcBmJ0m3OYN/pvbH4ry4mB6/oEjF2UB7WGNYvmEEKGM3kT5T5kgF3Z4qh06BC2+Cgw+XAUB04UQK2K+cDhLubbxKMkQAIkQAK6EwgSTnGkCqxcrZTqr1WnumDiwZdGK2DKnlubmuKJW8wCci6b1AgO9EZIgFs0SGlsHFXHJiw+AKsfZ6DjmA3YeMAFXr6f6+IKZzRsPGAgAlzJNBDIFF2NRUN0XHYR94e3h8PZ9phSR4RR3rAZU6yHY/2A0kJ80U5ihvH7aVjUsxcGtGyPmu2FGkyGM9i17DGuDZqKHeWli1U/OpnRxmbofW9nnNq5CwcrtBOxx0QENB283pogO3KMWwfnGSMxstFyzBKu7vytS6PUlLlYWjG9VguFEHl9CoYdb4kZ+0uFq1lJy5u6f2H93U7oWXMH5kvHPz2E45+q2mW1quIuCZAACZAACWgRCBYqoOZm4eslUrA8dMUVc5zfaeUy/t10wiHCO5/Pk/KaPbJJa4pPnm81D0Vup7GxF7aaoZi956bq2LpzjyE/wAH8WDwH+raqgJplRdgYscIZEhIqvtUaSpFVcIME4kzAROhpf1ZWj3M1LJjiCQTfx+NlYzB6iRd8s37CE9RA8wmDMaFSNi0vdWpS4rF7vRP7pszCqPvpYe/3AefL98M/o9qiaQ6pzuGBtxMqIF/wKrhP/V4o4Gqk0C1Yab8CxzZtw5oKwmBDOB2688d4jNvjirMlO2LB+PKw6TsE0/tsxvF0g9FgRDF0ODoWHcPWYGGtjTg1bxM2J6JQIx0NBEbYQlgIl+Mhwp1C2ggjfhkLK0D5bCdhJlSKLMWMJRMJkAAJkAAJkEB0ApoeYR+/9sXaI8+x7uw7PPwYrhIavUTiHrn2ewWUcsgIExFn1BDJzNwCwd8Vxprz79Dl2JsoVfbIlw5LOn4H98f78OHVkSjn5E7B6nPx1tUTOVovinZO88CAukXQsl4JVCtTUHWYAqcmHW7HlQBXMuNKjuU+E/Deg209JqNf9v74Z58UEoMQcGI8Jo9qg3LN5+LYYO3wFGIguDwMg/s8xX995mD7/PJwUO7h/uKRGN34NI4snY0FTunDnczslE5mvo+w24y45JeczIyT5wOgbG4IB9tB2CmdzEyVTmYGYLN0MgPpZGYqJkgnM1WLx1s980uxtNRgPgnbiYevfNS7qu+SYuDxDg7GQW8hjItZQ3UsrCiZxI5mbCztc3JfBmlOZ2DvdTFdh8dIgARIgARIICkQCBXhRmTsSn+hDrv//Gss2P00SarAfoyImwkRAxMa4UniynB2BmlCBJx/Ft0Le4tSmVTnAn1fqb41/0uXOdzjxaXbrzUPx7i94PAdyE+5vLbo0agUmtQqhmx21ggJFZG8U3HiO0ZoPPhVAhQyv4qIGWIn4IegdePQ1mIEzv/ZAWVVT5QFUtecjcm5xiGg8V+Y02QJphXQfNSu4Nj4szjWdyMu9ygYGfD5u4FrsN68Juyn7kbXrZ1QJok4mZGzpnK5XzMws1qAfCcCM8tYWq+FrcRzV/+vxtNSNtbHAS9PdHbVQ50nIlhzZqHG4mSZBlbi+zvxHZMgygDNsT+tPEsCJEACJGBcBNTCpYcIN7J4t1D3TEKrljGRvHzfC1VLZkZ74axHMwZmTHl1OVYuXbjRkWdAdKc/DlnDz/l/uButqrQZCqqOTV5xOtq5Lx24/NwTlxceR2/xGfuTE376oQRKF8r1pew8TgKxEtB88481I0+SQMwEAuAhYkKZZMuJ/FGeJmF3maMAcodexxU3sXKpKWSKgM/vnqZBztx2Wqq0VkidOyvyP3+vCvjspHIyUw9FhZOZIrN6onV2UafaycyimJ3MvFU5mfkHN1TOfizCncxMFE5mhpQV6rIRTmbmxe5kRtPGQ/b56Vu/KIGZnR96J65aTpRgzd7RbsOnIsXg6xsK50fecMiSJkqA5pCQYGFjQZc60aDxAAmQAAmQQJImoF5Fu/X4A1Ydep4kbC2rZk+DgtnTIa8Ya3NmDo+vUs4xYyRHq7TmsM9ppdpfl98e6yLPRN9wE1pNrkGf7SzvB/qrNJw+hIXhov8nvBTfZ8S3dYTWkgxXop1yZzRHgPcz7cOq/bSZiiIwMABXXnjFeP5rB6dsuwr56VDZHm3rl0CjakVVRYKFFpY5bTe/ho/nBYEoYgGJkID+BDIie8Pa6NjjX/TdkxMLGztABB8BvM/i0tzNWO3YGFNKSrtJ4cl00knc7tkX3fJUQt1OXhjxzxIszNsP/QpZC0vEYITd+QcrVnnjZevaqoDPieVkRj2Qqft+56k3Lj/wwrnbnkh0gVLdCD2+heYs3guHAC33v4ws1ds+PYplS4N+NbVmIGWwZlP+2UeC4gYJkAAJkECSIqAek28/8ca8HY+/SfzKpo7WKF0gg0qQlEJkdjuhPWQbEQdai5a/CC0iV1ut0ug3tmYWK53yEyiESakvVTRixVKr+sjdrT/mxv33/nghVnSXPA5XnZXC3iffqHaasoBZ6swwt8yA63dfRZaP64baWVC5vKcwvnt1CptxBZkCy9HxTwq86Ybv8kf4Hv4N8xdfEvETgxAmw1MpGeFZoz2mDeuAVtmFIx/3hfij5jYcnLYRJxoJT6bCWc/NuTMwZ99d3PINb5G/dSHk/KkfFvSuDAf9fqv17pLmaqV0HHD1gScOXHZN8MFMqsuudn2vn7rsV3qnFCsZo0OABd9nFUJmTlVg5hB/D1hnE4G0c1aOrE0a9ks1YM5IRiLhBgmQAAmQwDcioFaLvfHQK1GFS7k6WdY+AyoVtYVjrvSQvhM0kxQiLc1NYSrsQb9VCggORWrzqJ5fPwjbT5u0ZvB+fQ5er05ECWFik+sHZLJviGGzd0V6ljVU26Xdpqawaah6WU/yI0AhM/ndU/boCwQ0BUvn/9xw6Z4Xdp5/m6iOAwwtZM7LlAUDs2XH9AMvMNbFPUrPr3d1RHGhtvPEeYwqQHP67FWQ1bElJiw6hNDQUFQsmVflujxd2nDX5RQ4o+DjDgmQAAmQQCIQUI/NiSVcOqQ3R4fvs6FioYwo7WgbZYUyJmEuERDE6RLBYgXUTMi9JibhjnlkrMwA7yf49OExMmQti9Tpc8Ok1rQ41a1LISlszhpYV+WRlt5odSGW8vIk8HpRygPKHictAmq1G9kqqQa78+ybJO80QB+CjqnD1Xeuv4tuq1HAzhJBfu9VAqas08qumCpe1qTNl8MvIWwtZJKuy+tW+S5SBSYwKBiWFrTjDIfE/0mABEiABBKCgDoUiZcw95AOfSYe/GzyYejrSfXXasUyoen3OSJtJuU1pJd4zaS9Wqh5Lqltm2uFOzO3SA+zzCWRPktpVVODhc3nhpENsGb/Dey/GV2lNr79kU6Cqg/dqLLZHPpzVZWDoKDgEFiYU7SIL9vkUp4rmcnlTrIfMRJw9QzA2qMvEn3FMsbGiIP+6+rixidfVHz+9EtZ9Dr+pKAj8qdOg1STwwVGzcKh45xUajRujzarDhf4/g+89/T7YrysPDZp0Kl24Sje5ILFgGHOAUMTK7dJgARIgAQMQMBPeEvdcOw5eq55YIDaolchBcsOwi9B9ZJZIlcr1aum0XMnvyOaq4vvPHxw8tLDBBM4JT3pjfaX9lVUoU9CxSprKi0hOPkRZo++RoBC5tcI8bzREJAzkubCbkKmQxfeYNPpNwluY6kvHPcVtfAuLBjFnj7St2iM+X2FZ1lXzyAU/Duq+3JNe0w/t6tIY1MYOUv2xq4TN9Hsf7tirEvzoFSD+bVtBTSuXhxSnZazk5p0uE0CJEACJBAXAoqiCPVOE0iTlTEr7hjcXEWqwvb5IXeUFUtNjaa4tDk5lAkJEaq1ZuHvR1Lg3H38Fv7dex1yNdKQSU5Wj+1QCb1aVRarxMILrZYdqSGvxbqSPgGuaSf9e8QWfoWA2llAcIiCVYefYPXRlwYfuL7ShG92OjVM8VjE59ROVR0zqA4FfgxXP7LKVFy1r2u8LDnwtPvjACA+mrOTmjOj2tfkPgmQAAmQAAnEREAt5Hz4GICM1mlw7+VHg47TQ6pkQ4tqOVGlhMq/PeSKpTqZpQoXrtT7KfFbLWDKvmfKkE4lBEpB8Nq9V9h25D9VqBJDcHnxwV8VY3PX6XuY3L+uSoU2MChEmOBQ3DAEX2OrgyuZxnbH2N5IAupZMqkSm9D2HJEXjWFDquTYWlmgsvBMJ1Oh3OmRPsKVuUMua6RN89kjXIBQIUmtgwrJbT+/yCu5+IW7370qYmi5CY+w6yP2f7JKj635CsToWdZnWHFYmHzC8wsTVPXkKTsailkGpK43K7JefTdkrCy13YW+ZZmfBEiABEggZRIIDRWqk0LQ23jABSOXnMR/a39BBitLNBt/Drse+MQZinrVsmOdPCp1WK5Y6o9SfW/8PgVh3b4rBl/dnNm5Mvq2qaLSiNK/dSxh7AQoZBr7HUyB7f9WwqXazXmR/NaILW6WbF+gWFXVN2aW9q1Ux85KHRGIWfO8vwiO6SMEzqwWFiohc9+9D9AM1CztMT+6XsP7u6tU8bLyVRiripdVuu9KzWritE1hM07YWIgESIAEUhQB9eqlVM8cNnsfZLxFmVpXyI91U9tBxsEs9dtFvZnIsXhAk/xoWDGnahI3JdlZ6g1LxwKa/hf2nr6NSctOGUyVVprfLBndhKuaOt6L5JSNQmZyupvJvC9qtdjEWrns6pRJtTopBUrtFUkpSJqIFUmzVN8ublawsG0xF7YtmunWK18EiVljp7zWeP9gKz6+dYY6dImh42VpCptUo9W8C9wmARIggZRNQO05Vr16KdUoNdO1xV1QqnAu/Ln5AYZuf6J56ovbUrgc28YB9SrmUOVRX+OLBXgiXgROuzzCP9suR04OxKsyUViuavZr+72IzW1GW834wjSS8hQyjeRGpeRmqgeShBYu5QDWrFJ2lBexs9R2HZK7euXUGO5BoLBDsYww7pftlSFMZLJIkynB4mVpCpt0EKTCzf9IgARIIEUTkOqXvSdvi1VA8T04UjAyRekBJ/HwY/AXeWkLl8arFusLn9NrsHXdeqy+2hYTL/VHjajzxBoM3uHtvyMxbvFB7H5qg7TVW6Dv2BEYWTYjPhcJRtj1hZg5fh7Wn/bHM4caqN9zFBb0KoUskTUFIODAUAwZtA4rzBui0x9TsaBRXoQHPxOZ/I5ibeNFuD1rLaY5pY0spbkh7TZnrz4T673UzB/b9o/Fc2De8CYomCcT1CvdseXnOeMmQGto475/KaL1/kFh+HffE1QZedbgcbSkPeXm3kXwflENnJ5THb+2dkSFwuG2lWq4xuQdTVPAlO03T20Hi3RZoYhRyXf/COyZ1FwVF1PdN0N8SxUopz4rMXDqdnj6hMfrlKo3TCRAAiRAAimHgAxbIZMUSoq0X/BVoWThBmekS50KyweUiBGStLk8OLiEamyWq5dSuJTJOB35iDFxTXPk63MELt6ueHn9JdyUGLstDnrhwx+N4bAwI+wXXMer97txuOJl7KzWE2NuqmNii8LXx6NTlW0412gTtrs/was/8iPHuB9RZ84tRK4bv1uG8a3vI2T1QwSsyAzvdlOx3FXtFMkHn+aPQt8sXdDnCwKmbGHpQrmwVqg3y/cHqfoanyTjdTr8/LfKPlc6I5KT+EzJlwBXMpPvvTXqnqlVY2UokimbHhrUC11MsbOMd2ZU99usOWsoZ5lPXHmIw873seDwHd0r0SHnkv610LFRGWErY6lDbmYhARIgARIwdgJqjaN/tpxTeRfVtT/3V/eGY57M6DbjSpSQY0s7OaJ9rbwqm8uQUOWbmqbo2hed8+1vje9a5MfkT3+gVUxLPS9nY8B3+xHmvAcLI4U/T3iM+R65707CjR2tUBC3cO6HWuhQ9RDuji+NNKqLC8Hz0gD8WMMPPzxahiFSq3hTI6TZ0RdPNjZGNjyGS4MaGN7FBSfaiLXOF7PRr7QL8risxqh8unt//ZIKtM79j8g4oG4RTBvcSHieTSXCq3x2kKhvPcyfdAnE9Hgn3dayZcmeQKgYTGTy+BCoGnTqz/3PIAKmnBGd3aIAHs2ugp2TKqNVzTywzWARydM4Z0Yjm6/ThqYLc+lOvFG1opg/pgXebhsIKRjGd4ZS3YjeC4+jRp9lkPYcMkkVWiYSIAESIIHkSyAgMAgdx2zQS8CUNDqM2ww57k/vUQxynJahSKRmUY+GBYTtXrhi6Lf0fZD4d0yoDR/ehUUOzdAxUsCUrbCFXbNaqLx7D/a6ASbvj2Dz8ZJo8VPRCAFT5hG8yjVHB4sd2HLsndgX6rRv3kPJllGUlmeFJ/xcgKuH9F7/EDd+XYBjw0djkB4CppysbtugDO5u+EVlYykqinOSE9ytR67Fszdeca6DBZM2AQqZSfv+pKjWhbvSNsHj177I2u9klFnNuIKQq5ZS3ebB0toqVdg8WT/bHKQEwfJL3DQFTnXMrEur+uHU7LYGUaeVcTarD92oUqENDg5XzZGDExMJkAAJkEDyIvDohbtqYlHtPVaf3l154YW1ey6pQpA4//E9/vylFDIKYVMmc/OU+Irqi3d3X8CscjEU0wZZ2AlVUj3E7cdCGfbBbVwyKwYnh8+T5TK7YlIQJeqZ4cH9t0Jl1gymmTIC7z3hKc/BB+4vUyF3Divg+GR0PdcL8wYV1xBStS8YfV/97mBhboZhXWvh4eo+kHaWcU1Sfbb2wFWRk9Jqleu41sdySYtASvwLTlp3gK2B+kfl6WtP+IhAzfY5rSA9u8YnydnQ679XUK1aatpymGs4xYlP/cmprKaaSuVSBSJXN8f+5IQ8NuFKOHHtr5yplLY5Ur1GDk5c1YwrSZYjARIggaRDQD1pKMNdSCFBTizGNQUKuzxpIpPFNtwdjTH5QYhrn79cLgR+fp9gYmmOqOKjKJHWGhlM3cR7krBj/OgDTxML4egvak0mSIu0tqbw9fUXLpWECmqNBuixZz7GX3CDifMsTD1bD00q3MbKbqeQZ3k31HcZhu55rGBnlx02Df7CQW/dJoPV7w35c9pi34Ju2DCyQZzfF6TnYTkpLVWtUwmv/YFB1H6KeleNd49CpvHeu2TRctXqpfhRkT8u0hi8dv9lUVRn9O3kxPq5Vao2cja0WAGbyOLfdNXS+wxOT2yNjjXKoXjt1qg6bhtO+Hzth1youdyej2X9fkSjMmVRul5n1PpjD85pltOl3rfrsbZndVSt0BSVp5/A7Si/3W5wW9gKVf+5G+kkQM0ps40VJg/4EXfWD1Cp0sZH2JQDSLs/DkRZ1Yy8MdwgARIgARIwKgJhwsGPnDSUk4eNx++AdngSXTsjV8DkSlivVpURFkoHMOHcTGFhbg4lMBhBMYJMB0tL8epuaYk0SpCIyR1DJuHpz8LCPNwLbe5emLrWAWY/OyB1bx9k3TEMP68chgEV52N2tVOY2WQ/PJY8g5vHeZzPMh3tx50Rbod0T6lSmaq8xEoV2ovLekJ6m49rkqY24xbsFzaaZpFOnuJaF8slDQIUMpPGfUixrXD74IuGA5ZH2nFoqs5Mae+gMxe1cDmhS9FIVZtU3zCGZWTDg0/hSLeh6BQghEzhSe/m6nYY5TkHbfusw7mYBgdVQWGTcXkYBvVwwcnaUzHv4kVcXvADer95C3e1+pBO9d7Hf+PnYJLjHOw82ge/npuEAQddhcqMTOL/h3Mx9W97tPvpu2jq2e+x8gAAQABJREFUMnLgkMlCXE++AEj7C2m3GR9hU72qqbbV5GylCjH/IwESIAGjISC9gZqKiWEpDMjJw7gmOZ7IFbC82YU6p0jmQv2SSRJIj9yFcyP4+n1hNamVHl7F+aDCKFpQaBg5FkWFYKE6+zyqcK7gCe4cDYRDoewRK6HpYd1sMRY/+ICA2+uwxHE3RsxyxNjpP8Le5Qi2+9VDy9qZxKpnXhRuURbp1jnjUvhLgtbFv7yrVqHNkjG9ygttfFY1p2y7qnonDBTSs4y/zWTcBChkGvf9M8rWq384pJpNhe5LIXXyNVOXuUfg7umrcs4jbSpjSzEJl0lH1SYQ2DYRIwN6YOXklqifXXhbzdkcDeeNx99vl2D47rcRAp9WD4NPYMewa7g9diZW/1QK9sLrmpljR7SZ1wtNVNqrOtbr54wTB2tgcG8n2KX/AS27pMK5Qzcg3QFAeKa7MukUnMf2Rx+7L/8MqAd+S6G6I4VN9cqmVot13lWrxcxacTx8tpKDiM7smJEESIAEviUB6UE2OCREpZUihYG4JOlg7urfXVTjiQx1lXTG67j0JiHKCCXZGjXR6soxER9TcybaHyEHjmJHxZr4IYdw8JO7On60P4d9R55BUy/K5NEBbHteDXWrZI+hcdGd/ZjEoHIbQ0GdDpmamkSuah6b3znOtprynVA6BAoMopCpE/gknOnLb5dJuNFsmvESkKFCpF2enAWNTc2m/x+7VGqzs3uXiLGz0mZT2lxqrlwmtcFKwVNcO+AOz0Y1UV1zkta8Imo1fIcLB6/hRbTeiSlE52VYENQUg+tl0Qi6/DmjzvW6v8RzcxtkFjb+IrIYYGOLTK4ewgGA+OHeNxaDfLphbsvcYgbz60naScgkXY1LYVN6pJU2m3FNw1edU81WuntLL3dMJEACJEACSZmANG2RHmRbjVgX57BXMmTFicU9VHEXZV/Vk5hJud+J0rbgGzgxcAKWPRETyCIphQdiZl8XzOg5C5tfyWPBUC5NQO/fLNB2WluUUeWqgKZLGiPDsCHoffQ1AuQxr4PY2GchDg0agRGO4c6TVFlV/wlRVNvZT+nqaGS2H+sOuQtB9Tnubr8Cvw5VUD7cqe/nonpsqVc11baaMztX1qP056xS0KzZ919Ip1JMxktAl/dL4+0dW57kCLgL9Vg5SH1tFnTzxadwvvZI5QRIxstSJ3Vw5uUjyqJogQyqw0lNuFS31UR5iocuGVHyu2xagpwVMhRyRNm7j3BPnTny+yO8XVzgXDU/7Pf/hslta6CWU0WUa/IL2qy/DVeRT+d6M2RBttAPcPOVlYsZ0Q8izlbubMjpvxOrJqRG4Qlt8L2m8BvZhi9vqI397azTqWw25Yx0XD3LyUFErmSr1WfVDqC+fHWeIQESIAESSGwCUvsoQKgvyrFbW/NI17ZIFUoZMsvCnPEQozHzdMb+peuw9kq48yQTZEee2btwtvQ2TC+eTTjlyQbz9g8QtHotllYPf++BfKuo9Rf2bciO0O6FkNPODpkKDMeUkstxZFoVhCsha1wp+ChWdb8MBxGXtJ7an59VW4w5WA92vfMhs10lVHIdhfWTq0Yvq1GNrpvS5Eba7koPtNJrfVxMbaQzKelUioKmrtSTXj4TRaSk1yy2KDkRCBYDlLlQ+bx27xWajdqkl5OAD3uHI4OVJZqNP4dqxTKhT2P7iODMwvFAhN1gkmUVugUrHZZg/6rd2Fz1c+gUVXuPt0atAaXQ9+YYrWDMbng5thKansoD3yIt0K9XK/QoawL/w/OxZMoZ7Oq7FpdaX8Cqgl+vt6XpLVzt3BXtii3BhV4vcaDdXCz7ZSm23m4OB6/FeDDyA5x/mYRpd8Lwyboi6syegtlOGWJcPf0SY7kyLe9DfIMzS/scuUIq7TSl0T8TCZAACZDAtycgBUyptijVF+MiYErhQqpOFsyTSaVKqV7p+vY9YwsSk4AUFAfN3B3vZygx28xrxZ8AVzLjz5A1xEJAzmRJAVPaXzr1WamXgCmr7fX7VpWXsZ2TKqviXFpYqIMzG8GjK2wdzC2CId2zx5RC0gj349HUUkyF1z7gpmMfbF30CwaXzQorZEHmur9hXPdgeK8+it2mutVrgqIo87/+GP3gVzStuxwLa07Cmu9W4PfVDfH78O/gP30kuuaejZ0uF/HfmHe423sxtorwW/okKWCqgzNLz3JSHSouSe1VLlR4GFTb7MalHpYhARIgARIwDIH4CphSy0Xa8UsBUyYKmIa5L8ZYi1Sf3TKjQ5zeEaQvB65oGuNdV623G2fD2eqkT0DTC520v4xLql02v2qlTK6YyZTkVy81OqmYFoB9KS/cfeqh5eDHH0H378G5mD0KRxMy0yN7wUyw8Q5ESJQFPeE0KFcu5Hr+Vrg1L6ljvaLyfF3QdelJnLm4C+eG2+DtxAhnPzZXcG6PHarWKYVsMpZWtWZo5n4Rh+6G24RodOOrm+oXB6lCK9Wh4qoaI1WopToWjf2/ipwZSIAESCBBCcRXwJQ2+9J7rKV2IMcEbTUrT6oEpPqsuZhBl+8IUnNJ30RBU19iSSO/ESwHJQ1QbIV+BOLrhU56oFPHz5Ie6IxJuFSTMkEBOFUzwdPjF4UvV810GxcOm8GhihAWNQ+rtoVnOeE9ru3ts9j9QnMFVAh/r17hbEkhmAp7Df3rFRG3tJz9mCipYGlA+xi1bWy1MgVVs9dxiZdFY/9oDwQPkAAJkECiEpDjd3xUZKX9pYyzLM0fjHHsTlTYKehi8h1B+l6QpjF7JjXXu+cUNPVG9s0LUMj85rcg+TVAzoDGxwudnAE9+Xf3SBUb4/VAlw4WXcZj+dP5aD/zLB6qvJG/gfv8wRjt0xEz2heIcAj0EX67R2Pg/pfhHuIc+mBY80tYNGoFDvpIk2nhWe7OHMxckh61utQSSrCWOtar8Wx92hPF2Y9iUhxODdxwVATTfie9zZ7eiZ2ZKqBeYbFiaoCUJrV5ZLwsfaujsb++xJifBEiABAxDQAqYcvyOqw2mFB7aNiijMqOgfb1h7klyqkXtqb5RtaKqUDb6OgTSFDRpWpP0nww6/kn698joWuj3KW4DlPyxWfhrfcgfn+TjAEYIic9WYc1vS7DwTrBwE24Gr+9aYeT0AeiRR6xaiqTgAW71bIHyqf/E/QV1kUceFC7Nb0weibF73eBqIhz/WJdGyb7DMKfVd8gsz0sF3K/Uq8qm+s8TXjNroqjvYlz9X2WhHhuRvPdiVzwd/6iriulb2mpKVVpp8N/+t82QwqM+SdNhhD7lmJcESIAESEB/Aupxt+GA5Xo7aJG/1zunt1GFJ1E7+9O/BSyR0gjI9wNpbymFR32StPfd/EdHVVg1tdd7fcozb+IQoJCZOJxTzFXi6kFM/mDMG95EtXrJASr5PS6f/AMxas6+OMVXkzPjcuKBz0Xyey7YIxIggaRBQDrpMxXxkGUM66+FGNNuMScEtYlwXx8C8RU0zc1NRWicKE4s9Lk88yYgAQqZCQg3pVUd1x8K6ZF0+pCGqh8Jzkglz6dGOoGS9hj/bDkH6UlW30RBU19izE8CJEACuhFQT+BRwNSNF3MZnkBcNeDk+6N0JqRehTd8y1hjfAhQyIwPPZaNJBBXAVMdH1EthERWyI1kR0Aa/Et7DBnOpv+fB/VWj1ELmskODDtEAiRAAt+YgPxd1tcLPFcwv/FNS0aXj483Y+nHQzqaUk+WJCMsRt8VCplGfwu/bQfkD4O7tx8qdF8aZ6FBLXx8257w6olJIK6TEjI8ivRey0QCJEACJGAYAtfuvVLFsdanNgqY+tBiXl0IxEfQ5CS0LoQTPw+9yyY+82RzRRm7Uro57z5xq14CphycZHgStZ2d2ttYsgHDjnyVgAzOfXFZT0hbXH1Sp993qRwJ6VOGeUmABEiABKITkGO4nPBrNmpT9JOxHKGAGQscnoozAWkuZWmRSuXQRz5j+iS5Ci8nS5iSFgEKmUnrfhhNa6Sb86CgYL3dnGsPTubiR4UpZRLIZGOFLTM66CVoarovT5nU2GsSIAESiD8BacMmx/BBM3frPUl8bH7nyBBj8W8JayCBzwSkoJkurQXkM6avoCknS955+IjwOZoxxj/Xza3EJ0AhM/GZG/0V5eBkamqCViPW6eXmXK5a3Vk/gIOT0T8BhumADNKd2tJCJWh2qGyvc6VqQZODic7ImJEESIAEIgnI8FIyhuXUf4/pNYbLCtb81pRjeCRJbiQUAantpK+gKd8NpGadFFTleyrTtydAIfPb3wOjaoF0cy4HJ+mFbv/NNzq3XTOmkc6FmDHZE5CTFVLQXDu1HaTxvq5JPZhIdW2p8sVEAiRAAiSgGwEZv3jjARe9Q5VIuzfaxOvGmLniT0AKmjL2qj5JvpfOWnFc9Z4aHExBUx92CZGXQmZCUE3Gdco4WvIPWJ84WpoCJkOUJOOHI45dk4KmnHWU3uH0ETTlYNJ78jbIFVHOWsYRPouRAAmkOALSDrPdHwf06rf0BK/2o6BXQWYmgXgQKF0oF+Tkhj5p+KpzOO3ySIRNY+xMfbglRN5UE0VKiIpZZ/IkIN2cd517ROfOUcDUGVWKzqgWFOtW/g4hH31x5u5bnXjcfOmlyi/LSffldCKlEzZmIgESSIEEpK1aQGAwGg9dizfe/joTkJN/w7vWgvQEb5aKfhR0BseMBiHgmDcLrJQQHLnxUuf6jl96jHY/FBOaUuYq8y6dCzKjQQlwJdOgOJN3ZXL2U8Y31DVRwNSVFPNJAlINW72iKZ8dXZNcVZeTH3QipSsx5iMBEkiJBKQmkbTDvPzcU+fuy9/iMT1qq36bOYmnMzZmNCABaaY1TExyDKhbROdapUnNsNn7VJpOVJvVGZvBM1LINDjS5Feh9CTr9ykI7X/brLMXOukVbN7wJkJwSKUywk5+VNijhCAgBU35vOnrdVa6L5eTIEwkQAIkQAIxE5AqhPqYushxfNnElrAQaofyt5mJBL4FAWmmFRwciulDGurljX7ducf4Z8s5qs1+i5sWcU0Kmd8QvjFcWqrHSJs5afum6+ynZpgS2mAaw11OWm1UOwPSV9CsPXCVajKEjoCS1v1ka0iABL4tAfmCLieKZZxhfZJ0upLNzpoTxfpAY94EIWBungoWFuaqxQt9Qpv0XnhcNQEt/waYEp8AhczEZ25UV5TqMXImSM4I6ZrkwCS9gjGRQFwJSEFTDihyFl3XAUWqx6gdAVE9Jq7kWY4ESCC5EZAv6KPn7tVZE0n2Xzr6kU5XmEggqRCQvhvku+XCX+vr1SQZC1b+DfC9QC9sBslMIdMgGJNvJdfuvYKcCdI1SS9gHJh0pcV8sRGQA4qcRdcnVhbVY2IjynMkQAIpkYBUk11w+I7OXZdxi3u1qqxy9KNzIWYkgUQiIL0c6+uJnmqziXRztC5DIVMLCHfDCUjVgk/+gWg2apPOSGZ2rkwX5zrTYkZdCeg7c6lWj9G1fuYjARIggeRIQHqTleO4PmqyUnNkybifECriD9PRT3J8Koy/T9IRkHRGpY+DQPle8M7Dh3G1E/n2U8hMZODGcjmpWjBqzj6d1WvkzKf0/iUHNXr5NJa7bDztlDOXchJD1ySdVEkbJMbP1JUY85EACSQ3AtInwqKNZ3Uex2X/1/zWFOnSWiCV0CRhIoGkSEA6AlLbZ+rTvkhvs+I9lSlxCPBXJHE4G91V9FGvKZfXNnLmk45+jO5WG0WD1S7M5WSGLkk6qVq8yZkeEXWBxTwkQALJjoBciZQet2Vgel2TnMirVqagrtmZjwS+GQG1faa0HdY1SXMa+W7LhRBdicU/H4XM+DNMVjXExQvd+t9bc+YzWT0FSa8zcuZShjb557cWOjsCki9X0qaYiQRIgARSGgG5Ejnx7yM6d1tOFvdtU4XaHzoTY8ZvTUBGP5C2w/qozQ6bf1il5eQfEPytm58irk8hM0XcZt07qa8Xug0jG9CTrO54mTMeBKTH2bRpLCG9F+uaek/bTbVZXWExHwmQQLIhsPf0bb28wi8Z3UQ1Wcx4mMnmEUj2HZE2w3LFXsZk1zVJLad1+64gTWpzXYswXzwIUMiMB7zkWFQfNdkBdYugbYMywg4zLDmiYJ+SKAHpvVhXFRmqzSbRm8hmkQAJJAgBubojnf1MWnZK5/qlp056hdcZFzMmIQJyxV46B9T1nUA2Xe0EKCg4JAn1JHk2hUJm8ryvevdKXy900gPdtMGNIP9Izcz4GOkNnAXiTEBfFRmpNittkxiMOc7IWZAESMBICMjVnbV7XSAn2HRJciwf3b0Ofx91gcU8SZKA+p1Aqnzrmv5a7wwLczNdszNfHAlQOogjuORWTF8vdGoPdPwjTW5PQtLvj3yJkvaZyya21Nk+U9omqYIx06tc0r/BbCEJkECcCEjVQelVe8q68zqXl4HtpTdZ+fvIRALGSEAdakeqfOuapmy7qvLZIBdYmBKOAIXMhGNrNDXr64VOqsnSA53R3N5k2VBpn5nNzhp/9K6hU/+kVzlpo0SvcjrhYiYSIAEjJCBVB6ctO6pzyBLprVuGh6LJixHebDY5GgGp8i3fT3VNs1efEZp4nFzRlVdc8lHIjAu1ZFZGHy90ajVZqh4ms4fASLsjbYJ1DWvS/8+D9CpnpPeZzSYBEoidgJwslsHm5QqNrmnoz1VVsa1p8qIrMeZLygTk38CY3nV01nCSk8/SAz1XMxPurlLITDi2RlOzdPYj/9h0SWo1WarW6EKLeRKagBxUJvb5QafLvPjgT69yOpFiJhIgAWMjICeLpZ2Zrknt7IcrOboSY76kTkD+DUgNp7EdKuncVK5m6owqThlNFJHiVJKFjJ5AsNBFl+qD5Tsv0slJgFwxWju1nXAQECLsN2gwbfQPQDLqwD9bzqk8xunSpbfbBsLWOi2N/nWBZbR5fPBu5QIMuWgSpQemSIWMjbthwY+ZYYJ3eLH1AFaefYeH1sXQqmc9NMllIfLrUjZKtRo7fnDbcBa3G/6AGtZRr62RSWwGI/TGXvy94R5Om+RH3Q4N0a1YetEmkW4sQZ+/PeAtNmV709hXRPeeVVEpg5gTDjuPfZ2PYq3VZxWvdP6l0X1FA1T673O50NSZUKRabfRvbo/Msk6ZPpzEkrPfoXuDZzikVYc8nTYgO2pO7YyO2SPmnrWuFWZTQKOdIVAuHMLWrHXRKr8MBeALnxPbMW/3KzzI4IiaLeuhq6o/MfAIvoULv79G4Lh6qC5xM8WbgJxsc/vgi+w/zde5Lv4O6oyKGY2IgHQCFBgYjMLt/tJZbfzq311QvGB2qs4mwH2mpJAAUI2lSilgSjs1Xb3QzRraUBWTiAKmsdzhlNFOOah0bFQG/+69rtOzLGf7Jw/4MWXASUa9NKkx+Yu9UU6O0zpnjWxdxmJDF3E4dAsmlE+F1i4tUFSdK+wGnGstxayf+2D2jMLI83gX/m73G/rPHoeF5b9SVl3HucGoWD0tmj2fglE51ALlJ3isP4yT30shU51R+9sPvhsnocnV6hg5+Ff0D3PG5tEj0bD1/7CvsRB+397E5dKj4dIrpygohLfz2zCzzjU8OjoYnaxe4dKdohin2Rd19ZrlvFxwesc6dC6bFwOP/4z6UuD1Ool/9lujS8NKaLhGfGS5g7+gzAv1tdQVRXwrmtcSc9GvTmP/tN/QoslE7KiXBqEX92FLiVpCyAyA18yR+Mm0B5bM7IB8Dw9g2/xhKF1kFC4NsNLicQ+X287HpC5TsI8CphbwuO/qu4o5s3Nl1YpP3K/IkiSQNAlIJ0AynrZ0aNV4/A6dGilXM+UCCpPhCVBd1vBMjaJG+WIuk66xtGQMIqmGIAczJhJISgTUg8qsgXV1apa0WZK2SwGBQTrlZ6bkRkDERtv0F3o2GYyN3YrBXnjVNC/UAgN2OSBN+604qUN3FbEKen+VD+y6+WLD3jfQSx3o/T8YOLY4Js/4EfVyWAK5aqP1gmao6eqDT9GubQXrSq0xuuVd7LnqH+3sFw9kLINq3UZj/+jz6D3nrlg3jW8SQmqu6vhxoBUe7X2CwPA1V1WlCh7izEZH9P3VCQ5i4tK8cCO0XbwE1wfkR1Q58jWej1uGqe0mYLsUpuPbJJZXEZCaRdKj7Jpjd3UiIv0q9P0/e2cBH8XxxfHfRQiaECgOoRBcQrHiXqDFChQL7locStFSoPyLeyEUt0DxYKUUKy7BPcFbHALB4vefd8kml5C7m0suycmbzwfubvft7JvvXm73zTxpXVUzYSx1AAsxAQskQAmtZEuaULgYlTnj2EzTX2i2GEzP1CJ6pAdz2VVMuim1a1hO4yZrEYNjJW2SAGU8lk0CRKuZqZ1iPwLbJDQbHLQaz3B5WQa0buGO1Nrjz/Qtenx5AXtvR07Aae+K+14VsBNeR+qgxdRqqD5xHw7HFdD5WZijp/xxfkQtVNaWyVgPw7u5I532tqj3ZNBeP6pClkzGOh4JN9amddB7xSkci6df4zcJ4/zKC3zImSHWoSrkQakqF/DbUj88j7VH64PqI4LnjcPXmXrBu0Wu2Ny1xPit8QTIs2jtrrPSroEUr0YlS3jC2HjWfIRlERjXrYa0wiu2n2Z3WWla8oLG3rXke2ZJsyVA6copm5zsKqZSR8tsB8SKMQFBQEkCJJPEilYzv29bFRnTp2Zj0+a+PU9w95UbiueJu5bmDPcKobj9IBhwT6OHijC29vji2IifMN0FqFJvLKae8UTN8mJV0mALQdhdNQp66CkabheKh9uWwPO8I1Kl/oiQvX7w6z4Gu0sJo1GUdEv3cB+GDroF1+AIRMdjxh1KlB5qe3cUz/QPnhu11BoziOhzhYQj59NLWBrRDBtWFoATxDiixbIg79zJWPn7AvQs7A//Rs0wqEtMjKkqy3tcWTMTLa6nQ2jIA/yHAnCPPpbfJIaAkldBti6m9oQxh70khjwfawkEIlczD0uF0SjPBJyvwbRXllcyTcvTInojA1N2FZPcDegPlW5m3JiAOROgmfkCbp+BsibKNF7NlKFkpTIRoRC5IeK0CIQEGf6dU+Ma9i99hncnVqNdn2VY+uEjtm+7ifdxetP5UR2OYGG06WwRjsjTtDu8F/6AlQ3e4USFftg5pASyRh3wPk9dzJj9o9g/CktWiIQ/OgzMSPFQhCTCKzz6XP/Lj0y+pTFjRRvUjzehUU649fgFW2+uwYVOKnwYIWJMdzwHrQnbZ3iIf+5Vx+xV47DbZRV6bHlmnHuxTlC8Q8mrQJmzZZqyiskGpgwtlrEGAsasZq7xOcsJAU180dnINDFQS+lOdhVT+QOlmxk3JmDuBGg1k1YoZZoSmxkiYpq42Q4BFfKhXG0/7D0T+8FcE1u4OSsqldS3igmo7mzF0PTf4+9FwzWG3pR1XTBl4wHsljLmnODwZTpcP3A7jlH6Do+vPkdQrMvgAHXdLvj9/O8Yfiy2rrHE9HxQPTyI5WmK4ku9hqieDpRdLs0xevQV/Dj1Uhy9FQHl1RH2Hq3Rf00J5BpzBNfFmmfYnSLoO7qaWL38DIX+VxNVf1iDNa8TuLSqnIZfowks3Hgq+r2hN01ql+BYTEOQeL9VETAmNnPe9vOasX8M+mQG0qqYJOdg2MhMTtpmci5exTSTC8FqmJwArWZq6mQZsZqZisvxmPw6mHeHrsjZNx/e9/PBiej5hVCodizFwMpN0P4zfdoH4sVKf7h2KoUcipiqPJp4+uK3na+ULfpfKzXHLzs3YNo95UFGGFyX56Jv2/2IfMSJOVwFD9RdlQvHfzqAWzGb5d6F+mJ/j7tIP7Uy8sodoUdKuAJ374G5670x71EcA/HOEvSacllEuipN7H/4DEcLuSJT3DXLTO0wYdZ9/Dz6BB4r4vyaIAKhoeGaZCW7Lz+SOp48PDh5nxQqFrIyAt0bfSE1IvIIoOfjNKlFaAI3kxDgmEyTYLSsTmRnPnkV07KuK2sbSUBZzaSVSkONMjKO7PaVcJGx49qvhmCl8P5Py5TIKpQaGbPYi5qTWs19GDYtXYT+xbtgaMMiKHvlCg6U7YPN08vH1JXUiMc5Vn0GPhs90HWIdkylMz5rnA13l4nEN80LwT7PQ2ycPB03VZFGpGN4BpQe2AuDi0clmlJVRctjgQht3xZ5XMqhbcRl/P6xIbyPtEZ8JcTVHj2xyXkCJh6rjdUVY8dkkorR/WvFcuYK8seq0zlE1tqJWFkzdqIeLQpAKldkSR+LTKzdsT6oqsBz2lrknn8Z/ScXFWuUUS1/A4zOPAdd8jxHQMuiqBJwFUsffYV1f9QUhvgLTb1PRVRoCzQehC0bf8WIY19gVZW0Mbv4nVEEHEVWZEpWIts6f/slyGuDJ9VkibGcNRBQSpxR3LKMWzk9H9PqJzfTEFCpRTNNV9yLuROgh+9Lfo9QpvcKg6pSLObplX0NyrEAEzBXAmPm7YaMoUnleXq2jJXr01yHxHoxASbABESpBRE/HCpfcJ6ybnMdQP7i2DIB2ecBYvR48wC4ZkgDp1S8opnY74zkFGZiT8PHmwMBciXcvO+SlCrKKqaUMAsxATMjoKxmyqi1ZOcFjRgnt5KhxTJMgAmkNAFK3nfgjL/Uygzp2uZrj5RWmc/PBFKMgDHPA6QkJQBiA9M0l4uNTNNwNPtelILNMis7nFHW7C8nK2iAgBKb2b9eMQOS0KQ3/8fXn4vDGyTFAkyACZgLgfV/yk0YK/dzc9Gb9WACyU1AeR6QraOtJADiiefEXyk2MhPP0CJ6oJTlOw5fltJVCZLmjLJSuFjITAlERKjRpfmXUtpt2nuJCzFLkWIhJsAEUpJAmCgn9uRlIGTqAZOerWoWSUl1+dxMwGwIyK7oU+wmTzyb5rKxkWkajhbRy8z1cqnO2zUsB1r55MYELJmAnZ0KpYvkRoOSOQ0OY95f1zQPbsEh/L03CIsFmAATSDECDqKc2KHTftLnb9+knKjLyr9r0sBY0GoJUEIft4z6S1Qpg//r+C2eeFZgJOKVjcxEwLOUQ5VU52fuG06xT2nO06VNxZk2LeXisp4GCfRpWcGgDAnQg5tTKk64LQWLhZgAE0gxAqt3X5Q6N02wUdkS/l2TwsVCNkCgQ52iUqOkzPPU2GVWCpdOITYydaKxnh3GpDr/rq4HwkQWWm5MwFoI1C5fQGr2Unal31q48DiYABOwLAKKq6xsbUzZCTbLosDaMoGEEaAEQFTKR6axy6wMJcMybGQaZmQVEsqsjL7BUIIAci90EFlouTEBayGQNo0TZGYvaaXf/8EL4VoWWd/QWsbP42ACTMA6CBjrKlurXEFNuRPrGD2PggkkjgAlACrg9hnoWVemscusDCX9MmxN6Odj8XtpVZICmGWK0A5pI+dWaPFQeAA2RcCY2ctt+y9x6nKb+nbwYJmAZRHYeeSWlMKUWZtCX6jcCTcmwARiCMgmw5JZnInpld/FR4B/feKjYkXbaFWSZmNkWs0vadYzXEaUZZiAxRAwZvbyj0M3LGZcrCgTYAK2QyAsLALvP4RIZ5WtV7Ww7cDhkTIBSQI06dy0jlzdWFqcYe8mSbA6xNjI1AHGmjbLzMZQ/SBKEEDuONyYgDUSUErz6Bub4jL7QTzMcWMCTIAJmA0BFXDwrHxWWXaVNZsrx4qYEQFjJp1JbfZuStzFYyMzcfzM+mjKKnv+xr9SrrKy9YPMesCsHBPQQSAiIgJNapfQsTf25gOnbiGtcDPjxgSYABMwFwLklXTy4n0pdSirLLvKSqFiIRslIOsye/DcPRslZJphs5FpGo5m2Qtlld1/Qs5VlmY9g4M54YlZXkhWKtEE7OzsNCv1MjUzt//DLrOJBs4dMAEmYHICf529J9VnhwalpORYiAnYIoGICDW+9HCTGjplciY3dX4+lsL1iRAbmZ8gsa4NMjFmyqynk5OjdQ2eR8ME4hCoVebzOFs+/Ug3lScvA/GOXWY/hcNbmAATSHYCoaFhmt8kmVrXpFy54nlFluywZNeTT8gELIGAnZ0K1csWkFbV9/oDkJstN+MJMDXjmVnEEeHCPZAelGVuSjzraRGXlJVMJAFKaiUb8H/26kOkZ5fZRBLnw5kAEzAFAUdHBxw6LReP6ZYxjaZMg1MqB1OcmvtgAlZLgHKRyLTTlx5wvhIZUPHIsJEZDxRr2GQv3APpQVmm0awnZ5WVIcUylkyAklrJ1siSjX2yZB6sOxNgApZD4Ir/UyllZWoCS3XEQkzAygk0qlZIaoQclymFKV4hNjLjxWIdG2UelKkoLT14c1ZZ67jmPArDBOqV+9ygkGzsk8GOWIAJMAEmYAICsr9JFUvlNcHZuAsmYN0EKBkgLbDINCUu82MQ5y2R4aUtw0amNg0rey9zU5J54LYyLDwcGyZANbJkHsLIzZzczfmmYsNfFh46EzATArKhL6Rukc+zgWI4uTEBJqCbACUDpAUW2XbrwTOIQ7gZSYCRGQnMEsSNicekB+4w8eDNjQnYAgEK3q9QXC6rHLmbp0nNybBs4XvBY2QC5kogRBiMt+49k1JPicekGE5uTIAJGCYgG5d55vIDOKXi5wHDRGNLsJEZm4dVfFKrYUQ8Zh5AyHNjArZCIEvmDCA3cUNNxt3cUB+8nwkwASaQGAKphMF4446ckVmtWM7EnIqPZQI2R6B6aTmX2St+T2yOjSkGzEamKSiaWR9UtPnGbcNJAuhBO3tmZxGPyV8DM7uErE4SE5BxEz9/i28qSXwZuHsmwAQkCPxz/r6EFCD7wCzVGQsxASsnQOEzRfJnlRrlyZv8PCAFKo4QWxdxgFjLxwt+ho1MmQdta+HB42AC2gRk4jIp2J9aqCh9wo0JMAEmkFIEjlyL/C0ydP7yJd1A7rXcmAATMEyAwmeKihhmmUZ5Gt6L2tmcp0GGVowMG5kxLKzq3drjtw2Op0QBuT8ugx2xABOwMAKUHEOmnb/xL5f3kQHFMkyACSQJAXqwffD6o1TfObI4g9xruTEBJiBHgMJnKJZZplHyH85hIkMqRoaNzBgWVvGOssr5P3ghNZbC+bIhOIRnPaVgsZBVEZDNKnfz7lOR/CeVVY2dB8MEmIBlEKBVE3qwlWn0oEzhL9yYABMwjoBsLDM9D2RI52Rc5zYuzUamlX0BKC3zjXuGXWVp2KWL5BbZsnjW08q+AjwcSQIyWeVkC6BLnpLFmAATYALSBCi7NT3YyjTZB2WZvliGCdgSgS8Kynk2/fvkjS1hMclY2cg0CUbz6YR8zB89NfyH0KAkZ6Ezn6vGmqQEAZkby73Hhv+WUkJ3PicTYAK2QSDwXbDUQGV+z6Q6YiEmYGMEcmd3kRqxTK4TqY5sSIiNTCu82DKZ6NxzZLTCkfOQmIA8AZkbi0xss/wZWZIJMAEmYBwBmfs59eicPrVxHbM0E2ACoLryFDom0279FyAjxjJaBNhXUguGtbwNeGs4SUCJgtmtZbg8DiZgNIEII24slHjDzk4lYjO5ELPRoFPsgEA8WTEPg0+pYmlgB3u4Nu6KeQ2yQIUneLBpD1YcewI/5xJo2aM+muSm+FuZY2N1q/XhPZ57H8PVhnVR0zn2uSOF9Pc9P9dW9F70ArR+Trqmca+Ibj2qoZKLxHzwRS9x7EvNseGpP0Ox6nXQr5k7smhOHAb1yb3YlK0eWuYLwctde3GgWGPxXus7/foQvI4VRreGORD5YEB8fLDo7wA8y1sSTTp8FcVHa7jKW61zqwRZ+2xF8bXnV2hbOL34FNVen8C+VWew42ooIsrXwcBOX6Cg1umhb7//Hni9qYpeZTNEdfYWL/dsx4as36FvWbmkHYoa1vpKmWU/BoVwDLm1XmAeV5IQsBchZpQwS6ZRhlluxhFgI9M4XhYhrZRe0KdszmwuoBpB5F7LjQnYGgGKXZa9sVDijQJ5Ih/VbY2T5Y7XGdk7j4Z3ZzGC8I346Ut7tPJtjuLKgCIu4mjt3zG9Y2/MmFoUbre3Y5HnWPSbMQYLvjRwrNLH8UGoWCMtmt7/BT/mVEypD3i57i8cqkJGpiKo/Wqg7z8v4UzpkfDtmUsc9A6BJzZj2lfn4f/3IHRQPLrUe7DE5Tcsmr8YZzrmiDHiHl+OOTbAF/9sXYtO5fJiwIGO+No5HOGndmGjR21hWH7Aq32L0XaRPQr7fAsPRfWAQ1i82xmdycgUfP75ZiUWtOmCyfOK4fPrGzCx2xw89BqMfp/H89igfW6EIvT6n1jWZxJGzZ+I/xUTluSdRejZKRCfT++CSQPsELR1CfrUuIAef3YSugkFDO3334XFDzyijMxghG0Zi+o+TeGzwvoNTFlvigxpUyMV51jQ/mPj90xAioAxCbOevAyEa/o0cHLSniGTOo1NCrGFYWWXnf4AZFqurC6inhbX/5NhxTLWSUD2xvLfszdI4xTPg7V1YjHbUamuXISuf8YpLTJqb5iPHk0GYX3XEnB3tIdjkebov70g0rTdhEMSnanFKujNlYHI3PUdvHc+glriGONF0sO5UiuMbHEdO84p3iniTPt2YVK7ssg/4wSu6urUtSyqdx2J3SNPoNes6wiOMUU1R6jf5kGNfAfQx+shgj7pQ9wX1sxGl/p9sbZLSQ0few9PjB9hhxOXXkiM1RGORRuh16C3+PPoMyF/Gyc6XEF6r0EYVSELnJEZWZsNweZhp/D9fH+EGNgfO/95KHB8Fupva4QNS2rC/RPdbXcDZcymVRluTIAJGE+gfN5MUgc9fh6IkLAIKVkWIo8cblZDgNKd0x+ATCvklpXd/2RAsYxVE5BJgEWJtBwc7K2agy0NTo1nuLwsA1q3cEesKLZM36LHlxew97bhBwhVwE54HamDFlOrofrEfTicRADJmL1+VIUsmSInOdS4B99fgeYDu2Ow6x4svCiMLp1NzLQ3rYPeK07hhHC91W4Rz1xQdVBP9F8yDz9fD9HehTBxjmPLM6KD4BMztSJWG2sPxZom2eOYq7EO1foQiDeXPsL1szRQBZ3A9g+10a2Ydikgodu3tdHR+xz+CL2hd/8lrV5xexZadXPDxGVfoUSMctoSVvWe6vRyYwJMIOkJFMrlKn2SVI5sOsnCsoGfaVkUli9nb6/C2/efzkvHN7J0abVv+PFJ8DYmYP0EXDMYdrcLfCf3N2X9tKxlhE9w95UbiudR/ESVcTnDvUIobj8Q2Tzd9X0vxNraHl8cG/ETpgsX1ir1xmLqGU/ULG+C+ml2oXi4bQk8zzsiVeqPCNnrB7/uY7C7VKRrlipAGJbvv8YPovxUoVFO8Nzqj9mlikKX45ba3h3FM/2D5/EttToURRthTK7tsA0nTrZCJQWDiOp8GZg3Hj7RAp++0dIbKjVyPL6BXaWG4UhzsTpw1x/7KjfBz3GOIt2+SPUPzv2XQewvrXP/baF7GdHnR38f9N33QpjLobjwIgKVs1v3gx5NGss2mXJMsn2xHBOwRQKZ0sv9fp+5/EBT/s8WGSVkzGxkJoSamR6TytEBN+4YLtws6xZgpsNktZiAyQh8nkMJdNPdJact183GYvdEhCKYnuFjzbVFICTIcAiBGtdwYOkzvCu4Gu1OhsLtw0ds33YTc8p7IF1igUQ4Ik/T7vDuKbId7huOz1/3w8khJZBV068wfjcdx5YsL/C+zyU4p3GA2+qD2DO6KJrosjKFQRYSe6FSS0NhZJfsh1Wew1F3YTmcbRyzrqsKew2NUwz9eTzfiNkjbuF6xufYfaYm/jxSEaE//44pT+yR7mNpdFv+DSpF651LHBAZk1m4/zr8eqEwZoo+IoTBRGrEfoyL0c3Qfoij7+56hyH7J6P75R9QYNAh1F9f26rdZY2ZNNa6qPyWCTCBBBDQJMP861oCjuRD9BFgI1MfHSvdZ4xbgJUi4GExAQ0Bt+xcysfWvgoq5EO52n4YceYj2leJWbFUww9HNmdFpW4x2+Jjo7qzFUPTf4+/F9VCDhJQ70fhwgew+ycPtIxltMZ3tOw2B6jrdsHvw6dj+LFyWC30VOMKdi4ohEmHx6GvZm4kEM/TDkW/o+/RpFb85q3q4UEsT1Mav4mVwPibC1wHdsCwSvMxIHcBjUiIMN3K1n+A1efeoy/1m6UlBi0Tu57OQvu65EqcHV/8NBbe8XcotlJMZmP0WnAKJedfQ9DcCuhxxBcHQyvEMoYV3UZ+nhpZ9ez/jRac1U4oNrAtumcXjyzZ+2PL6skYtrcMttTPKOm+q1NZs90hO2lMA5BdhTHbwbJiTIAJWCUB6/Y3scpLpn9QD5681i/Ae5kAEzCKANfGMgqXBQi7ImfffHjfzwcnorPKhEK1YykGCrfO9p/pG0IgXqz0h2unUpEGJomqyqOJpy9+22na9PYqeKDuqlw4/tMB3KLTnPVG36LV0Cx68d0ZWZq64MTi03gcn8qhvtjf4y7ST62MvNCzQutQDW28M+PZmH24LxYz08IFOXu64+2wv3Apms8bvFl2Autyyj4yiAOvvMCHnKLkiKoGun1/HuMW3dVKMnQXl0be0ehWFeX07s/7ydjywWN2FbEIuwxrXusynj85yKo3cEkyq768PDgzIiBbt9aMVE5RVXglM0Xxm/7k9x5ThTX97YuCcoVn9ffCe5mAZRMIFdmVi+SPdETUNxKujaWPjiXsS42MWexjZ7lzH4ZNSxehf/EuGNqwCMpeuYIDZftg8/TyUXUllXHFOVZ9Bj4bPdB1iHYmQmd81jgb7i7zw/PmhWCf5yE2Tp6Om6rImDrH8AwoPbAXBhePu8wZp2/llFqvao+e2OQ8AROPV8TM3YEo07l0jHFLcmW/wYQTZ7E/pBbaa8VF5gryx6rTOdBq3kSsrEm1JYWrrb5WYBBW9emBTPejhAr8gD3z56Jb8a643sgdBQ9ewdX2NdD5qY6kSFrnppjMnE8vYWlEM2xYWUAkVxJLkQN+xq75k1GgYjpUr2yHt7tEUqA5P0fpJtxoDez/RPVM7TBh1jAUmnoRzSZ/gfSfCPAGJsAEmIAcgbCwcFCdWW6mJ6BSi2b6brnHlCLQfpQ3DNXV8upXGz1bVk4pFfm8TMBsCFD2xjK9VxjUR31ojEEZFmACTIAJmJLA9OUHMHzlcYNd8j3dICIWYAJ6Ccg+C1CSrTWTPfX2xTtjCMj6vsQcwe+YABNgAkyACTABJsAEkpQAJx1LUrzcORNgAklMgI3MJAac3N0HvFWKdif3mfl8TIAJMAEmwASYQHITcJYsv5DcevH5mAATsG0CbGRa2fXfffmRlY2Ih8MEUp6A/4MXCA2NzoKS8gqxBkyACTCBKAKF82UTNbINxN0yLSbABBJNgBdyjEPIiX+M42UV0hTg/DEoBGlSx01EYRXD40EwAWkCGdLG1AbUd9DbD0EICgmHo6hFy82KCLw+gf2/H8cqfyfk/PobDGnmLhL/BOLJinkYfIpqZ8Q0O9jDtXFXzG0QBj+v+wjrWQbZd+/EgWKN0TKfVqHKiKs4OjMIOYeVRr6Te7ApWz20DFyG3oteIm5atvCs1TCmkSMCClVADRflfCJNgv8ezPn3Swyo+VlUiY7YOjlEOCN3tL5Cx9eH4HWsMLo1zAFR/AR48DfWLz2HLYGuKFa9DvppxiXkRL9eb6qiV1lKBkTtLV7u2Y4NWb9D37L6S7dEyvP/TIAJMAHbJcALOcZde17JNI6X1UiHhXO+J6u5mDyQBBMo4Ka3XkWC++UDzYiAeg+WODdGuVWPyfyKabcXoVfbc7hUvSMWz2+Ibo8WoXanQ7gNZ2TvPBreC0fBe35BFDpdBGPE+7ULR2B+gyzC6HuMm4tP4pqoB5k5cCeGbBAGZ0yvwLnl8PQNRBpEIPzULmy8J/aW6oVF1N/CHvjp31coPHKkpv8/fq4Ej9cb0GnQUTxR+lCfxfbWhxCQV7sGZDBebw6IPm71vPro/HY1GnQ/FnlcwCEs3v04slDJ5UmoOOg50vQcjD/GlUXdx8vRpuQGnKD+/XdhsdAtsgUjbMtYVN+QG/XZwIxiwi9MgAkwASZgKgJsZJqKJPfDBJgAE2ACZkZAmJX7dmFSu7LIP+MErkZpp8YNHPa8iHTTRWmRClng5JgP7v2EUVYiBE9DZIcgVh6/LoemC47iaPQhoo7mjqco0JLqaOqpTRktL1bG6/bHlncrMPwYxdMHQ71hJSa26Ykf8+lZNU8ljN+O32DEqTM4EstyDkHYgcdw698M3+YSniquZVGl7yTsv9walaLPSW9EeZXjs1B/WyNsWFIT7rH28QcmwASYABNgAoknwEZm4hlyD0yACTABJmCGBNS4B99fgeYDu2Ow6x4svBhZu1IVdBZ7QuuiW7EYQ06FnCg6vB4qGxFFoHatj7bux7Axql9QHc01xdC+jnYdTUNg8qPMrEJQ9fCBd+BhTBpfDOMGUX1J/U0VcBknP7ggi+JlqxFPBYdSTji7ZB+Ov9FR05Lkbs9Cq25umLjsK5SIQaD/hLyXCTABJmDjBMrnNea33cZhieGzkcnfASbABGyWwJOXiuugzSKw6oGrAoRh+f5r9C6SG5VGOWHXVn9awwMe+2Nf5c9RIJGjVyEvKg1QwWdbVL++f+LXxvXQ2sXIjnP3xZzuu/Brla3wndMWTbRCPJWe7PM8xMbJ0+HZZzL6D+gLj1L+wPrvUEMRUF5rTsXtQc/wd5tWyNRoJn7cehvPlX0qNT76+6Dvjy9EhOldXHihxxBVjuFXiyDgYB9rtsEidGYlmYClESiUy9XSVE5RfdnITFH8KXPy/569QdrU8TzFpIw6fFYmkGIEHj+XNzId7PnnMsUuVIJOLLJtbjqOLVnO4SdhmPX60wFuCw6KFczIziKCQiHtGavz/GIZsOFX6LP8CA7gAx798RJffFsE6XXK69qRAa5966FhRE2Mq58xXqHwh3nQctQwrFvYEf2D3yHnbyMwvbxzVGIg7UMcoSrfHeP2bMKrNRVR98pc1OxMsabUQnB31zuUmTcZ3nNfYuYgZbv28fze0gicufyAE/lZ2kVjfZmADRDgpyYru8huGQ1nCHz09A3s+YHZyq48DycpCZQWK2FpeGImKRGbvG81rmDHgkKYtHacJsmO18wJ2NzrPNYcfQ98XgE9jvjiYJTBGXlyEdzodxd3Ym0zrJbaqTpa1DmDjWcvYNu2cmhfNZ3hg+KTcHSCo/iOOcW3T2ubCrlRaEwxZO+yDj6GdM1YGbXHDsDi+9ux+oEYn9oJxQa2RffswjimWNBU3hi293XshEha5+K3KUsgE9e/TNkLwGdnAkwgUQTYyEwUPvM7uFqxnOanFGvEBJgAE0hmAqqz3uhbtBqaRbuuOiNLUxecWHwaj1U14dnLF1OWPkSQolfYUaz3nIff/QxZbsoBka8qZEOh1k7Y+/1CTG9bC98kh5NInn6YM/gkJq57EstADMcl7O21AXsDY7IBqUIf4t4TV2SNLpGi6J8PHrOroGS/ZVjzOkZe2cuvKU+gRMHsKa8Ea8AErJxAeASHDSTVJWYjM6nIcr9MgAkwASaQQgQC8XxbIMp0Li2yvGq1st9gwomz2B+SBq5DJ2Bd4E/IWXEUug4dhMruu3B24XhMLqZtJaZGxiypDSQvELFwdRtirL89ajfMLwqb6Gsq2Lm54BN7T98h8e7LAJc+NVBr9Bbs0LKJ7VEcdbsH4miTFsjTbgq6DRmOrwr64MSqQegTbWxrdZipHSbMuo+JUy/indZmfssEmAATsBUC9nZ2uHn3qa0MN1nHqVKLlqxn5JMlKYH2o7yx9nhk9I2uE3n1q42eLSvr2s3bmYBNEAgPj8Alv0co03uFwfGqD40xKMMCTIAJMAFTEli88Th6LThgsMtpnSpjWJfaBuVYgAkwgfgJ8N9a/FwSu5VXMhNL0AKPv+IXXfbbArVnlZmAaQhQXDIlzDDUOGW5IUK8nwkwgaQg4CwZk3nBj1dhkoI/98kE4hJwTm+ouFTcI2z7MxuZVnb9q5fOa3BEr96JrIvcmAATkCLAKculMLEQE2ACJiTw9n0wCufLZsIeuSsmwAR0EXjw5LWuXbw9EQTYyEwEPD6UCTAByyYQ+C467YtlD4S1ZwJMwKoIpE5lLz2eW/8FSMuyIBNgAp8SuPf4zacb49mSM5sLQkPD49nDm+IjwEZmfFQseJuMe42hmE0LHj6rzgSMIiDjZvZ5jvgyphh1GhZmAkyACRhFwNHRATmyOEsdc+b+Kyk5FmICTCB+AgFvP8a/I87WXFldEBQSFmcrf9RFgI1MXWQscDu711jgRWOVzZ6AW/aMZq8jK8gEmID1EcieWc7IpJG//xBifQB4REwgmQjsvvxI6kwZ0nJMphSoKCE2Mo2hZeayadM4QvYPwP/BCzMfDavHBJKegMyqPrnHcGMCTIAJpAQBt4xppE5768Ez4cbHKyxSsFiICWgR+BgkP0FTwO0zZEjnpHU0v9VHgI1MfXQsbB/V+qE/AJn29kMQjPnDkumTZZiAJRH48FEuARa5x5CXADcmwASYQHITqFYsp9Qp374Pgp14BuDGBJiAcQRu3HsmdYDshI9UZzYixL9IVnihZf4QqHRDmtSprHD0PCQmIEfg5v3nUoIUF6VSqaRkWYgJMAEmYEoCsjHhN+48A5Vl4sYEmIA8gYgINf57Jpf0R3bCR/7s1i/Jv0hWeI1l/hA4q6YVXngeklEEZG8sFBeVPi1PyBgFl4WZABMwCQHZmHCuf20S3NyJjRGws1Ph0VM5I1N2wsfGEOodLhuZevFY5s4vChqurSWTVdMyR89aMwE5AjduGy5g3qCknKua3BlZigkwASYgTyBExFgWyZ9V6oDbj7nOnxQoFmICcQj8c/5+nC3xf5Sd8In/aNvcykamFV733NkNJyqRSXhihWh4SEwgmoDMRIt7Ds4sGw2M3zABJpCsBMhJP2cWud8g2eyYyToAPhkTsAACsnVmy5d0Q1CwfJIgCxh6kqvIRmaSI07eE1Ayn8L5DK9kklZPXgYiPCIieRXkszEBMyFw5JrhlOUlCmY3E21ZDSbABGyNANXKlE3mR2woazxnmLW1bwmPN7EEZOvMUn6G0DB1Yk9nU8ezkWlll5uS+RRyk3OvuUUZtfjvxcq+ATwcGQI0wfLgteHiyzRzGRwSKtMlyzABJsAEkoSArNv+jXtPQYYpNybABAwTiBCLLOdv/GtYMEqC8jNw+RJpXBpB/jUyjpdFSKcTSUrK580EQ7Mzpy89QPWyBSxiTKwkEzAVAcomp5lgkeiQJmxo5tKJ8/5I0DIzkYgT2NXpb6xJbx+tWLqPpdFteX2UP3oMxzyqooaLkjX4LV5sO4TjFRqiSQ6ae32CB5t8sOjvADwrUBHdelRDJZeoOdmAazj1vgAq5Nb+UjzDrVOAW4Ws0FuqO+IqTkwNhPOISiiunBphUJ/ci03Z6qFlPsdIXV+fwP7fj2PV7VTIUqkaerX9AgU1uwLxZMU8DD4VfTAcwzOg9MBeGFxc0Se2jEOEM3J//Q2GNHNHlmgSOt5c9ELvRS8RNw1GeJZaGPxzOrzquD0ent+gkqJOHOYRGfOjXruG6FoiAzQirw/B61hhdGuYAw40w/ngb6xfeg5bAl1RrHod9FN09N8DrzdV0atshihF3+Llnu3YkPU79C0rVzdSxwgtcnPpQtkh4w5LceaNqhe3yDGy0kwguQlQyR+qtCDT2lV2lxFjmTgE2MiMA8RaPlYsnN2gkSkTk2YtPHgcTEAhQNnkaILFUKOJGpqw4WahBNT/4vS14hjj2xyxH7uFcZP6LwzoHoItG+vAnYydy3PQZkIJzPQVhmTERRxusA5LO3bET/OFYXZmOcZUPY2r+4aie3ax/9Rv6PtgJHx75ooBE34Ya/vao5X2uY4PQsUaadH0/i/4MWeUFaa+huPjV2FV5gXw7eEmDC1q4Qg/tQsbPWpHGpm3F6Fvrw9wm9QR84cDgRu80L3Dc0zzrosSqmC83hyAwgumYbybYtnFqBH5LijmJg0AAEAASURBVI5MiB9url+NBt3rYseSKoh2AI9Pv1K9sGgh9fIcNxpPwXrt84RvxE/x8tQ6fyzmguu//2D3/8aieZPx2FpfxBYGHMLi3c7oTEbm5Umo+JM7Rs4bjD/SXsYx7+VoU7IkJl1ujUr+u7D4gUeUkRmMsC1jUd2nKXxW2J6BSXRLFJALgTl47h6GddG6HvyWCTABvQRkszLLJNTUeyIb3SnumNyskUDl0nkNDouT/xhExAJWSoAexgw1mqjhZj4E7Cedg65/xmkpjLPyg/BX4Q3otVmEDIQdxR8d3qPq5kbwUAnX6DWz0bVeDyxrWxzuDqnhXKkH5i7Mg5Dn8gkf1GIl9ObKQGTu+g7eOx/Fikp4m78U6i79HZPufeqGrcYNHPa8iNRzB+DHilmQQaw95mzdEzM+v46TDxMYP5+qIAp1/AYjTp3BEWH3UdOnX6SEKf4XnHPXQIMB6eG/8w6CY3UZgrADj+HWvxm+zSUmclzLokrfSdhPBmYsOcHo+CzU39YIG5bUFBMCtteCQ8Kk8yzIrHbaHkEeMRPQTeDkzSe6d2rtKeKeTcQ7h2tt4bcyBNjIlKFkYTLG3JTIH53/cCzsArO6iSJAybFkHsZkJmoSpQgfnIIEMiPb2O/QasIcjBy3A8vHDsZP+ciB8zkur3ZFhxbuUauMpKJYb6zaBn1L6nWEjTUWVcBOeB2pgxZTq6H6xH04rLVXnaY0uq/IBt8WW3EiTGuHeKsKOIA1wXXRrViMk5EKWVHs1wHo7pbw27Uq4DJOfnBBFmH3UdOnX6SEqf4XA7zyAh9yZkCM0zL1nQoOpZxwdsk+HH+jx3i+PQuturlh4rKvUCIGiamUs4h+nFI5oHSR3NK68j1dGhUL2jiB5y/fGvT4UxCVK54HQWLCh5txBGz0Z9s4SJYmbcxNifzRjbmBWRoL1pcJaBNQq9U4c/WB9iad78sVzwsySCmZFjfLJJDu4T4MHXQLrsERiIzH1IofdKqDniPXwXFyHeybnFUTM0grfHdfuaF4nihrLL5h24Xi4bYl8DwfFT8pZJzTPMPutDXRSiMvHkT2+OLYiJ8wXVSTqlJvLKae8UTN8k5RvakQXqQbVnkORN2F5XC0f54Yg/b1M5yrWhEF4jtv1Db7PA+xcfJ03BSrrp/GY0YKact85vgvDm9zRr3No1BDs9uQfrpPrpdn1GHRMiHhyPn0EpZGNMOGlQVixqh0X3MqbqdbiYltWqGRfWX07PYthioxmSo1Pvr7oO++F8I4DcWFFxGoTK7KNtwoJkzG+4jv6Tb8JeGhG0XglOSzgFvGNKCkP9yMJ8BGpvHMLOYImZvS9n9uoGfLyhYzJlaUCSSGgEolF49JNxUqHcDlABJDO+WPfZ+nLmbMjhuTGaVX2AmsnZcTg6qfxaTNX6PGd1FZuSNCEUyerLrmFiIckadpd3j3zBUzQIpX/DJyRU6Naziw9BneFVyNdidD4fbhI7Zvu4k55T2QLvqINHAd2AHDKi7Cz1/9hInR24X37sPXeCU+5xDGVcTeeWi3LQh5X93C7q8m41IPR4Q/zIOWC4bpickUUZ5RMj+5/Qe/XqPg99svmF4+8iFJTj8thbTe6uUZJRct88Ybv5Syx4yLbVA/3uczR6jKd8e4PeLf6+PYP28uam5vJuIuyS02BHd3vcOQ/ZPR/fIPKDDoEOqvr22T7rIK/uoiBEbGyKTC8nxPV6jxKxPQTeDkxfu6d2rt+fbLfFqf+K0xBGx7atAYUhYoSzclQ43cBt9/kI81MtQf72cC5k7gj0M3DKqo3FS4HIBBVBYq8AYBM//AmiGDMW1GQ+E2+zsWPokQq5n5UK62H/aeiVPeJuQ+rj6IHVWoa+CqO1sxNP33+HvRcHgvHIUp67pgysYD2B33Z9ahKtosz4hrbTbgL3XayO4+r4Dely7hqEbWEXb1h4g+huPXBgm7VauQG4XGFEP2LuvgExUCKq2frgHKbndpjtGjr+DHqZfw3tAxGSuj9tgBWHx/O1Y/EIGjaicUG9hWJFoS8+B1+2NLKm8M2/s6VmyroS6taX9IaBiK5I+aBDEwMDJE+Z5uABLvZgKCwOr916U4cOiMFKZ4hRJ254q3K95oTgQoLrN2hUJSKh0864ewcD1xMVK9sBATMH8CVB/TUGkfGgXfVMz/WiZcQ2HEXP4NzU43xXxavXSqh55LguDV/yBuwxU5O+XCucl/4VJ0+I0wSOdNRNvtj0SxEUPtI16s9Idrp1JiJTKqqcqjiacvfttJ65PaTbjklhyIP7ofxoCFUftU1dF1yFVMX/EQQYpo6DGsX/QU4Xo8eBXReF/z9MOcwScxcd0TRCDQCP3i7c2IjcI9uLtImrTeG/MeCeZaLRyXsLfXBuwNjNmuCn2Ie09ckTW6rIxyQD54zK6Ckv2WYc3rGHllry28phK1L8sWdZMequ/1B3xPl6bFgrZGgOpj+j94IVUrm9hQ6Mzb93KTjLbG0tB42V3WECEL3U9xmeTuR25/horOk8sA19ay0AvNahtF4NBpPyl5jseUwmT2QtHxgSImk5omhrFfFWTrC7TaXCvK/VJYb5pssyPRbnNJ/PXdKFwdMxMdCm7D7eYFUPDgFVxtPxr7+uf7NK4wDoEnwng6tdFDGIqZtPY447PG2XB3mR/eNI1rKaaD0/ffY87qmVipOUJ8HjAeG2ZNQr6KLvimShBubEqN+l2LIZWo70pNO95Ss0H8Z1fZEys65ENMlKiyh14zwKVPDdQquQU7PSvhhR793javIKSpqWDn5oK49l68PGPV6NQcHPOfqgo8p61F7vmX0X9yjLuwvSgqU7f7KfzUpAW65/oS9bK9wP0t4SiycTzmiTjWT1qmdpgwaxgKTb2IZpO/QPpPBKx/A5VTkgmBIRJ/Hb/FNbCt/yvBI0wgAaqPefbqfamjqZQZPUtzSxgBlUiEYZtTgwnjZXFHDZi8BfP+uqZXbzJE728bqleGdzIBayDQfpS3wbgmuqmcXimsEG5MID4CAddw6n0BVMitHbT5DLdOAW4VskI+B218nfM2JqCbwOKNx9FrwQHdAlF7+DfMICIWsHECDfsvk8oyP/q7MpjUv4GN00r48NldNuHsLOLIelULG9STVjr/8fVn9xqDpFjAkgl8+Bhs0MCk8bWqWcSSh8m6JzUB12JxDEw6YVYUYgMzqcnbdP/GhMBQSAC5A3J5Mpv+yvDgdRCg0iUyZczo8Iql8vLfkQ6OMpvZyJShZKEyYWERqFWuoJT25F7jYM9fBylYLGSRBA6c8ZfS+0sPN4SFcdFlKVgsxASYQLIQUEJgaJVSpm3bfwmOjrGrk8ocxzJMwNoJyJYuIQ70DB0cys8DCf1OsFWRUHIWcJyDgx0ojqN/vWIGtZXNsmWwIxZgAmZKYOFG4c9ooJHrePWyBWw2i6UBPLybCTCBFCZQr9znUhrIZNGW6oiFmICVEVj/5yWpEVEMND1Dpxf/uCWMACf+SRg3izqKXGYNxWWSy+zOf65yAiCLurKsrAwByiT3MuC9lHtMhzpFNV06OvAKgAxbi5B5vQM/Lv4cY38oKepUvkPgwS2Y4/MvbrkUQq0W9dGlRAaoIk5gV6e/sSZ97OueNigHak3uhPY59MzH+u/Ar3fKYVi9HNGJgdR4jFte9xHWsyKKq2P6thelOVyKl0f7jlVRyUVPn9FgA/FkxTwMPhWZMMghwhm5v/4GQ5q5IwvJXPRC70Uv8Ua8DU/9GYpVr4N+yj7a//oQvI4VRueG6RGwYm50P7SLWtoPefD1rO9QzWdWrH2aBEmU0KeobzQX43WPPIfm/zh8IzLmR712DdGV2IuMt7rHqG+f0v8TPNi0ByuOPYGfcwm07FEfTWLFyypyOl5fn8D+349jlb8TcmqzRXxxtqEI8r2D/zwKwz3iT3iNy45mU74QztLJ0ygLfL3KhfDL5nMGT6i4zObN4cormgZpsYCtECBXWZl6s8SjUTW5Cg22wi4h45S5yyWkXz7GTAgEi6ri0i6zR2+aidasBhMwHQHKJLf1wGWpDukBjuOYpFBZhlDw31jR+BYKdCwuDMy3CJj2A5qeK4E200ZgWevUSLtgGErPu4swu0pouHqspq6l97ePcKt0J837pcu7aBmYAXg8ujHsm+3BLe3R3/bBolazMemudoGTx7i5+CQ0KdfU/+L0teIYI2pmrlnUAWPy+WNX4x/Q7/Rb7V5Ebcg9WOLcGOVWPdZaSQ/G680BKDxypEaf1fPqo/Pb1WjQ/Rie0NGPL+NMlK5/jCuL2gFr0ancSvyplAYJOITFux8LwQzI3nl05PiEHt4LRX9dP+Lsh5wokyks1jmotueqxf0xuLiYvZfVXXskxwehouMo/KpdtkSrHzr3hn45kGPhWDQXtS8BfWOMiKXbJ+OPuIijNSdhQGB5tJv6A5Z5huK+51hJtuLUtxehV9tzuFS9IxbPb4hujxahdqdDopSNaOGHsbbv0cj39FnTXuPe+N+x+rHIl+hUDe1Lr0OL6TcN1wFVDk/kK4W0kKcFeVzItBXbT7OBKQOKZWyGwP7TsX699Y675pfCVVaUA+SWcAJsZCacnUUc6eTkKO0yS6udVEeQ49Es4tKykkYQWLLzgkFpxVVWLK1wswoCz3F/xCps+KErumW3E4abH46sL4Q+Q8qgoFipdizaCG0WeuGCRGkSDY7gfVi6tgS6fjiMdfe16wqnQtq2abG/xy6t2pq6AGZFjkZdMWlbEaRr6Y290bndxZt9uzCpXVnkn3ECV3UdnqogCnX8BiNOncGR6GOjhF3LonrXkdg98gR6zbqOUF190Pbgv7C4e2r0mkdlXGTrv+nSPeZEamH63lwZiMxd38F75yMtYzlGhsqjIHcNNBiQHv477wjTP85jiPYYo9eGo47X3keJ8TfMR48mg7C+awm4i/hDxyLN0X97QaRpuwmHok8ZP1s1buCw50Wkmy5WbCtkgZNjPrj3G4w/SoTgaUj0wXrepEO6Nr0x+9RU9D72UY+c6XcpHheGeuYwGEOEeL+tEVi9+6LUkBuUzInsmZ1BsdDcEk4gzq97wjviI82bgEyWWRqBz4ErcGBXQfO+mKydNIEIUVuQMieT65ihpjy4sausIVIWsv/pGkzaVAsjGrtq5g1UyINSVS7gt6V+eG70EMRs9q5DWDegC37v8hxLve8gen5brUKa0m3h880udF14B0EyfWf6Ft3rnIPPpUhTUI178P0VaD6wOwa77sHCi7pNRFXAZZz84IIs8U6GiEqZTeug94pTOKZTj5d4OnEz/hjXA32E8W10i6O79vGqgJ3wOlIHLaZWQ/WJ+3BYe2es94LelRf4kDMDnKBtsEcKRY8xHjM1ep/qNS4vy4DWLdxjl40R+vX48gL23o7sVxdbVdBZ7Amti27FYh4iVciJosProbJ0CFZ+lBnhioPTj+J+rPEl3QfFZVbmDEoYjIwsyzABayZA1Rop47JsVtkODUpZM45kG1vMr2uynZJPlNwEQkWmzEbViwsXmz9BNx19jVZ8erasrE+E9zEBiyFgZ6fCpr1yQf6dv/0SQcEhSO0k/YRpMRxsT1GxenXmOnb1GIzfogefBXnnTsbK3xegZ2F/+DdqhkFdlLjAaKF436iFCXF8gTM6rhbZujPXR5/CB7B/RAHUVww9dVq4DuyAYRUX4eevJmFyZGhvvH1FbnRG/lJ2eP6KTFVHqAKEYfn+a/xQJDcKjXKC51Z/zC5VVOwB7PM8xMbJ03FTFYrPHP/F4W3OqLd5FGro6F1t747imf7Bc4Hg00ZcZqPezdbYMilr9KK99jmi4zHJXTbeFlv3GBExlj2+ODbiJ0x3AarUG4upZzxRs7yTRiTdw30YOugWXEPCkfPpJSyNaIYNKwsgFV7oHGN1YbLf1jH+ahBux6/cUDyPchEUTZzhXiEUtx+IFVr3NLrZPvbHvspN8LNyWDyv0ToHRxqsjo4hsL/ugLzasmXrYOyp8zgSUhd5dSHTlk/ke22XWUP3czoVJTmh+z83JmDLBFQqFch9XLaRq+zHoFCkSU2/wtwSSoCNzISSs6DjlJUZWqkxlDCAVnw4AZAFXVxWVScBmrl88eqdwaRX1AGVBSjg9pnOvniHpREIQfjdD3DN5aIx1GK0zwm3Hr9ga49QhF/agt9GjEDD3j+LGMks0QZXjGzMO9XDjVh04x2eT52CaxFBsHN5gOvHO6B+Fa3YOIeqaLP8CNZ22IaTp7+IOTjedxEICVLS4gtjaNNxbMnyAu/7XIJzGge4rT6IPaOLool4vgl/mActRezoT27/wa/XKPj99guml3eOt9fIjaEI0eXu+WY9JnROj/77yU02pinnGO8W12CLkYl5p617zFa1iEA9sPQZ3hVcjXYnQ+H24SO2b7uJOeU9RDws8D5PXcyY3RyKuTMj5tDoMUaff66y83n0vrjj19jQEaGivICQjWXcaeunh604LEI8RBKqSDNYOWfMa1ydIdbAb9ydgvUxIlCrsiGX616cfSI0kuKndXAi3vb/tjSGrzxusAdKcjJdhMFkyZge9lymzCAvFrBOAh+DQiDrPk4VGchVllviCSTAVybxJ+Uekp9ASGgYaKVGpsmmd5bpi2WYQEoRoJnLlT5npE4/pE0FKTkWshQCdrB3cUR4UFg8Dpc0BkfYe7RG/zUlkGvMkcgEPTqHFoQwsbL437wJ+HP2j1g1dzxWLM2MUxuviVy12k0YaCX7YZXn3+g930/EGupumvjQzVlRqWQaod8V7FhQCJPWjtMk5vGaOQGbe53HmqPvY3WggljlHCMefrqsg49ub1qoHh7E8jRF8WUce1GNf3Fz+AGcm9lTE6Maq3MjPmjrrn2Y6s5WDE3/Pf5eNFwzjinrumDKxgPYrcvg1T5Y4n3c8auQD+Vq+2HvmdjeOdr66WX7eQX0OOKLg7FYCkPR7y7uxNpmSDlh6Ianh0vaOMANHZaI/ZScrGkdD+ke1vicZQNTmhYLWiOB/af9DHryKeOWDS9T5PlVNwE2MnWzsao9qRwdNCs1FMxsqNHM5/kb/yJcpEvnxgQslQDNXM7bft6g+pTwp3GNkhrXGIPCLGAhBMQSYLHMeLf/Jh4oGt9Zgl5TLovCFEoTBsXDZzhayBV6y9urj2HdNDe0qKMlVfZrjNm8C6uodkis5gLXIT0wefsSjHuq6/b6FkErvDCgSmO0F4vnqrPe6Fu0GpoJF9PI5owsTV1wYvFpUQgl1hIdkKcf5gw+iYnrnsRvPIf6igREd5F+auXYLp0Ih+qvWfjWrgsW1o+MUVXOZtxrbN1jjg3Ei5X+cO1UCjmUjaryaOLpi992Go6HVg4x+Bpr/K7I2Tcf3vfzwYnoANlQqHYsxUDhBmuQraomPHv5YsrShzFxtGFHsd5zHn73k7cyVU+P48937iidjI4QjiLJEXleyNzPiSn9Dn74GCyS+vE93eB3jAWsksCEpYelxkXPA+ReTq6y3BJPgN1lE8/Qonro07KCCHzealDnGauOYM1kT4NyLMAEzJXA6h1npWYuyY2cCi5zsy4C6nIdseTfhZhzrRZmUnKX/A0wOvMcdMnzHAEti6JKwFUsffQV1v1RM8YwIgSpXJElvZaB6LsPv37TBAeijUAhIwyoBl1Wo9vJd+gbF5vY19CrHNZ/EfNAr8T25bJ7if92PEFg5wHYObU8sogakc+3BaJM59KxdSj7DSacOIv9oeVQLlb/GeDSpwZqldyCHW37ooldKB5uWwLP847IFeSPVadzoNW8iVhZM0Oso9Tqv7Ck43W8r3MEQ/ocit5npyqCjlPqIL9W3KOy066yJ1a0A3TrrkiKV/UZ+Gz0QNchWoY4nPFZ42y4u8wPb5qaapUvzvjdh2HT0kXoX7wLhjYsgrJXruBA2T7YPF2CbUgttB86AeumjkXOitnRtMoH3NiUGpU3jce0YuSnrDU+nW/f4s3Sc7jwyzQs1imTdDtk7+cUu3ngjD/HZibdpeCezZQAhc1cuPmfVPI/GgK5oVPjWEwNhkT/pxIXQBPakOieuAOzJ0AJgCg+M2/TGVIP3483D+A4DrO/qqxgfARoFbNIm3lS33O/Vb2RO5szJ/yJD6RFbxO3ttvT0LRtQUw41gwePKVq0Vcz+ZV/hlunRJhlhaxa2WtDEeR7B/95FBYlU1L2+0WrklTDr1hbud85ijs/vfKTKZHkx8pnZALJTKD9KG+Qh55Mo+fejOlT8/OADCwJGa3pWglpFrFoAkoCoNHtKkmNY/66oxzHIUWKhcyNgOwqZrvK7hq3M84oa25X0BT6iNUz98HYNusqhv5PrOKZokvuw4YIZEWhWAYmDd0RqcuSgSneirqpiwflQO+/mqbIBIaDg53GA0MpvWTowihJ/QzJ8X4mYC0EaA2NypbIGpj0PEAJf/h5wHTfAF7JNB1Li+gpVCQACgmNkJ79PLeoMzwK5mRj0yKuLitJBIxZxaTvd3H37KCYZW5MgAkwAUsiQAn9XgV+QI7votPx6lWfVzP14uGdVkhgzLzdBqsqKMM+PKMNKnp8zs8DChATvPJKpgkgWlIXjuJhmuLPZGc/KTaT055b0hVmXWVXMemBq7SoS2iqaDEmzwSYABNITgI0OUYrL1RyQabxaqYMJZaxBgKUuPKJKN1jqGyfMlZ6HqhetgAoKz030xFgI9N0LC2mJ/rj+75tVSl9lUyzYZxpVooXC6UcgYiICE0GxV/WnpBSYly3Gho5mnjhxgSYABOwRAJhItdCl+Zy5clofLJZNi2RBevMBBQCtDhCIV+yLfp5QOQt4WY6Amxkmo6lxfREf3w0+zn6uzJSOo9Z8BccuIizFCsWSjkCdnZ2+G39MalkPzRrSWnKKRkWNybABJiApRJwEA/F5JFB8WQyjVczZSixjCUToFhMY1YxqWxJrXIFERzMZUtMfd3ZyDQ1UQvpj2I5ZFczd19+hJ3/XLWQkbGatkhAuakMX3lcavg8aymFiYWYABOwEAI9vysvramymsl1M6WRsaAFESCX12EzdklrTMkwKYzMyYkyenEzJQE2Mk1J04L6UmI5pnWqLKV1v5l/RhVz5pUfKWAslKwEjLmpUAFzXsVM1svDJ2MCTCCJCVA8GXloyDRazVy/xxeUoZYbE7AmAhQOdv7Gv9IZZWkVs13Dcnj7PtiaMJjNWPgXxmwuRfIrQn+MfVpXBf2RGWpUzJlcEck1hxsTMDcC//j6S99UJvWrp1FfKeljbmNhfZgAE2ACCSGgeGjIHDvC6xBPHMuAYhmLIkDhYBTiJduUVcwM6ZxkD2E5IwiwkWkELGsTpT9GchGQrZtJrohUc4iMU25MwBwIULIfKlkybK7cTYXilih+KSSUV+TN4fqxDkyACZiOAHloyMZm8sSx6bhzT+ZDgEK7KMRLpvEqpgylxMmwkZk4fhZ/NNXNbN+orLSbzcBpPpqSJuHi4Z4bE0hpApTsZ4H3UZD7l0wb37suQoWBmcqRV+RleLEME2AClkVgaMdq0grzxLE0KhY0cwLKhDOFdsk2XsWUJZVwOTYyE87OKo6k8g1p0zhh+oBIF0JDg6IZosUbj8NePNxzYwIpSYBW1GllXTbZD2VTLuD2GRzZwEzJy8bnZgJMIAkJGJNpltQYv2gf18JOwuvBXScPAWXCmVboZRrFL1Ms5scgzigrwyuhMmwpJJScFR1HZRwoaYCsmw3VIWS3WSv6AljgUGjWkty9aWVdppFbzMhuXwk32TAZcZZhAkyACVgkAaqbSR4bso1qYXP2eFlaLGeOBCIi1EZNONMYKH6ZwsXSpOaMskl5TdnITEq6FtI3JUAJE6tCsjcmmilit1kLubhWqibNWk5ffkA69mJKr5qaGwplVebGBJgAE7BWApScjzw2ZOtgEwdyMXz/IYTzLVjrl8LKx2Vnp5KecCYUSoZ5XsVM+i8GG5lJz9gizuAgVoXoxuTVr7aUvuw2K4WJhZKIAKUol3WTpRX6Nt+U5ULLSXQtuFsmwATMi4BSB1smczxpThPHI2fvZLdZ87qMrI0kAQrhkk32Q11Shnn6G+FVTEnAiRBTiSLm6kQcz4daEQFKAkSuszV7L5VOpHJuUWdNtk4rwsBDMWMC9HNF2WSLes7XPBjJqOq3qjfccmQUyX54FVOGl7nK+B8epFO1AjVmf7ov4gR2dfoba9JHJnmKyJgf9do1RNcSGaBCGNQn92JTtnpomY/cpd4h8OAWzPH5F7dcCqFWi/roopETu/z3wOtNVfQqmyHqHG/xcs92bMj6HfqWVco/BeLJinkYfEol+lbBPlvB2H0834gRPuUwqVs+KM5ZatyF74hrCP21ISqpY+tKJ0r3sTS6Lf8GlVRRp73ohd6LXuJN1EflJTxLLfxvQiW4IxThF3dh+ZZb+OtNZpRt1hgDa2RFakUw1usTPNjkg0V/B+BZgYro1qMaKrmIOWf/Hfj1TjkMq5cDMX8t7/HSZx+OlW+CJjlMMC+tdV3s1U5wKV4e7TtWjTx/LB0D8d/MbTjeqQNaZL4Xw0rhIcYbsXsF5uTthMHFU4kjdVxDg9xinTT+D1o6KwLR1+f2p8zUeIxbXvfxqns6vOq8Lfo7qBybNigHak3uhPam4Kl0Gs8rPXz3WnAgnj3xbzo8o40mdCb+vbyVCZgXAXKTvfPvSxTsuEhasf71imHuqOaaDPOcAFAaW4IFY+4jCe6CD7QWApQEiP55jWyCMr1XSA2r6Y8bcN37e6R2SgVyWeDGBJKSgEqlQs+JW6QNTFqZpxV6bjZIQP0vTl8rjjG+zVEcYi7133+w+39j0bzJeGytnwbhp3Zho0dtYWQGIWDaCHxn1x1e09rhc7892Dx3GEoX+xFn++eDg/8uLH7gEWVkBiNsy1hU92kKnxWKgUlsg/F6cwAKL5iG8W5isu7aPuxYNBLls/fEnlEeyPLuKv4+544JwsiMaQF49LefOFK0WLrGSMR6V6oXFi2kLc9xo/EUrNecS/nNfY/33mNQ83BNTBw3CH+kuYSj8/6H2v90wfax4vzaHUVcxOEG67C0Y0f8NN8dWc4sx5iqp3F131B0z/wQ/9V6iaMPO6Omcoz6JHb1u4R3V5oqW4Djg1CxRlo0vf8Lfsyp6BCzO/pdfHKxxvoMj3fuxILGPlgz/Scs+FIx5KmHYLw9eAlXW0AYmVqsojuPQITfeZxI014YmW/1XEN93J7Df2AXVM8xEw9+LKRlWIuTXBqJhhWyo/OHgWgZS+doBSLf3BbGeuujCDr/C8bnUx6pHuPm4pMI7jkILVeXREOS/PN7lH0wEr49c8XpIGk+Ugb4ni0rY8nOC9KTxh0mbse1df01Kzx8P0+a68K9mo6AsW6ytLI/qtdXCA4JhVMqZbrPdPpwT58SMMG05Ked8hbLJkDZ6aZ1qiw1CHKzoYd++mPnsiZSyFgoEQRoZp4SVcg0irughyyOu5ChZe0ywhDKXQMNBqSH/847wnyJMYzU8MOR9YXQZ0gZFBTxbI5FG6HNQi9cIAMzFhaRhfD4LNTf1ggbltQUK4e6miMcizVA87lDsPjsPIw8ozEjdQmbZnvASgyfUB5z5n+Lr3OKVT3Xcqg6rj/mnVmI8Re1syeK92tmo2u9HljWtjjcHVLDuVIPzF2YByHPQ6B2rY+27sewUfsY3z0YXbUamrlEqqrGE9xcGYjMXd/Be+cjMt/jbXJyWZGjUVdM2lYE6Vp6Y6+uzuI9Q8xG+WsYc4zyTq0Kw5vf/sTWEGULvT7H/dWXccYp5nuivTf2+1RI2zYt9vfYhUtmlFdMyQBPk8ayje7nvSZt1tzPw8K4TJksN5ZLGQLGuslSbobsmZ3ZwEzGy8VGZjLCtpRTBYeEoW+bKtK1M+mhn/7YlZuapYyT9bQsAhSHaYzr15zhTTjuwrIucRJrKyyAKy/wIaf2ahmEuZkHpapcwG9L/YRpoafdnoVW3dwwcdlXKBHb+tRxUH6U6emI/fvvi/1SB+jox9BmYZkduYoTg2ugcqzT5EfZfnb458iTaENQLUZ4ebUrOrRw19JIHFS1DfqWTC1Y5EWlXuHw2XNfOBRTC8QLnxco3u4L5IhSQxWwE15H6qDF1GqoPnEfDkdtj/siK6c5LtO36F7nHHwuaRvEcXvU/Vn6GsbThTrwc9Spcxm/7dSqtRuwHbN9iqNR3ngOiLtJrUKa0m3h880udF14B0Fx96fwZ2MmjUlVup+v3+MLBwd+PEzhS8en10PA2OcBmnTm3Ax6gCbRLv4VSSKwltytU6rI2pnrJraSHgY9/HMadGlcLGgEgci4ixcg12zZ5j3iG42bLMdhyhKzTrl0D/dh6KBf4dn3Fwz9rh0yrqmJ3/oVgFO02UXjzoK8cydjpXoFehZujZJD12PplbcxEioRB+zvg74/voC9iKO88MKIFZ7CWZHp4TthyUbGheqjHK1rn8no3nkPTkiv6oUg7K4aBQtm+rT7QlmQ6vpzxCzSPcHdV24onkfXCp0wOL+uDM8FB7Gfzq8+A5/1X6BbPdeovoXpKQyQYyPqoJNLNfSvdwxr4l2plZVTVHZG/lJ2eP4q0rRVtsq/GriGejqKeJ4exbtURJrxh3FFIxcM9abjOPBjQzRxiLnWeq+POi1cB3bAsJWL8PP1GNp6Tptsu2jSuE/rqpBNAkSKeU7ZoykJkWxK8omYgCQBysvw4WOwUc8D1LUy6ezkxG6ykqhNIsZGpkkwWmcnxmSbJQKUBp3qZ3JjAqYiQGnJgoJD0H+Kj3QcJmeTNRV9y+/nfZ66mDH7R3j/Lz8y+ZbGjBVtUN85PgMrJ9x6/IKtN9fgQicVPowYgYY7nkcZmiG4u+sdysybDO+5LzFz0CHIOWwLfuIBP0TyLhut68JRWLJCK+GPzGVQh4s4o/BPJeM7f0QogvUsGKpdG6F7vdPYeFa4+Z7YiQkNquEbyqsjmhrXsH/pM7w7sRrt+izD0g8fsX3bTbyP3B39v6xc9AGIQEhQPPrHCEi803cN9R/ulL8+RtjtwkJyExYxqN5T8qJXi9zQvnQGr49DVbRZnhFXOmzDyYj0+k+YjHtp0pjqAa4e+61RZ2079g/Nw3xoaGKvi1GnZWEmoJeAsXkZqDMlNwNPOutFmyQ7tX9Dk+QE3KnlElASB9BDu0yjeI46A1Zq6m3R6hM3JpAYAhEicYXI86OJ+ZVNT06z9V5jvgMVJOcZy8TQt7JjXZpj9Ogr+HHqpU8MotgjdYS9R2v0X1MCucYcESaVaCIDarGBbdE9u1jlq9sfW1J5Y9je1zErnbE70PokVsQOPYVLFTfRRzAigkK1VhRJTHw2yaKXExy+TIfrB27HGVvM+Z2itFIhH8rV9sPeMx+19BRvQ+7j6oPI2FEVsqFQayf8veci7m39gGoti0ExmVR3tmJo+u/x96Lh8BbG8JR1XTBlo6hXG2ccsnKKEpqYys1ZUamkdjIlZW/U6yfGsS7DNJ5rGKerTz5G5ESNqamxc8NV4Xq8AyMbNUbrDIGfiOnfIH6sSvbDKs+/0Xu+H97qF072vdXLFjCqduaZ+6/w46xdIhmgPedbSParxSfURcCYvAzUB+dm0EUyebazkZk8nC3yLBRjGR4eoXlol3W1IUOz1Yg1mtUnNjQt8rKbjdJ24vs3Zt5u6UQ/pPi2X1trZu2pIDk36yJAZUp0/TM8UmFmdRcJbtZ7Y96jOBNgd5ag15TLeBbdidj/8BmOFnLFpw6o+eAxu4qwJZZhzes4/UQfT2/EvttL0HemBwY2FNmNP6+FIWf3YfUTxf1SDdWZHRhXtiyqxbewGqsviQ+VPDHl4CpM0nbVfOWN0bOizh/dhStydsqFc5P/0kpS8wYB8yai7fZHUXGYQqEa1dHLazaa7hTlRSorhp+Iz1zpD9dOpaLjM6EqjyaevrHjGSmOU0pOUeotglZ4YUCVxmj/WRAeX32uiWukMiD3n6aBS1oqClMQ1b+7heU7ldVlcWzwP1i3Mj/qlxH6GXUNlfNqv4ox122I0Uvno/YvH1C3XXFx7ZVrpS1n6L0LXIf0wOTtSzDuqXk9XpHb7MhuX0nnWqCRzvvrGudbMHTJeX+yEaCQLGPyMtBzq+ImyzUxk+0yxTpRrDQBsfbwByYgCNjb22ke2unhXbasCa06tfxhLXbN6ypcuMJEJi/+mvGXyXgC05cfwC+bz0kfSC4xlOQiRLh3cf0raWy2I6iqAs9pa5F7/mX0n1xUxGVGtfwNMDrzHHTJ8xwBLYuiSsBVLH30Fdb9UTPGmFJk6TVTO0yYNQyFpl5Es8lfRK/y2ed5iI2Tp8Pf4SPS3riMbZ81wYIDbdBSk2eoOjpsuYtx37RF8Qpl0ejNRfz+sSG8V1VF9qi+I2P+bsE1ONK4cQzPgNIDe0XVgNRWQAU7Nxe4aBunwthrtlesvH3fGXnVHvjO+Q7W3i6L6X/2ijq/1vEeo3B1zEx0KLgNt5sXQMGDV3C1/Wjs086m61QXnbqsxYxUlVFbOQ/FZ270QNch2qa3Mz5rnA13l4mVu+YVoBmqAbk3TVVQxprL7iX+2/EEgZ0HYOfU8iI69j883DQGhce4o7XjPfzZdCD2CxsdoueMI77H/77/HpmXFUfLQq9weXNqVN40CtMo662LzDWMh5sWFqhqocu4Feizqy3mlo/+dkRLKDp/cn2iJaLeiGvR0Ksc1n8Rx0hN5Yos6VPO8KT7sKg0ZlSJMhoRPdTnzOaCRtWLxx0pf2YCyUaAQrEoJMuYRtlkuYSZMcRML6sSQbT6pmNNf0bu0WIJUMY5Sggg20Z/VwaT+jcAuT3SqhQ3JiBLgGYsG4/bKisuEpBEFlimciU8YymNjQWZABOwQQLkcmjsitD+uZ34gd0GvyspPWTyiKO8DDV7L5Wu90o6K88EwSIAnUNnUu4q8pN/yrG3qDNTzSxK/0yGo2yjVShydyQDkwxNbkxAhoCxBibFXPxvUCNNgWU2MGUIswwTYAK2SiA0NExTP1g21wJx0s63QCE03JhAchCgNbDgkFCNZxzFCMu28nkzRT8TsIEpSy1p5NjITBquVtcr1cwi11damaSHetnGhqYsKZYjAsYamBRzsXR8C5Gcwo4LLPNXiAkwASZggICjowPCjMy1QF0q+RbooZ/zLRiAzLsTTSAy8Z8KI2buhGziP+WkVH6PMio7peJyJQqTlHplIzOlyFvgeSmmg25Of0xpz4amBV4/c1c5IQYmuXBlz+wsYjA57tfcry/rxwSYgHkQcNDKtWCMRkq+BXJfpElnbkwgqQgoif8o+ZQxTamRbcwxLJt0BNjITDq2VtmzcnOijF2yGWcJhPaKJpWX4MYEtAkYa2DSsQuGfM0xQtoQ+T0TYAJMwAgClCiNHsqNaWRoTl6yX5PQj8NgjCHHssYQoFArYxL/Ud8UzkVhXRSHyc08CNiPF808VGEtLIlAJpe0aFy5ELYfvIo3QXIzmkeuP0bY23f4qlJhjbsNFdXlZrsEFHcYSij13aQdRoHYMaGZJtthqJiwoFI73JgAE2ACTMA4ApRrwaNwLs19me7Psk25l9epWEiTb4Hv5bLkWE6GACWm+mHlcRnRaBkK41o6vhU+BoUgdWqRRpmbWRDg7LJmcRksV4l/fP1RY+h6owZAPwYbp7ZDapFP3c6ODU2j4FmJMBmYijuMsbOV0zpVxrAutcXNhDPJWsnXgYfBBJhAChFQyow17L/M6Ng3ziCfQhfNik+bEK8m8qq7tq6/pnSZoyPXyDanrwcvAZjT1bBAXaqXLQBaVTKmKXEdZCRwsz0ClDSCHmwS6g5DBiYdz5lkbe+7wyNmAkzAtAQ0uRaERwjlWqCsnMY07TAYdp01hhzLxkcgoQYm5WagRD9sYMZHNWW38UpmyvK3+LOTu6Kjg73RWUFp4DT7xLW3LP4rYPQAPnwM1qQkNzZjnDJrrsy8G31iPoAJMAEmwAR0EqCC93UGrNRkktUpFM8O5bc5NFQ8D/BKUjyEeJMuAonxaqI+zy3qDIot5maeBHgl0zyvi8VoRQYmGZqNqhc3ekVTqb1Fs1fUeCbUYi57ghWlh5iinvMT7JbFBmaC0fOBTIAJMAG9BAq4faaZ+DUmqR91qKxohoaFcXkTvYR5pzaBxBqY5EVHBibVfuVmngR4JdM8r4vFaZWYFU0arBJnR66UHKdpcZdfr8LKjSQhrjDUsTJLzgamXsy8kwkwASZgEgIJ/a3mfAsmwW8TnajVAOV+TEjYDAHSTv5Hix3czJMAG5nmeV0sUqvEGprtKrtj8djmSJvGySLHz0p/SiAy/jIUv/z+t9HpyKk3NjA/ZcpbmAATYAJJTSAxhibFd1KMHDcmEB8Bei6gWqstf1hrtFcT9ac8F7x9F4QM6VPHdwreZiYE2Mg0kwthLWoohiZlne0wcbvRsR3kprPt19YaFwhlBcxa2NjiOMg9duA0nwTdSJSZSl7BtMVvDo+ZCTCBlCKg3McTamhyvoWUunKWcd7nL9+i8/iNCXouUAxMfi6wjGvNRqZlXCeL1DKhSQRosIr7bHh4BOztOXTYkr4AauEHQ3XTqP7lCK9DRk800FgVA/PdhxCk5xlxS7r8rCsTYAJWQMAUhuaCIV9r8jWEi5JVXM/YCr4UJhhCYp4L2cA0wQVI5i7YyExm4LZ2usSsZFF8x5zhTUDJCPgmZTnfHJqlHDxjJ9Yev2200tor2cpDjtGd8AFMgAkwASaQaALKb3BCVzRJAa9+tdGzZWVNQiDOt5DoS2KRHSheaYn5HrGBaZGXHmxkWuZ1sxitw0Tm2eCQcLQasSZBrhE0UOUmZTGDtkFFTbF6STXa1k1spZlUCBGp8FNxKnwb/CbxkJkAEzAnAqYwNDnfgjld0eTVJbF5GUhbNjCT95qZ8mxsZJqSJvcVL4Ew4fLqIFxeE5pFjDolA8RrZBNNrCa70MaLOUU3PnkZiGEzdiVo9ZIUp4cQrzHfcbKIFL2KfHImwASYwKcETGFoak8ihoWJZwIHDoP5lLT1bUmMNxvRUBYZOAbTMr8bbGRa5nWzOK2VH4jEuEvQoGlGa1T3OpoMtOxCm/Jfg49BIVi94yx6LTiQYGWU+Fta9XbgVOQJ5sgHMgEmwASSioC2odlv5p8JirUn3RSjgcuVJdWVSvl+Fc8met5LzHdFyc3wMSgUaVI7pvzAWAOjCbCRaTQyPiChBJSbFM1stR37B87cf5Wgrihub3S7Spo4jwR1wAclioDycEA3kAlL/9/efYBFcbRxAP8jTVFETOyKBcFeIVijWNGoqGhUbJ9do7H32BNLVIxGrEnsGk3svRt7wd5iD/YSjUYFpQj3zRzssZygIkcOlv8+D97e3ZaZ3yJ3787MO/sSdR2VxBDKTYhEFYw7U4ACFKBAkgmoP8Nr9Fr00YGm7Lni178esn+SMcnKygObT+DV61AMmboZ/jv+/KhCyO94yncDBpgfRZhsdmKQmWwuReoqSLDIGjp02qaP/iMktWT3m5Edq+qz16UuPfPUVrk7efryXUxZfOCju8bK0quTOilfXMxTK56VAhSgAAUSKmCKm8VLRjREFbeC4BCYhOonv+2V7wcfO32dUiP19Df8bqCopNxHBpkp99ql6JKHhb8RiV2s9NNc+E7cmqi6yLui/dt+rh+vmagDcec4BZQPj8SOu1QOLrvHftW8Mqyt0+h/B5TX+UgBClCAAilHQN4sTkxSP1nTnrWL4puuNdmqmXIue5wlTWzrpTyo+uYzezfFyZziXmSQmeIumXYKrAz+T+zAcEWEwaYiYZpHJbiU12fh+gCMW30qUQeWdyiVO9dyLGe6tDaJOh53pgAFKEAB8wko4+gTk9RPll5+Nkzs6okWdd3Yqmm+y5ngMyvfERLbeilPLG82TOhTnzefE3wVkvcODDKT9/VJFaULF9NVWIvpKn5aeThRCWQULONutEwQpMgk7NEU3WKVMyofIOntbBAuWrGtRSs2FwpQgAIUSNkCSovTiq0nkdheSbIla2yP2swin8x/JZR5L03Zu2lA++oICQ1DWlvefE7mlz9BxWOQmSAubpxUAkrgYapWTVlOGWx2ql8areu76bPRKglrkqoOKfm4yh1JWQeZ0Gf2ymMfPa+p2kHdehkaFg5bG2aIU/twnQIUoEBKF1D3SkpMQiDFgVnkFYnk+Sh7Is1cfhADFx1OVAFjfz94I74f8OZzokCT4c4MMpPhRUnNRVK3ao5bduSjs9cZG8oPrSa1ShrGbSp34oy3S63P5R3JpRtOwH/9aZOZK2Mv2XqZWn+rWG8KUCC1Cchxml3Hrk5UYjhpJgMQmUVeuUmc2hyTa31li/XguXsT/T1BtlrPG91UPxZXaWRIrnVmuT5egEHmx9txzyQSUP7gyMBn/NxdicpAa1xEpXXTu3pxQ6KB1BpwyruRuwOumazVUrFWj43l2EtFhY8UoAAFtC/wJiISVpZpTDb8RQabynQW2tdLvjVM7JRl6popc2MrCSDV73FdWwIMMrV1PTVVG+XDSo4N7Dphw0fPxxgfiryT1uaLUvD0cDEEnFpPpa4EljsOXjFp8C6N1V8G+OER328dX6cABSigbQHlRnFipzlRKxnnWlC/x/WkEzBlcCm/I6z7vrm+R5kyljfpSs4jJwcBBpnJ4SqwDB8kIP/Y9fhhW6K7acR1MhlwViubDzUquBq61MrtUmorp3r8qWwR3itaLA+fvmXywFIaKd2aWtVzh+way8mTpQqX5CEQjoizm7FgzVXseP4J3Bo3QO+qWZFWFi7yCDb/bxeWZrDUFzUyUwHUblUPHYrbwwIv8HChP/oeszBUwzrCHmV6d0XfIiffsZ9h87dXjM6nbGAXkgPVxv8PrdPtx9xDhdCxXg5EjUx6iNurtmLhoYe4lrE4vuzsBe/c0Ukxrm/E93+5Y0BtZVtAhwe4OvcW3nQpj2IxxVZOo3oMxuPlh3CxXi14ZoxnQ6OyxrYRh/p3r6qsOuD2LqyYdwprXjiiaJUa6NHYGVnkGa9vxdznldHVzT76/C/xz9b1+C1rE3R3Sxf9Gh+0LCC7z87+LfHj9xQjGWz2a1EO3p7F9bkW1PkElG34mHgBUwaXsjTq5H9hItmjjUj2yEX7AgwytX+NNVFDJbGA/MBatvkETDle0xhIBk0NPfKjYpm8cC+WFwWdPjVsog7eDC+aecU4EH78z0scu3gbR8/ewo4TN03eAqyurhzrOrRjTX1w+TI4FPbpbdVvc50CJhOwaLEt3mPpVtSJ471gBC8fDs99nvhuZF3USXcOB/2XYZBFe6wfURJZIlZilIclmp30QTERouHufmyZsBY/e4/GWq9wXG4wEStmTsZoJ6NA7J37ZYouxzM8GNYWuf/sjktr68LVuHTbvobb7aE42SVXzDuBo+Hm543DM8vCNvIsDlb/GX5tu2FKmyJwurEeczofw+UpwzHTQwRs2zsjX/PMaHd6HEbnjwpJdTiFjW77EXqiD75Uiqzbil8cZmHOjJ9wvG0OETzL5XH8dVNK8746qst6/juUH+WMof5N0dDuPA4tX4uRs0tg7PnmqBCrnqF4s2YwSm1ohA0LPeGsnIuPmhZQWqxM3SNJubmpDH1Jjp/NKeXCKj24ZE+nJRtP4JdNZ0z2vUFeJ2XqMib/Sym/EaYrJ1M5mc6SR0pCASurNPqj21inQZcvK0K2miVVsHn739f6Fj//HX8aaiTHGZZ2yQaPkk7ImSVTrMDTsFESrygfBOrTyAmQr9x6jOPnb+PCtYc4euWhyT4c1OcxXpfB5dctK+u7GcuusXJhgGmsxOdmFXi2CAO//Qw/nm+IivpPOndUHpkZ/t4icDw7HTOLq0snwq/cVfFFr50YPOMvvPTKq37zHeux9wv1EgGi3Dp0J+YtK44Ohfbh11teGJ036u/XOw6keisC+G0GOnsPxukOBaNaXQv7oOf6pxjgsQp7r7eHJ2xg19IOuztvhs+2higZ5ye5CJx3bsbYVm7wmHIEF9v6IFaVVWd892o8ddTvFIY3ex7AqecANMwlW1ndUKm7G3Z3Nz5iOHB4KrzW1cdv8xlgGuto+bmSMbRM4dz4Y3Ynk7Vqys/prjP36H+Y2C9xv0GB957q58JesvuSSXuKqW9Cyy7UzC6fuOuUEveO86MpJVaEZU4dAsr8isbBpinvvMUluezwjehseTEpu2UXW+ccmVDcJTtyZnNArqwOsLdLa/IAVAkkXwaH4PJff+NFUAjOXHuEA3/eN+kHQlz1Vr8m70j2bFgGrb3dYwWXNpzzUs3E9WQhIAKsAxdxpO83mBXrU64A3HqkQbsDD/F2xCVullx4glc57UWgGJmAWsTsF9UBTDzfvBe/9uqDP3NORJ7lf2H4kILRXWDff9hw0dJ4db49ms9zjgowlV0yN0Rnj7FYeCMSnjoLpCvTEhucJ6OWaDU82LNAVHCrbCsedbiJU98DPrM64ctLYzD7bAPMLPWxUwgZ11E5kQ2sStnixM87cbhsfVR0iCeYvjEVzTo64bvzNVE81vVQjsPH1CAgbxbL+RAb1SiJ3pM3mGSaLOk2bvUp/Y/SlbaGhyuyfKJ00U4Nsh9eR6XFV8nPYKrpytQlkNdh7lDv6LGX4gaTWJTvburtuK59Af651/411mQNlT9YSrApWzflGIKk+IMZH+CW8/cB+aNq8VRvK4NQR/uYcUeZM9jqA1L1Nsr67Yf/4uaD58pT/aMMbJPDIj8w5HyjyphLpeWSwWVyuDosQ9wCooUtUAeXkpnffts1C2w2PEaoaKBLf2cn+ve5CsewCOR8dA7zIhvjt0UFRTvhE1jmuYOV4/1wxSIchvGYxWRrXfz7yQ9UHW6JLq8Z0XaJC/CJF74qtAe7BxeElzjfhywWuI/Ap04olsd4h4xwLheOG7dDow6js4Nj7zYYUH4OxtQci/FFYh/d4tlWzA6ug0GiBcn1G1v4rr2OaaWK4EPDzPhs3vrS4DkJN9IvwnctmqG+ZUV06dgQ/ZUxmRY6vL6+Ad13Ck+E48yTSFTMHk8gGrv4fKZBAaVVM28OR2z27wBTTYehUB2/9RS+E7eKp1v1YwBrVy6E6p8V1I/dVLZJjY/qcasHT9/AjsNX9UG5qS2ULszy+5hc5NhLtl6aWjllHe+tz4uUVXyWNrULKMFm+JsI1K9STP8jx36s3nkuSf6IJsRbH4Qa7xBPQGq8WXJ4LrsIt6hTUm8qyyPHXMqFwaWegf8kdwFdBEJF8PjWEvYGYdFxTnCeWpgyTY7JjFqmqDaOuJMHX84c8PaYTLGNYb/nyzGulCWmnG0Br4xRO1vcWYk5l4PweNJE/BkZgjQOt3HpcBt4VYq54aQ6TdyrkeEIlQ0AUTFt9DaRCAsxqo9VZbRYcADL2qzD0YDSqmOJ/6urDmNNlicI/uocMqazgtOSP7B1WBF4f2CU+a46qk4kVq1h8VknjNwqfv49jN3+0+G5vnH0uMswBG4OQr/d49Hp/CAU7LMXXiuqczxmbMBU98xaJH2ReRZa1HVDg6olTNaFVg0ph7soQ15k0hnjgNM4l4F6X62tHzgVFViaujus2kk9hEZJ/sfkPmqh1LnOIDN1XnfN1draKiZTWYmCOfTdNGRCmo37zuOHFcf+k3GKWkA17hIr66R8YHDMpRaucGqpgy2sPNLj0vobCPYqhfSGaodCt/cRHCo5wVZngp4CDj4YNqwjskw6hxbjSorzhOCNaDG85z8Je3yiW1FPDITr0j8RVMkNGQzliH8lTIRg7tXnYPDx12itCkx1uIYDq7OiQkcRrJ5Q9hetnSV6YLHvQHjOSI9B4mUZl+pwAZtmumLsvpHo7iC3fYHHdv3R42AwvKvJ5wlY3qrjO/bNVBHVR2TDT9VmYMntqhits0XR3i3RKbv4qpG9J9YsGY8B28tijVem6CRE7ziVEfFbAAAZuklEQVQW39K0gJJnIY244SO70MphGKaeF1sBVAecsodRwyqFUb2ca6yhLVoKOpM6o7ziKh/lzejR3WrpLWViH7mkS/uBd7L0W/MfLQswyNTy1U2ldbOKDjjTpLHQ3ymVd0vlfF3rdp/D73svM+A0+r2QgWWbGkVQu6IrqrgV1L+rfFjIJ/zAMALj05QhUMEXE/ssxthLEzChSHST4NPlGDZVjAc7HpMxOnGVEWl+OnXG9ILL4d+jBIbkOIRfJzuh6QVVN123OhjeeDMWj3GLDvjefUY7OMCxe34EN9mAIydEhlb9p3Q4LDbOQ++KrXHgraKL7ft1xvia49HrUTWIYZiwOLEc3YvUQ4A+wJTny4gsjRxwZEoAHlQr++4CvPWuUR1zxnTjjcA5bO96CZjcTLTkRr1uEX4HNx86IqtDzHZRh8yPktMqoYTHfCw90RdtMhm//9aJ+UIqEEiXNur/5qeZMmD6Nz5o7+OBKYtF63wSDReRPYz0vYxE0iD52RdfJvm4Eu0ll8thXDYZVJ64eOc/ySivGMjgsn/bz/U39JUhNOwaq+jwURFgkKlI8FFzAurgKE92B/3dUnnHlAFn1NyWMrAsXyovqrm76KcgCRfjJ2S3Y9kqzA8Lzf13SPEVinuakndUy+IzNN7+Avi6HfLqSqJJxr+w7IYb/LZ1xZcyJ4hRz1PjI6nHZCrvpanoi4WtlGfRjxaV4Dt5GXLPOI8hTffj+7pe2GMI7sQ2ohxftF+CjkeD0N0rui3TxhFZMrxjbKLzAKyaNwc9i7VH/3qF4XbhAva4fYXVfp9FzT9pVAR5jnpz3bGitExYFIrH616gbLsyyKHezq0uvj1yArvD3VFONd5UbmI85lS9m35dVcee42WLbdRiKToa1+p0DKO8m6JTLg/UzvYEt9ZEoPDK0fBXGygHzNwK304dANdJZ9F4fOkPatlVduWjtgWsLKP+P8ieSEvH+6K/GPaSlMGm1HxXJvnCztlQOF+2WK2dyhWIiIyEpWyCTeJFSdKjPo2couzSzUf6JID7xdzX/3UCQOPgMmrOS4YS6mvE9RgBzpMZY8G1VCAg02hH6nSGIEoGnHuOXYX8Y51Ud06TC6tM4NPMs7B+GhalxVIGlm8iItlamVwuEstBAQpQgAJizGYEZK8kmWNhwZoAw/hKc9AoSfyqiLmzM4oEfoXyZ9MXQ07LkhSLbJl88PgF7v39HPcfPddPT/Y0KNSs31HUwaWss3JDOinqz2NqR4BBpnauJWvyEQKvXoXBzi6qu06wWD956TYCzt3GH6dumiy9+kcUyyS7yKCytns+fWule7E8+mlH5IFDQsNgaWmpb7E0yYl4EApQgAIUoEASCCjBpgy8Zvx60OwJ/eKqovysdc3laHgrXw4HOGXPZHge14oyFZny3rOXr5Pldw71HKSyW6zs5K4kXFTK/v7Hl3i+bgTGTF2J9edCcS9nOXg26YxR/b1RQT3t0bMD2DZ+FKavOYN9ofmRr6I3Og/vjd4ljcdwhyJyakVkGXvzrVNbhjvBc/UB/F4ruteIOOaOkUPw/dbL2GtRDOVrdsa4Ca1QLZPSEh2CkK390bf3Miywroc2E8fDv37emOmjgndhaYNZuOi3FBPK2r11Pr7wbgEGme/24bupSEAmuLEW83gpYzpl1eVd1OPnb+vvJB698jDZjueUY0s+L5oT8k5r4QJZ4ZovqyGolPVQkvfIdS4UoAAFKECBlCQg8wTIYRzyZvCyzSeQ1HNjpyQbU5dVfp8Y1qoCvKsX13+PkIF+pJh6+OOyxYZAN/8L5BjvjHZTB6J/gwJwvLgCq0cNQceIqTi19ku4ygo824gF1bvBr6YffujtA6/053Bkxlys/twPfp7vDtij6i+GCmxrCTefT9D9/kx0lLuE78O68k3R220K5o5qhjoRW/F7v55o988I7NrRFRVlfqKHMzHIZS2e7VyOn9OMQ7Mar+F5Yza6Z5VB6Au8mlAd2c6OxIUV3sgbdSL+mwABBpkJwOKmqUtAdgcJF1MgKC2dSu1l4Kl0Y5HdbOXyX3W1Ve6YlnbJJrrtpMVnJZyQI0vGWAGl/EAIEeXOEN1Cq5SbjxSgAAUoQIGULKC+Ybr/5HWs2n7OrF1pU7Klcdlll1j1tGWvQ8LEUJropGnGG3/gcx3OY1/lz9Gl6XFc6eMSk1X68lA0KxqIsneXY0jOZ/jnm0rI+9dEXPzoYO4Kjnt74kv3Lbg0sgzSibHpmF8HdlPrYfPpAaimDBsN34HFuVpj7g8ncaB1LqT5rT7Srf0Kf61ogOy4gZN1PTGw3Un80TyrGLQ7Bd3LnITTycUYkk85wAdWnJvpBajGXwQKxCMgE+Cop0aRm8nAs2CeLPqMavK5MunwUvlELDIAlcvL4BD9wHz9E/GPcdcY5XX1Y2Yx1qO4S3bDS+qxH65OWfXJeQxvRq/I7r4y1Yd6kS2xGcQPFwpQgAIUoICWBJSEfvKzuGKp/PqM6BP61NdPV7Zky9lk2eU0OfvLG9ed6pc2tFrKsiqBfGIDTHksCxG6FSzrgLv7A3ChhwtK6Gc3CRPTMJ3CSbvyaP2p6IAbuguL/NOh8ebqH99aeGYuxmytjHY/lhABppzGKRBHlp9F1tazUFUd6ViXR4POGdF+VQButPaG8/1H0GV3hMwHbiGycGcWw2z//idYPLuGs/38sXvgRpxhgCk8Pm5R03/cEbgXBVKRQFyBp7r6MgCVi411GsN0IOr3E7r+MljcjROLlWXc6f6NW1kTenxuTwEKUIACFEhpAuobwOrpypQ5Ihlwxn9FZWApkwA2qlHSkD1X3rBWFiWQV54n7jELco+Zg8VtOsKj/G506FUNVQL8MGJTaTTb2QcNZENpwD5sCnVHbas1mNFqMpbuvYsAuxJxjJ+MuyQ63EfgzJU43G0pluSPCmssdIG4eDoNSvXNCWX0ZdTeGeBY0hU55l4WYaQPXD4VY2kDnuKpeDO76B775I4l8tQT4zn3DED7w13w45KooDXuM/PV9wkwyHyfEN+nQAIE7NOLOeVMuJj6eCYsGg9FAQpQgAIUMLuAOihySJ/WMD+2EnBuOnD1PxvSYnaMeAogM+RWK5svVmApkwDKjPsykU+S3rB2/Bxe/f6HHp39sWjSQWy/5Qinbzujg7tjVPfZJ49xM8MhjOn5Gu17zcOyhWWR92rUuM16LS0QsKU1isdTL/myxfWfMGZhEfge+wyG9EuRQQgKygRba+NeXSLktM+A9EEvEBwpbt571kWnr6Zj5NEK+PmNH8Yf8oL3gotYWGEfnOZPRJ2TA9Cx5RysC7ZHhMcwrFjRHXXUyYreUS6+JRpIiEABClCAAhSgAAUoQIGULqDu4ulob2cIOOeKljqZPX7H4avYceJmsk3iZyp/mbynoUd+1K5cCOrs8jKBkhJYprVN3HjLDyvrPdwdXh+lf3dH53lXcMczJ9LeXoklPZqh1KaBWLO2N+rY2iLDyyoYvPIXjC4QfaO+WGs0/+Eu9uRfhPkXm+GHYvGV9Sn+WbACy+uPw1V19lcLG5Eo6jVCxTRtcS0RsIWt7CCWpwvGL72OwW1dkFZkl/3f2tFou9AXOcpPx5kq+zA59xb8s+wmHtcNwpX/VUal4SVww79qTDAb18H5mkGAQaaBgisUoAAFKEABClCAAloQsLWJ+Yorh5woYzjHisrJVs4TF+/g6NlbOH31YYofyym7wJYvlB0VRYZ592J5Dd1g5XUMUnWFlRl6/9Pl0gz0m5gfnS/MwIRC0QGkUzO0WZML9hUboPeCerjSpBgqRBxEaETM9dKXMZczClv/giP3RVfe+ILMp2vw41Q7NNpQE/lUFdOlKYCiJYMx7erf0H3hEJNwCK8Rcv4y/qrWGEX0o5DskbHRbMyWP3J/meynuSuGnfwCzie7YU2wF3rU+FR0uf0ERXzckb79QQRMrwov/b6qE3I1TgGjKxrnNnyRAhSgAAUoQAEKUIACKVLA1jZ2cOWQPh28KhRG/SrFDPWRifuuBD7CheuPknXgqQSUMlGgzDBvnBhQyeWgVMysmebv38VVixzwyh17KJHOOjcKOFvgwf1nCMlTFV84T8KInTcxzsU5ZgzlvRu4HFEKRV1kKp+4ltd4s2guJpTuiqM1HWJtYIECqCDmuwzceBAXRFbbEoZ3L2Lv73fh0sYNzobXlBWjZD93RFdc2SLKSEkBSvAjpzBJMBl3oAAFKEABClCAAhTQioDMViun/1J3t5V1u377CV6+CtHPl63OEp/U05bJMZSO9umQL4cDnLJn0s9/bS/Gm5YpLNKfqhY5rlIUO/lOWRa8ET+Lrq8TG8zDkrE+qKAfz/gQD5YNQp/Od2G/Zz1+KZ9WzHHZDp/7vESpPYvgX16M1Xy2D9u/agtf21k4s6genPASL379DsNtvsKkpvkh9hBNtL9hslMfbJ1zCrub5VC1VkYDBa2Gf94u+OmrlVgzqjpcrO/j4XeN4fFLXfj/ORoN06sgZZ7+Pe1RtnUhjL/xDerIuDZoCcZnn4SAlX9gjdJdNuMydpdVs71nnfH5e4D4NgUoQAEKUIACFKCAdgXiyxyfK6sDdJEZ3wrulkZTyG63Dx6/MMDIltAXQVFZ4Q0vvmNFtkQqi71d2ljdXJXX5aM+Sc8bnWE8pfLefzOuUjnbRzymr4/Ou2YgfPQwdMvXGXfTyFyvNnhTqBE6r1uCseXtow5aZw62LPoaXX3z4dMXVrCIzIkcHfywaWRdEWDKKUke4NqKefjZrjIGiCDTSbyC08dxsOAgDG4UR4Apj5rBBz0DXiJNt2aomF0nwkgbRJTuAr8/hhoFmGLbcDGNSsfjcFn8A7yUhtMMLfDNtrMi8U8+ZFES/0z/nOMxpe0HLmzJ/EAobvZfCrxE0I4RmDb/DPZcC8KzT0sgm1cLjOpUCxUyqpJRPz+AfbN+wqLtl3A6PDsylq2Bxt07oneRjG/f0YpV/BDofv8Ctb8Pw/0+y3GxbZ6Yd8Ux90/1x097A3HWMj8yVWiObwc1RjXDeUMQtrc/vh17HFssy8Nt0GD418gVdVdNHuX1LqzvsA5Hh03GhOLKX6qYw3ONAhSgAAUoQAFtCISGhiPsTdRs1XLcp3FL6PtqKRPxhIVH7S+3ZUb594nx/ZQkoPrGnpKKzbJqV0AGgA1Re6INgjrNx28nj+G4fw30uD4WtQZuwlWl4s83YlX7Eeiua4rmyw/j9JZRmOr6BHefywl137Pcm4lvJ79EiI24E6ZewvdhZ4f+aBPSDK2XH8T5xb4Y8nQqWnRbhsNvojd8PA9Tez7Do0nbcGpSGqTt64/5/ygfEC8QsmCImFzYG90YYKpluU4BClCAAhTQnIAc6ykDQ/mT0ABTYshEPMr+DDA19+uR6ivElsxU/yuQvAB0OI9jLVqhba0NuNIxX0zAeH0oetV9gZwHZmBI9mf4d3Jl5L49DRf9ayNvgqpwBee7+KJ+0cGYsX8ihjRaH92SKbq3rKiDskt8MWV9F1RTOpKH78Da2t/Cr+dKHPDJhjSb6iPd9r74y7+WmLj3Bi50aIlePlvwR/1PgHtTMNr7JtKum4YheYznZkpQIbkxBShAAQpQgAIUoAAFUqwAWzJT7KXTZsEtROiWr1A47h4/jQtK6yFE+urzp3Ami0hJ/YlopwzbhTXznNG4TeUEBpjiOJsHouetDpjbvTQyydHy0YsOgTi99Qme1q+GqkqAKd+zLo/q9R7i6LbTuCMHhj98BN2nmZBZvGWBjHDMFoS/n74Sz67h8viVWN6xB3ozwJRyXChAAQpQgAIUoAAFUqkAg8xUeuGTb7WzIHu/H7AqfDJ8fQaix6o12DS8CWr4F0WlGZ3QQGYh/3MfdlsURTHLbVjcpxGaVHRDiRrN8Pnw1fjjhdJ1NY4aPlmIKSPSoeCE9vCyCY61gYUuENdOOqKUmGcq9n+KDHAo7Ar3S9dxGaJ1MrMj8ORfPBV76/ACTx87IE82kaLs0FgMuNIKP3YoDI7EjEXLJxSgAAUoQAEKUIACqUwg9vfpVFZ5VjeZCjh8jqodqsI3eC/O/DwTP2y2hM7XFx1KRk+o+/Qx7tsdwLLR+3G08mhM2h+A07O9MejpNNTrsw4X4qyWaGkcPQd+TQZgctlYeaujto4MwqtXYj4ka+NuruK/iF0GpH8ahBeRohW1fF0M3bcQI089hcVxP8w6XgXepa9gdf/7sBreAnXOD8DgKmXh4VYeju0XYNsLo3GfcZaNL1KAAhSgAAUoQAEKUEA7AgwytXMtNVKTe3joVxvVRkcgaOxG7N6+C3s2tUTPY/1Qqe0vUUGbrS3swsuiycxJmNW0NJytLGHl2hoNhtdDvwNrMP+qoZ9ttInsJtsfPS+0wI9fu8edflpMuGttE47Q8JgutGrQN+lEACozCuXsgv5+GZFtkBi/Odwaupld0G51T7T7bCCmlduDXzpdwJUxu3H05AqcyDwNLacE4Jn6QFynAAUoQAEKUIACFKCAxgUYZGr8Aqe46l2bgXHziqHG3LGYUCG7mBpERHa5mqHxnIlY9noOev8eCBQohjLBrxAaYdTqmM0ZBSMe4u4jEVSqF91urB57Hc+Dfodfjc/g4e6Ocu4iWLxvjfTTG6N8mcZoc9oFzqWf4VLgP3L2JdXyGmFXLuNgcWcUkUEm7JGh9myM3RWAU9unY27+tZg0rwKGDaqBfOd3YltYBTSt7Ci63OaFs1d+FNpzDAGqo3GVAhSgAAUoQAEKUIACWhdQpzjRel1Zv5Qg8PddBKbJi8bZbWKVVmeVG065g8Skx88RkqMqqrmuQt8D9zAuv1PMGMpHN3DdUiQHypc21r6wqIsmR8SP6lUdTuGgd3t0a7opOrtsMMKqWCBQBIUXOuZDCcO2F3F0hxVc6pWCs+E1ZUVJ9rMQZ2SynwfydWvYGsW+ytZ8pAAFKEABClCAAhSgQGoQYEtmarjKKamOZZuhTY4dmDBxM44Ykvg8xON1YzDzUBk083IVrZvuqDG4EAr/OAa9Tj2Panl8vg8Hvt+EWd4t0CGP+LUOP4ujI37EvNtGrZrxWqSHTbuRmB84HS0nH8I1fY/b+3gyvQ+GvmiNSS0LxASz+mOIBEPGyX6KVUVNi4NYtu+ZyEN7Cze2B+JK9XLwiPecfIMCFKAABShAAQpQgALaE2BLpvauacquUbr6aP7LvwibNhPjqo3E3xaij6rOCmH5qqHmtF6YpCTt8ZyDBWO+xtC+1VEuWG7zCV43HoJNvTzhJAWeH8S+deuxrZwvOjpljcMkK3JWrwtvF/uY9+x80ObXl8CIAWhTLlwEilZ4VuhLDF7wNRraxWymXwsX06j0f4b0fq3hpTScpm+BbgvPInBADZQfYINrJftg+SiPuMeAGh2OTylAAQpQgAIUoAAFKKAVAQudWLRSGdaDAhSgAAUoQAEKUIACFKAABcwrwO6y5vXn2SlAAQpQgAIUoAAFKEABCmhKgEGmpi4nK0MBClCAAhSgAAUoQAEKUMC8AgwyzevPs1OAAhSgAAUoQAEKUIACFNCUAINMTV1OVoYCFKAABShAAQpQgAIUoIB5BRhkmtefZ6cABShAAQpQgAIUoAAFKKApAQaZmrqcrAwFKEABClCAAhSgAAUoQAHzCjDINK8/z04BClCAAhSgAAUoQAEKUEBTAgwyNXU5WRkKUIACFKAABShAAQpQgALmFWCQaV5/np0CFKAABShAAQpQgAIUoICmBBhkaupysjIUoAAFKEABClCAAhSgAAXMK8Ag07z+PDsFKEABClCAAhSgAAUoQAFNCTDI1NTlZGUoQAEKUIACFKAABShAAQqYV4BBpnn9eXYKUIACFKAABShAAQpQgAKaEmCQqanLycpQgAIUoAAFKEABClCAAhQwrwCDTPP68+wUoAAFKEABClCAAhSgAAU0JcAgU1OXk5WhAAUoQAEKUIACFKAABShgXgEGmeb159kpQAEKUIACFKAABShAAQpoSoBBpqYuJytDAQpQgAIUoAAFKEABClDAvAIMMs3rz7NTgAIUoAAFKEABClCAAhTQlACDTE1dTlaGAhSgAAUoQAEKUIACFKCAeQUYZJrXn2enAAUoQAEKUIACFKAABSigKQEGmZq6nKwMBShAAQpQgAIUoAAFKEAB8wowyDSvP89OAQpQgAIUoAAFKEABClBAUwIMMjV1OVkZClCAAhSgAAUoQAEKUIAC5hVgkGlef56dAhSgAAUoQAEKUIACFKCApgQYZGrqcrIyFKAABShAAQpQgAIUoAAFzCvAINO8/jw7BShAAQpQgAIUoAAFKEABTQkwyNTU5WRlKEABClCAAhSgAAUoQAEKmFeAQaZ5/Xl2ClCAAhSgAAUoQAEKUIACmhJgkKmpy8nKUIACFKAABShAAQpQgAIUMK8Ag0zz+vPsFKAABShAAQpQgAIUoAAFNCXAIFNTl5OVoQAFKEABClCAAhSgAAUoYF4BBpnm9efZKUABClCAAhSgAAUoQAEKaEqAQaamLicrQwEKUIACFKAABShAAQpQwLwCDDLN68+zU4ACFKAABShAAQpQgAIU0JQAg0xNXU5WhgIUoAAFKEABClCAAhSggHkFGGSa159npwAFKEABClCAAhSgAAUooCkBBpmaupysDAUoQAEKUIACFKAABShAAfMKMMg0rz/PTgEKUIACFKAABShAAQpQQFMCDDI1dTlZGQpQgAIUoAAFKEABClCAAuYVYJBpXn+enQIUoAAFKEABClCAAhSggKYEGGRq6nKyMhSgAAUoQAEKUIACFKAABcwr8H/mRaFLPB/qmQAAAABJRU5ErkJggg==">

## 2.4. Breakdown of minimum capital requirements by risk type

In accordance with article 92 of the CRR, the entities must at all times comply with the following capital requirements:

a) Common Equity Tier 1 ratio of 4.5%, obtained as the Common Equity Tier 1 capital expressed as a percentage on the total amount of risk-weighted assets.

b) Tier 1 capital ratio of 6%, obtained as the Tier 1 capital expressed as a percentage on the total amount of risk-weighted assets.

c) Total capital ratio of 8%, obtained as the capital expressed as a percentage on the total amount of risk-weighted assets.

Regardless of article 92 of the CRR, after the Supervisory Review and Evaluation Process (SREP), as of December 31, 2016 the minimum Common Equity Tier 1 ratio should be 9.75%. As of December 31, 2016 the Group has a phased-in CET1 ratio of 12.18%, which is above the regulatory requirement.

The total amount of capital requirements is made up mainly of the following items:

- **Credit and dilution risk**

Risk-weighted exposures for credit and dilution risk, excluding the amount of risk-weighted exposures for the trading book. When calculating the risk-weighted exposures, the credit institutions may apply the standard method or the method based on internal ratings, when allowed by the competent authorities.

- **Counterparty credit risk**

Counterparty credit risk-weighted exposures corresponding to security financing transactions (SFTs) and derivative operations (section 3.2.6. of the present Document).

- **Market risk**

It arises mainly in the trading book and includes capital requirements determined with respect to the debt and equity instrument position risk, the exchange-rate risk and the commodity risk.

- **Exchange-rate risk**

The capital requirements determined with respect to the exchange-rate risk, the liquidation risk and the commodity risk.

- **Credit valuation adjustment risk**

The capital requirements determined with respect to the credit valuation adjustment risk resulting from OTC derivative instruments that are not credit derivatives recognized for the purpose of reducing the amount of credit risk-weighted exposures.

- **Operational risk**

The capital requirements determined in accordance with title III of the CRR with respect to operational risk.

In addition, as stated in the introductory section of the present Document, Basel III, unlike the previous framework, introduces capital buffers as a complement to the minimum capital requirements. A transition period ending in 2019 has been established to facilitate the adaptation of financial institutions to the minimum capital requirements.

The third part of the CRR sets out the capital requirements, in accordance with the new Basel III framework, as well the techniques for calculating the different minimum regulatory capital ratios.

Below the total for capital requirements is shown, broken down by type of risk as of December 31, 2016 and December 31, 2015. The positions in securitization (standardized and advanced measurement approaches), equity and the counterparty credit risk are broken down separately.


**TABLE 7: EU OV1 - Capital requirements by risk type**

<table class="l">
    <thead>
	<tr class="m">
 <th colspan="2">(Millions of euros)</th>
 <th></th>
 <th></th>
</tr>
        <tr class="tableizer-firstrow">
            <th></th>
            <th></th>
            <th colspan="1">RWA (1)</th>
            <th colspan="1">Minimum Capital Requirements (2) (3)</th>
        </tr>
        <tr class="tableizer-firstrow">
            <th></th>
            <th>12/31/2016</th>
            <th>12/31/2015 (4)</th>
            <th>12/31/2016</th>
        </tr>
    </thead>
    <tbody>
        <tr class="b2">
            <td>Credit Risk (excluding CCR)</td>
            <td>309,046</td>
            <td>320,147</td>
            <td>24,724</td>
        </tr>
        <tr>
            <td>Of which the standardized approach (5)</td>
            <td>215,908</td>
            <td>218,072</td>
            <td>17,273</td>
        </tr>
        <tr>
            <td>Of which the foundation IRB (FIRB) approach</td>
            <td>-</td>
            <td>656</td>
            <td>-</td>
        </tr>
        <tr>
            <td>Of which the advanced IRB (AIRB) approach</td>
            <td>89,589</td>
            <td>97,913</td>
            <td>7,167</td>
        </tr>
        <tr>
            <td>Of which equity IRB under the simple risk-weighted approach or the IMA (6)</td>
            <td>3,548</td>
            <td>5,507</td>
            <td>284</td>
        </tr>
        <tr class="b2">
            <td>CCR</td>
            <td>11,888</td>
            <td>14,398</td>
            <td>951</td>
        </tr>
        <tr>
            <td>Of which mark to market</td>
            <td>9,473</td>
            <td>10,053</td>
            <td>758</td>
        </tr>
        <tr>
            <td>Of which original exposure</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>Of which the standardized approach</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>Of which the Internal model method (IMM)</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>Of which risk exposure amount for contributions to the default fund of a CCP</td>
            <td>93</td>
            <td>511</td>
            <td>7</td>
        </tr>
        <tr>
            <td>Of which CVA</td>
            <td>2,321</td>
            <td>3,833</td>
            <td>186</td>
        </tr>
        <tr class="b2">
            <td>Settlement Risk</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>Securitization exposures in the banking book (after the cap)</td>
            <td>1,477</td>
            <td>1,395</td>
            <td>118</td>
        </tr>
        <tr>
            <td>Of which IRB approach</td>
            <td>332</td>
            <td>346</td>
            <td>27</td>
        </tr>
        <tr>
            <td>Of which IRB supervisory formula approach (SFA)</td>
            <td>1,144</td>
            <td>1,049</td>
            <td>92</td>
        </tr>
        <tr>
            <td>Of which internal assessment approach (IAA)</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>Of which standardized approach</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>Market Risk</td>
            <td>16,370</td>
            <td>16,159</td>
            <td>1,310</td>
        </tr>
        <tr>
            <td>Of which the standardized approach</td>
            <td>7,112</td>
            <td>6,804</td>
            <td>569</td>
        </tr>
        <tr>
            <td>Of which IMA</td>
            <td>9,258</td>
            <td>9,355</td>
            <td>74º</td>
        </tr>
        <tr class="b2">
            <td>Operational Risk</td>
            <td>34,323</td>
            <td>33,291</td>
            <td>2,746</td>
        </tr>
        <tr>
            <td>Of which basic indicator approach</td>
            <td>6,444</td>
            <td>6,457</td>
            <td>516</td>
        </tr>
        <tr>
            <td>Of which standardized approach</td>
            <td>10,781</td>
            <td>11,384</td>
            <td>863</td>
        </tr>
        <tr>
            <td>Of which advanced measurement approach</td>
            <td>17,098</td>
            <td>15,450</td>
            <td>1,368</td>
        </tr>
        <tr class="b2">
            <td>Amounts below the thresholds for deduction (subject to 250% risk weight)</td>
            <td>15,848</td>
            <td>15,896</td>
            <td>1,268</td>
        </tr>
        <tr class="b2">
            <td>Floor Adjustment</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>TOTAL</td>
            <td>388,951</td>
            <td>401,285</td>
            <td>31,116</td>
        </tr>
    </tbody>
</table>

<ul class="cita"><li>(1) Risk-weighted assets according to the transitional period (phased-in).</li>
<li>(2) Multiplied by 8% of RWAs.</li>
<li>(3) Under CET 1 requirements (9.75%) after the supervisory evaluation process (SREP), the requirements amount to 37,923 million euros.</li>
<li>(4) Shown for comparative purposes only and corresponds to proforma data as of December 2015.</li>
<li>(5) Deferred tax assets arising from temporary differences, which are not deducted from own funds (subject to a risk weight of 250%) are excluded, in accordance with Article 48.4 CRR. This amount amounts to 7,653 and 6,110 at 31 December 2016 and 31 December 2015, respectively.</li>
<li>(6) Significant investments in financial sector entities and insurers that are not deducted from own funds (subject to a risk weight of 250%) are excluded, in accordance with Article 48.4 CRR. This amount amounts to 8,195 and 9,786 as at 31 December 2016 and 31 December 2015, respectively.</li></ul>

## 2.5. Procedure employed in the internal capital adequacy assessment process

To comply with the requirement of Pillar II of the Basel Accord, the Group carries out the internal capital adequacy assessment process in accordance with the supervisor's guidelines.

The Group’s budgeting process is used to make the calculations both for economic capital at risk allocated by the different business areas and for the regulatory capital base.

Economic capital is calculated by internal models that collect the historical data existing in the Group and calculate the capital needs to develop the activity adjusted for risks inherent to it. These calculations include additional risks to those contemplated in regulatory Pillar 1.

The following points are assessed within the internal capital adequacy assessment process:

- Systems of risk governance, management and control: Review of the corporate Risk management culture, Internal Audit and Capital Governance. The Group has developed a system of corporate governance that is in line with the best international practices and adapted it to the requirements of the regulators in the country in which its different business units operate.

- The Group’s risk profile: Measurement of the risks (including credit, operational, market, liquidity and other asset and liability risks) and quantification of the capital needs to cover them. The analysis and valuation of the Group risk profile supported by a description of the current situation and projections by type of risk described. The valuation is supported by both quantitative data and qualitative factors.

- Capital resources target: Capital distribution between the Group’s companies and the targets set for it. The capital management policies designed to comply with these objectives include: regular estimates of capital needs; continuous management of the capital structure; and concentration of the capital surpluses in the Group's parent.

- Capital planning: A projection is made of the Group’s capital base and that of the parent company and its main subsidiaries for the next three years and capital sufficiency is analyzed in accordance with the regulatory requirements and objectives set by the Bank at the end of the period.

Furthermore, a stress test is performed using a scenario in which macroeconomic values are estimated for an environment of greater economic downturn than the one budgeted, as determined by BBVA Research, and the consequences of this on the Group’s activity (increased NPA, lower activity levels, higher volatility in the financial markets, falls in the stock market, operating losses, liquidity crises, etc.) and its impact on the capital base (earnings, reserves, capacity to issue equity instruments, allowances, risk-weighted assets, etc.).

Estimations are also made on the possible cyclical nature of the models used. The stress scenarios cover recession situations in sufficiently long periods (20-30 years). Finally, backtesting is carried out on the data collected for the previous year.

- Future action program: If the conclusions of the report so require, corrective actions are programmed that enable the Group’s equity situation to be optimized in view of the risks analyzed. The main programs for future action are focused on models of: credit risk, operational risk, market risk, real-estate risk and integration in management.

This process concludes with a document which is made available to the supervisor every year, for supervision of the targets and the action plan presented, enabling a dialog to be set up between the Supervisor and the Group concerning capital and solvency.


{% include download.html %}