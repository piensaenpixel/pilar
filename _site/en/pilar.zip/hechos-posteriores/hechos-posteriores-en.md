---
layout: default
title: Hechos posteriores
lang: en
permalink: /hechos-posteriores/
submenu: hechos
---

Hechos posteriores