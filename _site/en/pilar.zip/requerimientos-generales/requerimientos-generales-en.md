---
layout: default
title: Requerimientos generales
lang: en
permalink: /requerimientos-generales/
submenu: requerimientos
---

Requerimientos generales