---
layout: default
title: Recursos propios
lang: en
permalink: /recursos-riesgos/
submenu: recursos-riesgos
---

Recursos propios