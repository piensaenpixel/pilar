---
layout: default
title: Ratio de apalancamiento
lang: en
permalink: /ratio-de-apalancamiento/
submenu: ratio
---

Ratio de apalancamiento