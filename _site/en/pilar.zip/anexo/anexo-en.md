---
layout: default
title: Annexes
lang: en
permalink: /Annex/
submenu: Annex
---


{% include dropdown.html %}

# Summary Table Annexes I to IV

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th></th>
            <th colspan="1">Dec-16</th>
        </tr>
        <tr>
            <th>Type of company according to annex</th>
            <th>Consolidated Cost (Millions of euros)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Insurance companies with a stake of more than 10% that are not consolidated at solvency level (Annex I)</td>
            <td>3,306</td>
        </tr>
        <tr>
            <td>Financial institutions with a stake of more than 10% that are not consolidated at solvency level (Annex I)</td>
            <td>150</td>
        </tr>
        <tr>
            <td>Rest of companies that are consolidated at accounting level but not at solvency level (Annex II)</td>
            <td>411</td>
        </tr>
        <tr class="b2">
            <td>TOTAL</td>
            <td>3,867</td>
        </tr>
    </tbody>
</table>
[Download table](#)


<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th></th>
            <th colspan="1">Dec-16</th>
        </tr>
        <tr>
            <th>Type of company according to annex</th>
            <th>Consolidated Cost (Millions of euros)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Rest of companies that are not consolidated at accounting or solvency level (Annex III)</td>
            <td>512</td>
        </tr>
    </tbody>
</table>
[Download table](#)


<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th></th>
            <th colspan="1">Dec-16</th>
        </tr>
        <tr>
            <th>Type of company according to annex</th>
            <th>Consolidated Cost (Millions of euros)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Rest of companies that are not consolidated at accounting level but are consolidated at solvency level (Annex IV)</td>
            <td>43</td>
        </tr>
    </tbody>
</table>
[Download table](#)

## Annex I: Insurance companies with a stake of more than 10% that are not consolidated according to the solvency criterion

<table class="l">
    <thead>
        <tr class="m">
            <td>Millions of euros</td>
            <td></td>
            <td></td>
            <td></td>
            <td>12-31-2016</td>
        </tr>
        <tr class="tableizer-firstrow">
            <th>Insurance stake >10%</th>
            <th>Accounting Circular</th>
            <th>Solvency Circular</th>
            <th>Activity</th>
            <th>Consolidated Cost</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>BBVA Insurance COLOMBIA, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>34</td>
        </tr>
        <tr>
            <td>BBVA Insurance VIDA COLOMBIA, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>124</td>
        </tr>
        <tr>
            <td>Insurance PROVINCIAL, C.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>7</td>
        </tr>
        <tr>
            <td>BBVA Insurance, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>1,498</td>
        </tr>
        <tr>
            <td>BBVA CONSOLIDAR Insurance, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>53</td>
        </tr>
        <tr>
            <td>MULTIASISTENCIA Services S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>1</td>
        </tr>
        <tr>
            <td>MULTIASISTENCIA OPERADORA S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>0</td>
        </tr>
        <tr>
            <td>VITAMEDICA S.A. DE C.V.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>0</td>
        </tr>
        <tr>
            <td>BBVA BANCOMER Insurance SALUD, S.A. DE C.V</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>47</td>
        </tr>
        <tr>
            <td>BBVA RE DAC</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>47</td>
        </tr>
        <tr>
            <td>CESCE</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Insurance</td>
            <td>0</td>
        </tr>
        <tr>
            <td>BBVA Insurance DE VIDA, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>77</td>
        </tr>
        <tr>
            <td>MULTIASISTENCIA, S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>17</td>
        </tr>
        <tr>
            <td>PENSIONES BBVA BANCOMER, S.A DE C.V.,GFB</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>196</td>
        </tr>
        <tr>
            <td>Insurance BBVA BANCOMER,S.A. DE C.V., GFB.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>421</td>
        </tr>
        <tr>
            <td>BBVA Insurance GENERALES SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>4</td>
        </tr>
        <tr>
            <td>BBVA BROKER SA (ARGENTINA)</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>0</td>
        </tr>
        <tr>
            <td>GARANTI EMEKLILIK VE HAYAT AS</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>301</td>
        </tr>
        <tr>
            <td>CATALUNYACAIXA VIDA, SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>466</td>
        </tr>
        <tr>
            <td>CATALUNYACAIXA ASSEGURANCES GENERALS, SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Insurance</td>
            <td>42</td>
        </tr>
        <tr class="b2">
            <td colspan="4">TOTAL</td>
            <td>3,306</td>
        </tr>
    </tbody>
</table>
[Download table](#)

## Financial institutions with a stake of more than 10% that are not consolidated according to the solvency criterion

<table class="l">
    <thead>
        <tr class="m">
            <td>Millions of euros</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="tableizer-firstrow">
            <th>Financial institutions stake >10%</th>
            <th>Accounting Circular</th>
            <th>Solvency Circular</th>
            <th>Activity</th>
            <th>Consolidated Cost</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>COFIDES</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>19</td>
        </tr>
        <tr>
            <td>IMER-OTC SA - SERV. DE INFRAESTR.MDO OTC</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>SEGURO DE DEPOSITOS</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>EASTSIDE PARTNERS II LP</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>BOLSA ELECT.VALORES</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0,000</td>
        </tr>
        <tr>
            <td>DECEVAL, S.A.</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>SISTARBANC S.R.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>REDSYS Services DE PROCESAMIENTO, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>8</td>
        </tr>
        <tr>
            <td>INTERBANKING,S.A.</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>ACH 4G</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>TELEFONICA FACTORING ESPAÑA, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>4</td>
        </tr>
        <tr>
            <td>TRANSBANK, S.A.</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>SPI</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>ROMBO COMPAÑIA Financial, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>19</td>
        </tr>
        <tr>
            <td>TELEFONICA FACTORING MEXICO, S.A. DE C.V</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>1</td>
        </tr>
        <tr>
            <td>FINANCEIRA DO COMERCIO EXTERIOR S.A.R.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>CAMARA COMP.ELECTRON</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>CAJA EMISIONES</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>PROMOT.BOLSA DE BILBAO</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>CORPORACION SUICHE 7B, C.A</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>CAJA VENEZOLANA DE VALORES, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>TELEFONICA FACTORING COLOMBIA, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>TF PERU SAC</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>1</td>
        </tr>
        <tr>
            <td>TELEFONICA FACTORING DO BRASIL</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>COMPASS INVESTMENTS, INC.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>01</td>
        </tr>
        <tr>
            <td>COMPASS CUSTODIAL SERVICES, INC.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>SERVIRED SDAD ESPAÑOL. MED.PAGO, S.A</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>11</td>
        </tr>
        <tr>
            <td>TELEFONICA FACTORING CHILE, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>CABAL URUGUAY, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>REDBANC, S.A.(URUGUAY)</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>SD.ADMINISTRAD. FDOS.CESANTIA CHILE II</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>FIDEICOMISO F/00185 FIMPE</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>4</td>
        </tr>
        <tr>
            <td>BH CFC-BANK OF HANGZHOU CONSUMER FINANCE</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>20</td>
        </tr>
        <tr>
            <td>ATOM BANK PLC</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>43</td>
        </tr>
        <tr>
            <td>RCI COLOMBIA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>17</td>
        </tr>
        <tr>
            <td>FIDEICOMISO ADMON. REDETRANS</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>1</td>
        </tr>
        <tr>
            <td>INNOVA 31, S.C.R., SA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>AMAEF - AGRUPACION DE LA MEDIACION ASEGU</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>AZUL HOLDING SCA</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>AZUL MANAGEMENT SARL</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>BANKALARARASI KART MERKEZI A.S.</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>CELERIS S.F., SA</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>FINAVES III NUEVAS INVERSIONES,S.A.</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>BUMARI, S.L.</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>SOCIETAT CATALANA INVERSIO COOP. SCR</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>TRANS UNION DE MEXICO</td>
            <td>Not Consolidated</td>
            <td>Not Consolidated</td>
            <td>Financial</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td colspan="4">TOTAL</td>
            <td>150</td>
        </tr>
    </tbody>
</table>
[Download table](#)

## Annex II: Other Companies that are consolidated according to accounting criteria but not according the solvency criterion

<table class="l">
    <thead>
        <tr class="m">
            <td>Millions of euros</td>
            <td></td>
            <td></td>
            <td></td>
            <td>12-31-2016</td>
        </tr>
        <tr class="tableizer-firstrow">
            <th>Company</th>
            <th>Accounting Circular</th>
            <th>Solvency Circular</th>
            <th>Activity</th>
            <th>Consolidated Cost (millions)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>BBVA AUTORENTING, SA(EX-FINANZIA AUTOR.)</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>45</td>
        </tr>
        <tr>
            <td>BBVA NOMINEES, LTD.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>PRO-SALUD, C.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>INVERSIONES P.H.R.4, C.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>INVERSIONES ALDAMA, C.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>BBVA CONSULTORIA, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>5</td>
        </tr>
        <tr>
            <td>BBVA Services, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Commercial</td>
            <td>8</td>
        </tr>
        <tr>
            <td>FIDEIC.F/403112-6 ADMON DOS LAGOS</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>EL ENCINAR METROPOLITANO, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>6</td>
        </tr>
        <tr>
            <td>ANIDA PROYECTOS INMOBILIARIOS, S.A. C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>78</td>
        </tr>
        <tr>
            <td>ANIDA Services INMOBILIARIOS, S.A. DE C</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>TEXTIL TEXTURA, S.L.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Commercial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>RESIDENCIAL CUMBRES DE SANTA FE, S.A. DE</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>6</td>
        </tr>
        <tr>
            <td>COINMODA- COMPLEMENTOS INNOVACIÓN Y MODA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Commercial</td>
            <td>-</td>
        </tr>
        <tr>
            <td>FIDEIC. HARES BBVA BANCOMER F/47997-2</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>BAHIA SUR RESORT, S.C.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>1</td>
        </tr>
        <tr>
            <td>ANIDA DESARROLLOS INMOBILIARIOS, S.L.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>56</td>
        </tr>
        <tr>
            <td>Services CORPORATIVOS DE Insurance, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>4</td>
        </tr>
        <tr>
            <td>DISTRITO CASTELLANA NORTE SA (EX DUCH SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>82</td>
        </tr>
        <tr>
            <td>GOBERNALIA GLOBAL NET, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>9</td>
        </tr>
        <tr>
            <td>FUTURO FAMILIAR, S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>2</td>
        </tr>
        <tr>
            <td>ESTACION DE AUTOBUSES CHAMARTIN, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>URBANIZADORA SANT LLORENC, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>ANIDA GERMANIA IMMOBILIEN ONE, GMBH</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>OPERADORA DOS LAGOS S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>IMOBILIARIA DUQUE DE AVILA, S.A.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>Services TECNOLOG.SINGUL. ( SERVITECSA)</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>1</td>
        </tr>
        <tr>
            <td>COPROMED S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>BEEVA TEC OPERADORA, S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>INMESP DESARROLLADORA, S.A. DE C.V.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>25</td>
        </tr>
        <tr>
            <td>CONSORCIO DE CASAS MEXICANAS, SAPI DE CV</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>6</td>
        </tr>
        <tr>
            <td>F/403035-9 BBVA HORIZONTES RESIDENCIAL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>F/253863 EL DESEO RESIDENCIAL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>F/100322908 FID. DOS LAGOS(SCOTIAB.INV.)</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>MADIVA SOLUCIONES SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>10</td>
        </tr>
        <tr>
            <td>ARRAHONA GARRAF SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>CATALÒNIA GEBIRA, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>GARRAF MEDITERRANIA SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>HABITATGES INVERVIC, S.L.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>HABITATGES JUVIPRO, S.L.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>MOTORACTIVE MULTISERVICES SRL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>GARANTI FILO YONETIM HIZMETLERI A.S.</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>10</td>
        </tr>
        <tr>
            <td>INPAU, SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>27</td>
        </tr>
        <tr>
            <td>FODECOR, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>CERBAT, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>25</td>
        </tr>
        <tr>
            <td>PROCAMVASA, SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>S.B.D. NORD, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>ESPAIS CERDANYOLA, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>PUERTO CIUDAD LAS PALMAS, SA</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>PROVIURE, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>CLUB GOLF HACIENDA EL ALAMO, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>AREA TRES PROCAM, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>JALE PROCAM, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>PROVIURE CIUTAT DE LLEIDA, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>PROVIURE BARCELONA, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>PROVIURE PARC D'HABITATGES, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>CONJUNT RESIDENCIAL FREIXA, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>HABITAT ZENTRUM, SL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>GARANTI KULTUR AS</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>TRIFOI REAL ESTATE SRL</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>1</td>
        </tr>
        <tr>
            <td>UNITARIA GESTION DE PATRIMONIOS INMOBILI</td>
            <td>Full Consolidation</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>3</td>
        </tr>
        <tr class="b2">
            <td colspan="4">TOTAL</td>
            <td>411</td>
        </tr>
    </tbody>
</table>
[Download table](#)

## Annex III: Other Companies that are not consolidated according to accounting and solvency criteria

<table class="l">
    <thead>
        <tr class="m">
            <td>Millions of euros</td>
            <td></td>
            <td></td>
            <td></td>
            <td>12-31-2016</td>
        </tr>
        <tr class="tableizer-firstrow">
            <th>Company</th>
            <th>Accounting Circular</th>
            <th>Solvency Circular</th>
            <th>Activity</th>
            <th>Consolidated Cost (millions)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>F/404180-2 BBVA BANCOMER SERV.GOLF ZIBAT</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>CAMARATE GOLF, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>1</td>
        </tr>
        <tr>
            <td>AUREA, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>5</td>
        </tr>
        <tr>
            <td>FIDEIC. F/402770-2 ALAMAR</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>FIDEIC F 403853 5 BBVA BANCOM SER.ZIBATA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>7</td>
        </tr>
        <tr>
            <td>CORPORATIVO VITAMEDICA, S.A. DE C.V.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>OPERADORA ZIBATA S. DE R.L. DE C.V.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>Services VITAMEDICA, S.A. DE C.V.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>FERROMOVIL 3000, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>4</td>
        </tr>
        <tr>
            <td>FERROMOVIL 9000, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>3</td>
        </tr>
        <tr>
            <td>IRB RIESGO OPERACIONAL, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>JARDINES DEL RUBIN, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>1</td>
        </tr>
        <tr>
            <td>COMPAÑIA MEXICANA DE PROCESAMIENTO, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>6</td>
        </tr>
        <tr>
            <td>ADQUIRA MEXICO, S.A. DE C.V.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Commercial</td>
            <td>2</td>
        </tr>
        <tr>
            <td>ADQUIRA ESPAÑA, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Commercial</td>
            <td>3</td>
        </tr>
        <tr>
            <td>OPERADORA ALAMAR SA DE CV</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>ALTITUDE SOFTWARE SGPS, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>FIDEICOMISO 1729 INVEX ENAJENACION DE CA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Special Purpose Real State Companies</td>
            <td>57</td>
        </tr>
        <tr>
            <td>VITAMEDICA ADMINISTRADORA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>1</td>
        </tr>
        <tr>
            <td>CANCUN SUN & GOLF COUNTRY CLUB, SAPI CV</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>BATEC MOBILITY, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>1</td>
        </tr>
        <tr>
            <td>FIDEICOMISO DE ADMON 2038-6</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>DESARROLLOS METROPOLITANOS DEL SUR SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>1º</td>
        </tr>
        <tr>
            <td>METROVACESA SUELO Y PROMOCION, SA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>208</td>
        </tr>
        <tr>
            <td>TESTA RESIDENCIAL SOCIMI SAU</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>91</td>
        </tr>
        <tr>
            <td>PARQUE RIO RESIDENCIAL, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>10</td>
        </tr>
        <tr>
            <td>CAPIPOTA PRODUCTIONS S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Commercial</td>
            <td>0</td>
        </tr>
        <tr>
            <td>IBVSOURCE-PRESTAÇAO SERV.INFORMATICOS</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>AVANTESPACIA Real Estate SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>18</td>
        </tr>
        <tr>
            <td>METROVACESA PROMOCION Y ARRENDAMIENTO S.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>67</td>
        </tr>
        <tr>
            <td>AXIACOM-CRI</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>HABITATGES CIMIPRO, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>HABITATGES LLULL, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>NOVA LLAR SANT JOAN SA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>NUCLI, SA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>RESIDENCIAL SARRIA-BONANOVA SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>SDB CREIXENT, SA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>SOLARVOLAR S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>PROVICAT SANT ANDREU, SA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>ESPAIS CATALUNYA INV. IMMOB., SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>INFORMACIO I TECNOLOGIA DE CATALUNYA, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>0</td>
        </tr>
        <tr>
            <td>NOVA TERRASSA 30, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>PROMOCIONS TERRES CAVADES, SA</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>4</td>
        </tr>
        <tr>
            <td>PROMOCIONES MIES DEL VALLE, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>TEIN CENTRO TECNOLOGICO DEL PLASTICO, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>PROVIURE CZF, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>EURO LENDERT, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>FACTOR HABAST, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>SENDERAN GESTION DE ACTIVOS, S.L.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr>
            <td>EUROESPAI 2000, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>IMPULS LLOGUER, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>1</td>
        </tr>
        <tr>
            <td>PROVIURE CZF PARC D'HABITATGES, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>NAVIERA CABO ESTAY, AIE</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>SEGURIDAD Y PROTECCION BankingRIAS, S.A. D</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>1</td>
        </tr>
        <tr>
            <td>Services ELECTRONICOS GLOBALES, S.A. DE</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>6</td>
        </tr>
        <tr>
            <td>REAL ESTATE DEAL II</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Other Investment Companies</td>
            <td>4</td>
        </tr>
        <tr>
            <td>GUP GESTION UNIFICADA DE PROYECTOS, S.A.</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Services</td>
            <td>-</td>
        </tr>
        <tr>
            <td>DOBIMUS SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>PROMOCIONS CAN CATÀ SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>-</td>
        </tr>
        <tr>
            <td>RESIDENCIAL PEDRALBES-CARRERAS, SL</td>
            <td>Equity Method</td>
            <td>Equity Method</td>
            <td>Real Estate</td>
            <td>0</td>
        </tr>
        <tr class="b2">
            <td colspan="4">Total</td>
            <td>512</td>
        </tr>
    </tbody>
</table>
[Download table](#)

## Annex IV: Other Companies that are not consolidated according to accounting criteria but are consolidated according the solvency criterion

<table class="l">
    <thead>
        <tr class="m">
            <td>Millions of euros</td>
            <td></td>
            <td></td>
            <td></td>
            <td>12-31-2016</td>
        </tr>
        <tr class="tableizer-firstrow">
            <th>Company</th>
            <th>Accounting Circular</th>
            <th>Solvency Circular</th>
            <th>Activity</th>
            <th>Consolidated Cost (millions)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>INVERSIONES PLATCO, C.A.</td>
            <td>Equity Method</td>
            <td>Proportional Consolidation</td>
            <td>Financial Services</td>
            <td>4</td>
        </tr>
        <tr>
            <td>ALTURA MARKETS, S.V., S.A.</td>
            <td>Equity Method</td>
            <td>Proportional Consolidation</td>
            <td>Brokerage Firms</td>
            <td>19</td>
        </tr>
        <tr>
            <td>PSA FINANCE ARGENTINA COMPAÑIA FINANCIER</td>
            <td>Equity Method</td>
            <td>Proportional Consolidation</td>
            <td>Banking</td>
            <td>21</td>
        </tr>
        <tr class="b2">
            <td colspan="4">Total</td>
            <td>43</td>
        </tr>
    </tbody>
</table>
[Download table](#)

The zero balances correspond to companies whose holding value is equal to zero, as well as companies that are not consolidated.

## Annex V: Transitory own funds disclosure template

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th>Template with information on temporary capital (Millions of euros)</th>
            <th>12/31/2016 Phase-in (1)</th>
            <th>Transitional adjustments (2)</th>
            <th>12/31/2016 Fully-loaded (3)=(1)+(2)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Capital instruments and the related share premium accounts</td>
            <td>27,210</td>
            <td>&nbsp;</td>
            <td>27,210</td>
        </tr>
        <tr class="s">
            <td>of which: Own shares</td>
            <td>27,210</td>
            <td>&nbsp;</td>
            <td>27,210</td>
        </tr>
        <tr class="s">
            <td>of which: Instrument type 2</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr class="s">
            <td>of which: Instrument type 3</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>2. Retained earnings</td>
            <td>23,688</td>
            <td>&nbsp;</td>
            <td>23,688</td>
        </tr>
        <tr>
            <td>3. Accumulated other comprehensive income (and any other reserves)</td>
            <td>(5,760)</td>
            <td>&nbsp;</td>
            <td>(5,760)</td>
        </tr>
        <tr>
            <td>3.a. Funds for general banking risk</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>4. Amount of qualifying items referred to in Article 484 (3) and the related share premium accounts subject to phase out from CET1</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>5. Minority interests (amount allowed in consolidated CET1)</td>
            <td>6,969</td>
            <td>(642)</td>
            <td>6,328</td>
        </tr>
        <tr>
            <td>5.a. Independently reviewed interim profits net of any foreseeable charge or dividend</td>
            <td>2,232</td>
            <td>&nbsp;</td>
            <td>2,232</td>
        </tr>
        <tr class="b2">
            <td>6. Common Equity Tier 1 (CET1) capital before regulatory adjustments</td>
            <td>54,339</td>
            <td>(642)</td>
            <td>53,697</td>
        </tr>
        <tr class="b">
            <td>Common Equity Tier 1 (CET1) capital: regulatory adjustments</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>7. Additional value adjustments (negative amount)</td>
            <td>(250)</td>
            <td>-</td>
            <td>(250)</td>
        </tr>
        <tr>
            <td>8. Intangible assets (net of related tax liability) (negative amount)</td>
            <td>(5,675)</td>
            <td>(3,783)</td>
            <td>(9,459)</td>
        </tr>
        <tr>
            <td>9. Empty set in the EU</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>10. Deferred tax assets that rely on future profitability excluding those arising from temporary difference (net of related tax liability where the conditions in Article 38 (3) are met) (negative amount)</td>
            <td>(453)</td>
            <td>(640)</td>
            <td>(1,093)</td>
        </tr>
        <tr>
            <td>11. Fair value reserves related to gains or losses on cash flow hedges</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>12. Negative amounts resulting from the calculation of expected loss amounts (equity)</td>
            <td>(16)</td>
            <td>&nbsp;</td>
            <td>(16)</td>
        </tr>
        <tr>
            <td>13. Any increase in equity that results from securitised assets (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>14. Gains or losses on liabilities valued at fair value resulting from changes in own credit standing</td>
            <td>(202)</td>
            <td>&nbsp;</td>
            <td>(202)</td>
        </tr>
        <tr>
            <td>15. Defined-benefit pension fund assets (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>16. Direct and indirect holdings by an institution of own CET1 instruments (negative amount)</td>
            <td>(181)</td>
            <td>(36)</td>
            <td>(217)</td>
        </tr>
        <tr>
            <td>17. Direct, indirect and synthetic holdings of the CET1 instruments of financial sector entities where those entities have reciprocal cross holdings with the institution designed to inflate artificially the own funds of the institution (negatvie amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>18. Direct, indirect and synthetic holdings of the CET1 instruments of financial sector entities where the institution does not have a significant investment in those entities (amount above 10% threshold and net of eligible short positions) (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>19. Direct, indirect and synthetic holdings of the CET1 instruments of financial sector entities where the institution has a significant investment in those entities (amount above 10% threshold and net of eligible short positions) (negative amount)</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>20. Empty set in the EU</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>20.a Exposure amount of the following items which qualify for a RW of 1250%, where the institution opts for the deduction alternative</td>
            <td>(62)</td>
            <td>&nbsp;</td>
            <td>(62)</td>
        </tr>
        <tr>
            <td>20.b. of which: qualifying holdings outside the financial sector (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>20.c of which: securitisation positions (negative amount)</td>
            <td>(62)</td>
            <td>&nbsp;</td>
            <td>(62)</td>
        </tr>
        <tr>
            <td>20.d of which: free deliveries (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>21. Deferred tax assets arising from temporary difference (amount above 10 % threshold , net of related tax liability where the conditions in Article 38 (3) are met) (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>22. Amount exceeding the 15% threshold (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>23. of which: direct and indirect holdings by the institution of the CET1 instruments of financial sector entities where the institution has a significant investment in those entities</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>24. Empty set in the EU</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>25. of which: deferred tax assets arising from temporary difference</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>25.a Losses for the current financial year (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>25.b Foreseeable tax charges relating to CET1 items (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>26. Regulatory adjustments applied to Common Equity Tier 1 in respect of amounts subject to pre-CRR treatment</td>
            <td>(129)</td>
            <td>129</td>
            <td>-</td>
        </tr>
        <tr>
            <td>26.a Regulatory adjustments relating to unrealised gains and losses pursuant to Articles 467 and 468</td>
            <td>(129)</td>
            <td>129</td>
            <td>-</td>
        </tr>
        <tr>
            <td>26.b Amount to be deducted from or added to Common Equity Tier 1 capital with regard to additional filters and deductions required pre CRR</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>27. Qualifying AT1 deductions that exceeds the AT1 capital of the institution (negative amount)</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>28.Total regulatory adjustments to Common Equity Tier 1 (CET1)</td>
            <td>(6,969)</td>
            <td>(4,330)</td>
            <td>(11,300)</td>
        </tr>
        <tr class="b2">
            <td>29. Common Equity Tier 1 (CET1) capital</td>
            <td>47,370</td>
            <td>(4,973)</td>
            <td>42,398</td>
        </tr>
        <tr class="b">
            <td>Additional Tier 1 (AT1) capital: instruments</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>30. Capital instruments and the related share premium accounts</td>
            <td>5,423</td>
            <td>&nbsp;</td>
            <td>5,423</td>
        </tr>
        <tr>
            <td>31. of which: classified as equity under applicable accounting standards</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>32. of which: classified as liabilities under applicable accounting standards</td>
            <td>5,423</td>
            <td>&nbsp;</td>
            <td>5,423</td>
        </tr>
        <tr>
            <td>33. Amount of qualifying items referred to in Article 484 (4) and the related share premium accounts subject to phase out from AT1</td>
            <td>691</td>
            <td>(691)</td>
            <td>-</td>
        </tr>
        <tr>
            <td>34. Qualifying Tier 1 capital included in consolidated AT1 capital (including minority interest not included in row 5) issued by subsidiaries and held by third parties</td>
            <td>383</td>
            <td>255</td>
            <td>638</td>
        </tr>
        <tr>
            <td>35. of which: instruments issued by subsidiaries subject to phase-out</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>36. Additional Tier 1 (AT1) capital before regulatory adjustments</td>
            <td>6,497</td>
            <td>(436)</td>
            <td>6,061</td>
        </tr>
        <tr class="b">
            <td>Additional Tier 1 (AT1) capital: regulatory adjustments</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>37. Direct and indirect holdings by an institution of own AT1 instruments (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>38. Holdings of the AT1 instruments of financial sector entities where those entities have reciprocal cross holdings with the institution designed to inflate artificially the own funds of the institution (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>39. Direct, indirect and synthetic holdings of the AT1 instruments of financial sector entities where the institution does not have a significant investment in those entities (amount above 10% threshold and net of eligible short positions) (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>40. Direct, indirect and synthetic holdings of the AT1 instruments of financial sector entities where the institution has a significant investment in those entities (amount above 10% threshold and net of eligible short positions) (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>41. Regulatory adjustments applied to Additional Tier 1 capital in respect of amounts subject to pre-CRR treatment and transitional treatments subject to phase-out as prescribed in Regulation (EU) No 585/2013 (ie. CRR residual amounts)</td>
            <td>(3,783)</td>
            <td>3,783</td>
            <td>-</td>
        </tr>
        <tr>
            <td>41.a. Residual amounts deducted from Additional Tier 1 capital with regard to deduction from Common Equity Tier 1 capital during the transitional period pursuant to article 472 of Regulation (EU) No 575/2013</td>
            <td>(3,783)</td>
            <td>3,783</td>
            <td>-</td>
        </tr>
        <tr>
            <td>41.b Residual amounts deducted from Additional Tier 1 capital with regard to deduction from Tier 2 capital during the transitional period pursuant to article 475 of Regulation (EU) No 575/2013</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>41.c Amounts to be deducted from added to Additional Tier 1 capital with regard to additional filters and deductions required pre- CRR</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>42 Qualifying T2 deductions that exceed the T2 capital of the institution (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>43 Total regulatory adjustments to Additional Tier 1 (AT1) capital</td>
            <td>(3,783)</td>
            <td>3,783</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>44 Additional Tier 1 (AT1) capital</td>
            <td>2,713</td>
            <td>3,347</td>
            <td>6,061</td>
        </tr>
        <tr class="b2">
            <td>45 Tier 1 capital (T1 = CET1 + AT1)</td>
            <td>50,083</td>
            <td>(1,626)</td>
            <td>48,459</td>
        </tr>
        <tr class="b">
            <td>Tier 2 (T2) capital: instruments and provisions</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>46. Capital instruments and the related share premium accounts</td>
            <td>1,935</td>
            <td>-</td>
            <td>1,935</td>
        </tr>
        <tr>
            <td>47. Amount of qualifying items referred to in Article 484 (5) and the related share premium accounts subject to phase out from T2</td>
            <td>421</td>
            <td>(421)</td>
            <td>-</td>
        </tr>
        <tr>
            <td>48. Qualifying own funds instruments included in consolidated T2 capital (including minority interest and AT1 instruments not included in rows 5 or 34) issued by subsidiaries and held by third party</td>
            <td>5,915</td>
            <td>350</td>
            <td>6,265</td>
        </tr>
        <tr>
            <td>49. of which: instruments issued by subsidiaries subject to phase-out</td>
            <td>350</td>
            <td>(350)</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>50. Credit risk adjustments</td>
            <td>538</td>
            <td>&nbsp;</td>
            <td>538</td>
        </tr>
        <tr class="b2">
            <td>51. Tier 2 (T2) capital before regulatory adjustment</td>
            <td>8,810</td>
            <td>(71)</td>
            <td>8,739</td>
        </tr>
        <tr class="b">
            <td>Tier 2 (T2) capital: regulatory adjustments</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>52. Direct and indirect holdings by an institution of own T2 instruments and subordinated loans (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>53. Direct and indirect holdings by an institution of own T2 instruments and subordinated loans (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>54. Direct, indirect and synthetic holdings of the T2 instruments and subordinated loans of financial sector entities where the institution does not have a significant investment in those entities (amount above 10 % threshold and net of eligible short positions) (negative amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>54.a Of which new holdings not subject to transitional arrangements</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>54.b Of which holdings existing befor 1 January 2013 and subject to transitional arrangements</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>55. Direct, indirect and synthetic holdings of the T2 instruments and subordinated loans of financial sector entities where the institution has a significant investment in those entities (net of eligible short positions) (negative amounts)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>56. Regulatory adjustments applied to tier 2 in respect of amounts subject to pre-CRR treatment and transitional treatments subject to phase out as prescribed in Regulation (EU) No 575/2013 (i.e. CRR residual amounts)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>56.a Residual amounts deducted from Tier 2 capital with regard to deduction from Common Equity Tier 1 capital during the transitional period pursuant to article 472 of Regulation (EU) No 575/2013</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>56.b Residual amounts deducted from Tier 2 capital with regard to deduction from Additional Tier 1 capital during the transitional period pursuant to article 475 of Regulation (EU) No 575/2013</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>56.c Amounts to be deducted from or added to Tier 2 capital with regard to additional filters and deductions required pre- CRR</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>57 Total regulatory adjustments to Tier 2 (T2) capital</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>58. Tier 2 (T2) capital</td>
            <td>8,810</td>
            <td>(71)</td>
            <td>8,739</td>
        </tr>
        <tr class="b2">
            <td>59. Total capital (TC = T1 + T2)</td>
            <td>58,893</td>
            <td>(1,696)</td>
            <td>57,197</td>
        </tr>
        <tr>
            <td>59.a Risk weighted assets in respect of amounts subject to pre-CRR treatment and transitional treatments subject to phase out as prescribed in Regulation (EU) No 575/2013 (i.e. CRR residual amount)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>60 Total risk-weighted assets</td>
            <td>388,951</td>
            <td>-</td>
            <td>388,951</td>
        </tr>
        <tr>
            <td>61. Common Equity Tier 1 (as a percentage of total risk exposure amount</td>
            <td>12.2%</td>
            <td>&nbsp;</td>
            <td>10.9%</td>
        </tr>
        <tr>
            <td>62. Tier 1 (as a percentage of total risk exposure amount</td>
            <td>12.9%</td>
            <td>&nbsp;</td>
            <td>12.5%</td>
        </tr>
        <tr>
            <td>63. Total capital (as a percentage of total risk exposure amount</td>
            <td>15.1%</td>
            <td>&nbsp;</td>
            <td>14.7%</td>
        </tr>
        <tr>
            <td>64. Institution specific buffer requirement (CET1 requirement in accordance with article 92 (1) (a) plus capital conservation and countercyclical buffer requirements plus a systemic risk buffer, plus systemically important institution buffer expressed as a percentage of total risk exposure amount)</td>
            <td>4.5%</td>
            <td>&nbsp;</td>
            <td>4.5%</td>
        </tr>
        <tr>
            <td>65. of which: capital conservation buffer requirement</td>
            <td>0.625%</td>
            <td>&nbsp;</td>
            <td>2.5%</td>
        </tr>
        <tr>
            <td>66. of which: countercyclical buffer requirement</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>67. of which: systemic risk buffer requirement</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>67.a. of which: Global Systemically Important Institution (G-SII) or Other Systemically Important Institution (O-SII) buffer</td>
            <td>0.25%</td>
            <td>&nbsp;</td>
            <td>0.25%</td>
        </tr>
        <tr>
            <td>68. Common Equity Tier 1 available to meet buffers (as a percentage of risk exposure amount)</td>
            <td>7.68%</td>
            <td>&nbsp;</td>
            <td>6.40%</td>
        </tr>
        <tr class="b">
            <td>Amounts below the thresholds for deduction (before risk-weighting)</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>72. Direct and indirect holdings of the capital of financial sector entities where the institution does not have a significant investment in those entities (amount below 10% threshold and net of eligible short positions</td>
            <td>2,040</td>
            <td>&nbsp;</td>
            <td>2,040</td>
        </tr>
        <tr>
            <td>73. Direct and indirect holdings of the CET1 instruments of financial sector entities where the institution has a significant investment in those entities (amount below 10% threshold and net of eligible short positions</td>
            <td>3,279</td>
            <td>&nbsp;</td>
            <td>3,279</td>
        </tr>
        <tr>
            <td>74. Empty set in the EU</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>75. Deferred tax assets arising from temporary difference (amount below 10 % threshold , net of related tax liability where the conditions in Article 38 (3) are met)</td>
            <td>3,061</td>
            <td>&nbsp;</td>
            <td>3,061</td>
        </tr>
        <tr class="b">
            <td>Applicable caps on the inclusion of provisions in Tier 2</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>76. Credit risk adjustments included in T2 in respect of exposures subject to standardised approach (prior to the application of the cap)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>77. Cap on inclusion of credit risk adjustments in T2 under standardised approach</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>78. Credit risk adjustments included in T2 in respect of exposures subject to internal rating-based approach (prior to the application of the cap)</td>
            <td>2,688</td>
            <td>&nbsp;</td>
            <td>2,688</td>
        </tr>
        <tr>
            <td>79. Cap for inclusion of credit risk adjustments in T2 under internal ratings-based approach</td>
            <td>538</td>
            <td>&nbsp;</td>
            <td>538</td>
        </tr>
        <tr>
            <td>80. Current cap on CET1 instruments subject to phase-out arrangements</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>81. Amount excluded from CET1 due to cap (excess over cap after redemptions and maturities)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>82. Current cap on AT1 instruments subject to phase-out arrangements</td>
            <td>1,836</td>
            <td>&nbsp;</td>
            <td>1,836</td>
        </tr>
        <tr>
            <td>83. Amount excluded from AT1 due to cap (excess over cap after redemptions and maturities)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>691</td>
        </tr>
        <tr>
            <td>84. Current cap on T2 instruments subject to phase-out arrangements</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
        <tr>
            <td>85. Amount excluded from T2 due to cap (excess over cap after redemptions and maturities)</td>
            <td>-</td>
            <td>&nbsp;</td>
            <td>-</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<ul class="cita"><li>(*) CET1 available to cover minimum buffer requirements calculated as 4.5% over RWAs</li></ul>

## Annex VI. Capital instruments main features template

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="5">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
        </tr>
        <tr>
            <td>2. Unique identifier (eg CUSIP, ISIN or Bloomberg identifier for private placement</td>
            <td>XS0926832907</td>
            <td>XS1033661866</td>
            <td>XS1190663952</td>
            <td>XS1394911496</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>Spanish</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Additional Tier 1</td>
            <td>Additional Tier 1</td>
            <td>Additional Tier 1</td>
            <td>Additional Tier 1</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Additional Tier 1</td>
            <td>Additional Tier 1</td>
            <td>Additional Tier 1</td>
            <td>Additional Tier 1</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>*Contingent Convertible*</td>
            <td>*Contingent Convertible*</td>
            <td>*Contingent Convertible*</td>
            <td>*Contingent Convertible*</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>1,423,0</td>
            <td>1,500,0</td>
            <td>1,500,0</td>
            <td>1,000,0</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>1,500 Mill USD</td>
            <td>1,500 Mill EUR</td>
            <td>1,500 Mill EUR</td>
            <td>1,000 Mill EUR</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>04/26/2013</td>
            <td>02/11/2014</td>
            <td>02/10/2015</td>
            <td>04/072016</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Perpetual</td>
            <td>Perpetual</td>
            <td>Perpetual</td>
            <td>Perpetual</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Issuer call date: 05/09/2018; also subject to both Regulatory and Tax call</td>
            <td>Issuer call date: 02/19/2019; also subject to both Regulatory and Tax call</td>
            <td>Issuer call date: 02/18/2020; also subject to both Regulatory and Tax call</td>
            <td>Issuer call date: 04/14/2021; also subject to both Regulatory and Tax call</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>At any time on or after the first reset date</td>
            <td>At any time on or after the first reset date</td>
            <td>At any time on or after the first reset date</td>
            <td>At any time on or after the first reset date</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Fixed to floating (since *call date*)</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>9,0%; USSW5 + 8,262%</td>
            <td>7,0%; EUSA5 + 6,155%</td>
            <td>6,75%; EUSA5 + 6,604%</td>
            <td>8,875%; EUSA5 +9,177%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Fully discretionary</td>
            <td>Fully discretionary</td>
            <td>Fully discretionary</td>
            <td>Fully discretionary</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Fully discretionary</td>
            <td>Fully discretionary</td>
            <td>Fully discretionary</td>
            <td>Fully discretionary</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Convertible</td>
            <td>Convertible</td>
            <td>Convertible</td>
            <td>Convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>CET1 5,125%; At solo & (sub-)consolidated</td>
            <td>CET1 5,125%; At solo & (sub-)consolidated</td>
            <td>CET1 5,125%; At solo & (sub-)consolidated</td>
            <td>CET1 5,125%; At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>Always Fully</td>
            <td>Always Fully</td>
            <td>Always Fully</td>
            <td>Always Fully</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
            <td>Banco Bilbao Vizcaya Argentaria SA</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)
            </td>
            <td>Senior to common shares and reserves and pari passu with preferred shares</td>
            <td>Senior to common shares and reserves and pari passu with preferred shares</td>
            <td>Senior to common shares and reserves and pari passu with preferred shares</td>
            <td>Senior to common shares and reserves and pari passu with preferred shares</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="5">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA International Preferred SA Unipersonal</td>
            <td>BBVA International Preferred SA Unipersonal</td>
            <td>BBVA International Preferred SA Unipersonal</td>
            <td>CaixaSabadell Preferents S.A. Company Unipersonal</td>
        </tr>
        <tr>
            <td>2. Unique identifier (eg CUSIP, ISIN or Bloomberg identifier for private placement</td>
            <td>US05530RAB42</td>
            <td>XS0308305803</td>
            <td>XS0266971745</td>
            <td>ES0101339028</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>Spanish</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
            <td>Not admissible</td>
            <td>Tier 1</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Preferred Shares</td>
            <td>Preferred Shares</td>
            <td>Preferred Shares</td>
            <td>Preferred Shares</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>569.2</td>
            <td>36.4</td>
            <td>-</td>
            <td>51.2</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>600 Mill USD</td>
            <td>400 Mill GBP</td>
            <td>500 Mill EUR </td>
            <td>90 Mill EUR</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>04/18/2007</td>
            <td>07/19/2007</td>
            <td>09/20/2006</td>
            <td>07/14/2006</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Perpetual</td>
            <td>Perpetual</td>
            <td>Perpetual</td>
            <td>Perpetual</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Issuer call date: 04/18/2017; also subject to both Regulatory and Tax call</td>
            <td>Issuer call date: 07/19/2012; also subject to both Regulatory and Tax call</td>
            <td>Issuer call date: 09/20/2016; also subject to both Regulatory and Tax call</td>
            <td>Issuer call date: 07/14/2016</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>At ten years intervals commencing on April 18, 2017</td>
            <td>On any distribution payment date falling on or after the first call date</td>
            <td>On any distribution payment date falling on or after the first call date</td>
            <td>On any distribution payment date falling on or after the first call date</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Floating</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>5,919% (floor); 3M US LIBOR+0,82%</td>
            <td>7,093%; 3M GBP LIBOR+0,875%</td>
            <td>4,952%; 3M EURIBOR +0,95% (from 09/20/16 +1% additional)</td>
            <td>3M EURIBOR + 1,95%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)
            </td>
            <td>Senior to common shares and reserves and pari passu with preferred shares</td>
            <td>Senior to common shares and reserves and pari passu with Additional Tier 1 instruments</td>
            <td>Senior to common shares and reserves and pari passu with Additional Tier 1 instruments</td>
            <td>Senior to common shares and reserves and pari passu with Additional Tier 1 instruments</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>No trigger, no discretionary</td>
            <td>No trigger, no discretionary</td>
            <td>No trigger, no discretionary. Includes step-up</td>
            <td>No trigger, no discretionary</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="5">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>Caixa Terrassa Societat de Participacions Preferents, S.A. Unipersonal</td>
            <td>BBVA International Preferred SA Unipersonal </td>
            <td>BBVA Subordinated Capital Finance SAU</td>
            <td>BBVA Subordinated Capital Finance SAU</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>XS0225115566</td>
            <td>XS0229864060</td>
            <td>XS0230662628</td>
            <td>XS1055241373</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>English</td>
            <td>English</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 1</td>
            <td>Not admissible</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Preferred Shares</td>
            <td>Preferred Shares</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>34.3</td>
            <td>-</td>
            <td>-</td>
            <td>1,500,0</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>75 Mill EUR</td>
            <td>550 Mill EUR</td>
            <td>150 Mill EUR</td>
            <td>1,500 Mill EUR</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>99.81%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>The Liquidation Preference plus, if applicable, an amount equal to accrued and unpaid Distributions for the then current Distribution Period to the date fixed for redemption of the Preferred Securities</td>
            <td>100%</td>
            <td>100%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>08/10/2005</td>
            <td>09/22/2005</td>
            <td>10/13/2005</td>
            <td>04/11/2014</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Perpetual</td>
            <td>Perpetual</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>10/13/2020</td>
            <td>04/11/2024</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Issuer call date: 10/08/2011</td>
            <td>Issuer call date: 09/22/2015; also subject to both Regulatory and Tax call</td>
            <td>Issuer call date: 10/13/2015; Tax call (At any time on or after the 5th year)</td>
            <td>Issuer call date: 11/04/2019; also subject to both Regulatory and Tax call</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>On any distribution payment date falling on or after the first call date</td>
            <td>On any distribution payment date falling on or after the first call date</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
            <td>No</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>0</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Floating</td>
            <td>Fixed to floating (since *call date*)</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>8%; 10Y CMS +0,10% (cap: 10%)</td>
            <td>3,798%; 3M EURIBOR + 0,65% (from 09/22/15 +1% additional)</td>
            <td>3M EURIBOR +0,30% up to el 10/13/2015; después 3M EURIBOR +0,80%</td>
            <td>3,5%; 6M EURIBOR + 255pbs</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)
            </td>
            <td>Senior to common shares and reserves and pari passu with Additional Tier 1 instruments</td>
            <td>Senior to common shares and reserves and pari passu with Additional Tier 1 instruments</td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>No trigger, no discretionary</td>
            <td>No trigger, no discretionary, step up</td>
            <td>Existence of step-up</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="5">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA Subordinated Capital Finance SAU</td>
            <td>BBVA, SA</td>
            <td>BBVA Subordinated Capital Finance SAU</td>
            <td>BBVA, SA</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>XS0376074364</td>
            <td>ES0213211131</td>
            <td>XS0361684391</td>
            <td>ES0213211115</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>English</td>
            <td>Spanish</td>
            <td>English</td>
            <td>Spanish</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>4.0</td>
            <td>99.9</td>
            <td>50.0</td>
            <td>124.7</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>20 Mill EUR</td>
            <td>100 Mill EUR</td>
            <td>50 Mill EUR</td>
            <td>125 Mill EUR</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>99.77%</td>
            <td>100.00%</td>
            <td>99.65%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>07/22/2008</td>
            <td>07/04/2008</td>
            <td>05/19/2008</td>
            <td>03/03/2008</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>07/22/2018</td>
            <td>04/07/2023</td>
            <td>05/19/2023</td>
            <td>03/03/2033</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>No optional call date; Tax call</td>
            <td>No</td>
            <td>No optional call date; Tax call</td>
            <td>Issuer call date: 03/03/2028</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>At any time on or after the 5th year</td>
            <td>NA</td>
            <td>At any time on or after the 5th year</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed to specified index</td>
            <td>Fixed to floating (since *call date*)</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>6.11%</td>
            <td>6.20%</td>
            <td>4.75% first 2 years; after, follows CP</td>
            <td>6.025%; from 3/03/28 3M EURIBOR+1,78%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)
            </td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>Existence of step-up</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="5">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA, SA</td>
            <td>BBVA Subordinated Capital Finance SAU</td>
            <td>BBVA Global Finance LTD</td>
            <td>Caixa Terrassa</td>
            <td>Caixa Terrassa</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>ES0213211107</td>
            <td>XS0291892262</td>
            <td>US055291AC24</td>
            <td>ES0214974026</td>
            <td>ES0214974059</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Spanish</td>
            <td>English</td>
            <td>New York</td>
            <td>Spanish</td>
            <td>Spanish</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
            <td>Perpetual subordinated debt</td>
            <td>Subordinated debt</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>256.6</td>
            <td>68.0</td>
            <td>184.7</td>
            <td>0.05</td>
            <td>-</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>300 Mill EUR</td>
            <td>100 Mill EUR</td>
            <td>200 Mill USD</td>
            <td>6 Mill EUR</td>
            <td>50 Mill EUR</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>99.06%</td>
            <td>100.00%</td>
            <td>98.21%</td>
            <td>100.00%</td>
            <td>99.66%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>02/16/2007</td>
            <td>04/04/2007</td>
            <td>12/04/1995</td>
            <td>06/30/1990</td>
            <td>08/09/2006</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Perpetual</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>02/16/2022</td>
            <td>04/04/2022</td>
            <td>12/01/2025</td>
            <td>N/A</td>
            <td>08/09/2021</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Issuer call date: 02/16/2017</td>
            <td>No optional call date; Tax call</td>
            <td>No optional call date; Tax call</td>
            <td>Issuer call date: 06/03/2010</td>
            <td>Issuer call date: 08/09/2016</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
            <td>At any time on or after the 5th year</td>
            <td>At any time after the 11/12/2000</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
            <td>Issuer call date and on each year thereafter</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Floating</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed to floating (since *call date*)</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>4.50%; after *call date*: 3M EURIBOR + 80PBS</td>
            <td>CMS 10YR + 0.03%</td>
            <td>7.00%</td>
            <td>2.50%</td>
            <td>4.70%; 3M EURIBOR + 1,08% since issuer *call date*</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>Yes</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)
            </td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior to preferred shares and Additional Tier 1 instruments</td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>Yes</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>Existence of step-up</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>Existence of step-up</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="6">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>Caixa Terrassa</td>
            <td>Caixa Sabadell</td>
            <td>Caixa Sabadell</td>
            <td>Caixa Sabadell</td>
            <td>Caixa Terrassa</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>ES0214974067</td>
            <td>ES0214973051</td>
            <td>ES0214973069</td>
            <td>ES0214973077</td>
            <td>ES0214974075</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>Spanish</td>
            <td>Spanish</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Not admissible</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Not admissible</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
            <td>Subordinated debt</td>
            <td>Perpetual subordinated debt</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>4.7</td>
            <td>39.9</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>75 Mill EUR</td>
            <td>50 Mill EUR</td>
            <td>100 Mill EUR</td>
            <td>35 Mill EUR</td>
            <td>75 Mill EUR</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>08/09/2006</td>
            <td>01/28/2005</td>
            <td>02/15/2007</td>
            <td>06/10/2009</td>
            <td>03/01/2007</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Perpetual</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>08/09/2021</td>
            <td>01/28/2020</td>
            <td>02/15/2017</td>
            <td>06/10/2024</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Issuer call date: 08/09/2016</td>
            <td>Issuer call date: 01/28/2015</td>
            <td>Issuer call date: 02/15/2012</td>
            <td>Issuer call date: 06/10/2019</td>
            <td>Issuer call date: 03/01/2027</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>Issuer call date and on each year thereafter</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
            <td>Issuer call date and on each interest payment day thereafter</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Fixed to floating (since *call date*)</td>
            <td>Floating</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>3M EURIBOR + 0.58%; 3M EURIBOR + 1.08% after issuer *call date*</td>
            <td>3M EURIBOR + 1.02% from 01/28/15</td>
            <td>3M EURIBOR + 0.44%</td>
            <td>7.50% up to 06/09/11; from 06/10/11 up to 06/09/19: 3M EURIBOR +5.25%; from 06/10/19 to 06/10/24: 3M EURIBOR +6%</td>
            <td>3M EURIBOR + 1.30% up to 03/01/2027; from 03/01/2027 3M EURIBOR + 2.80%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>Yes</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)
            </td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior to preferred shares, Additional Tier 1 instruments an Upper Tier 2 instruments (perpetual)</td>
            <td>Senior to preferred shares and Additional Tier 1 instruments </td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>Existence of step-up</td>
            <td>Existence of step-up</td>
            <td>N/A</td>
            <td>Existence of step-up</td>
            <td>Existence of step-up</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="7">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA BANCOMER SA</td>
            <td>BBVA BANCOMER SA</td>
            <td>BBVA BANCOMER SA</td>
            <td>BBVA BANCOMER SA</td>
            <td>BBVA BANCOMER SA</td>
            <td>BBVA BANCOMER SA</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>US05533UAB44</td>
            <td>US05533AAA07</td>
            <td>US05533UAC27</td>
            <td>US05533UAC27</td>
            <td>US055295AB54</td>
            <td>US05533UAE82</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 1 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 1 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>710.4</td>
            <td>426.3</td>
            <td>710.4</td>
            <td>355.2</td>
            <td>355.2</td>
            <td>142.1</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>1,250 Mill USD</td>
            <td>1,000 Mill USD</td>
            <td>1,000 Mill USD</td>
            <td>500 Mill USD</td>
            <td>500 Mill USD</td>
            <td>200 Mill USD</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>98.65%</td>
            <td>100.00%</td>
            <td>99.97%</td>
            <td>109.89%+accrued interest from July 19,2012 to Sep 28,2012</td>
            <td>100.00%</td>
            <td>99.79%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>03/10/2011</td>
            <td>04/22/2010</td>
            <td>07/19/2012</td>
            <td>09/28/2012</td>
            <td>05/17/2007</td>
            <td>11/12/2014</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>03/10/2021</td>
            <td>04/22/2020</td>
            <td>09/30/2022</td>
            <td>09/30/2022</td>
            <td>05/17/2022</td>
            <td>11/12/2029</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Solo also subject to both Regulatory and Tax call (en su totalidad)</td>
            <td>Solo also subject to both Regulatory and Tax call (en su totalidad)</td>
            <td>Solo also subject to both Regulatory and Tax call (en su totalidad)</td>
            <td>Solo also subject to both Regulatory and Tax call (en su totalidad)</td>
            <td>05/17/2017 in whole or in part, also subject to both Regulatory and Tax call (only in whole)</td>
            <td>11/12/2024 in whole or in part. (also subject to both Regulatory and Tax call, only in whole redemptiion)</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>On each interest payment date from the first call</td>
            <td>No</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>6.5%</td>
            <td>7.25%</td>
            <td>6.75%</td>
            <td>6.75%</td>
            <td>6.01%</td>
            <td>5.35%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Partially discretionary</td>
            <td>Partially discretionary</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Partially discretionary</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Partially discretionary</td>
            <td>Partially discretionary</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Partially discretionary</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Cumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>Yes, if a trigger event occurs </td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>A Trigger Event will be deemed to have occurred if: (i) the CNBV publishes a determination, in its official publication of capitalization levels for Mexican banks, that the Issuer’s Fundamental Capital is equal to or below 4.5%; (ii) both (A) the CNBV notifies the Issuer that it has made a decision, pursuant to Article 29 Bis of the Mexican Banking Law and other regulations (iii) the Banking Stability Committee determines that financial assistance is required by the Issuer to avoid revocation of the Issuer’s license for its failure to comply with corrective measures</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>Partially or fully</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
<td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Subordinated Preferred Indebtednessand (i) will rank junior to all present and future Senior Indebtedness, (ii) will rank paripassu with all other Subordinated Preferred Indebtedness, and (iii) will be senior to Subordinated Non-Preferred Indebtedness and all classes of capital stock.</td>
            <td>Constitute Subordinated Non-Preferred Indebtedness and will rank (1) junior to the Senior Indebtedness and Subordinated Preferred Indebtedness, (2) pari passu among themselves and with all the other Subordinated Non-Preferred Indebtedness, and (3) senior only to all classes of capital stock.</td>
            <td>The Notes constitute subordinated preferred indebtedness and (i) will rank junior to all present and future senior indebtedness, (ii) will rank pari passuwith all other present or future unsecured subordinated preferred indebtedness, and (iii) will be senior to unsecured subordinated non-preferred indebtedness and all classes of capital stock.</td>
<td>The Notes constitute subordinated preferred indebtedness and (i) will rank junior to all present and future senior indebtedness, (ii) will rank pari passuwith all other present or future unsecured subordinated preferred indebtedness, and (iii) will be senior to unsecured subordinated non-preferred indebtedness and all classes of capital stock.</td>
<td>
Constitute Subordinated Non-Preferred Indebtedness and will rank (1) junior to the Senior Indebtedness and Subordinated Preferred Indebtedness, (2) pari passu among themselves and with all the other Subordinated Non-Preferred Indebtedness, and (3) senior only to all classes of capital stock.</td>
<td>The Notes constitute Subordinated Preferred Indebtedness, and (i) will be subordinate and junior in right of payment and in liquidation to all of the present and future Senior Indebtedness, (ii) will rank pari passu without preference among themselves and with all of the present and future other unsecured subordinated preferred indebtedness and (iii) will be senior to subordinated non-preferredindebtedness and all classes of equity or capital stock.</td>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="10">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>Compass Bank</td>
            <td>Compass Bank</td>
            <td>Compass Bank</td>
            <td>Compass Bank</td>
            <td>Phoenix Loan Holdings REIT Pfd (Class B)</td>
            <td>TexasBanc Capital Trust I</td>
            <td>Texas Regional Statutory Trust I</td>
            <td>State National Capital Trust I</td>
            <td>State National Statutory Trust II</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>US20449EBT29</td>
            <td>US20449EEE23</td>
            <td>US20449EXN11</td>
            <td>US20453KAA34</td>
            <td>71909W201</td>
            <td>NA</td>
            <td>EI4269227</td>
            <td>EI4279275</td>
            <td>EI4274359</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
            <td>New York</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Nivel 1 (phase out up till 2018)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>128.9</td>
            <td>67.0</td>
            <td>-</td>
            <td>660.2</td>
            <td>19.8</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>300 Mill USD</td>
            <td>275 Mill USD</td>
            <td>350 Mill USD</td>
            <td>700 Mill USD</td>
            <td>21 Mill USD </td>
            <td>25 Mill USD </td>
            <td>50 Mill USD </td>
            <td>15 Mill USD </td>
            <td>10 Mill USD </td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>99.82%</td>
            <td>99.67%</td>
            <td>99.94%</td>
            <td>99.02%</td>
            <td>125.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Redemption price equal to 100% of the principal amount of the Notes to be redeemed, plus accrued interest on the Notes to the redemption date.</td>
            <td>100% of principal redeemed</td>
            <td>100% of principal redeemed</td>
            <td>100% of principal redeemed</td>
            <td>100% of principal redeemed</td>
            <td>100% of principal redeemed</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>03/21/2005</td>
            <td>03/16/2006</td>
            <td>09/19/2007</td>
            <td>04/10/2015</td>
            <td>11/28/2000</td>
            <td>07/23/2004</td>
            <td>02/24/2004</td>
            <td>07/14/2003</td>
            <td>03/17/2004</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Perpetual</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>04/01/2020</td>
            <td>04/01/2026</td>
            <td>10/01/2017</td>
            <td>04/10/04/2025</td>
            <td>N/A</td>
            <td>07/23/2034</td>
            <td>03/17/2034</td>
            <td>09/30/2033</td>
            <td>03/17/2034</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>No</td>
            <td>03/10/2025</td>
            <td>06/15/2021</td>
            <td>07/23/2009</td>
            <td>03/17/2009</td>
            <td>09/30/2008</td>
            <td>03/17/2009</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>No</td>
            <td>No</td>
            <td>N/A</td>
            <td>No</td>
            <td>At any time on or after the call date</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>At any time on or after the call date</td>
            <td>At any time on or after the call date</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>5.50%</td>
            <td>5.90%</td>
            <td>6.40%</td>
            <td>3.88%</td>
            <td>9.88%</td>
            <td>3mL+260pbs</td>
            <td>3mL+285pbs</td>
            <td>3mL+305pbs</td>
            <td>3mL+279pbs</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Discrecional</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Discrecional</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Noncumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
            <td>Cumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
            <td>Senior creditors</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)


<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="6">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>Bono Subordinado BBVA Chile</td>
            <td>Bono Subordinado BBVA Chile</td>
            <td>Bono Subordinado BBVA Chile</td>
            <td>Bono Subordinado BBVA Chile</td>
            <td>Bono Subordinado BBVA Chile</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>UBBV-A1203</td>
            <td>UBHIB70397</td>
            <td>UBHIB80397</td>
            <td>UBBV-G0506</td>
            <td>UBBVH90607</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Chile</td>
            <td>Chile</td>
            <td>Chile</td>
            <td>Chile</td>
            <td>Chile</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>190.7</td>
            <td>0.7</td>
            <td>0.7</td>
            <td>108.1</td>
            <td>254.2</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>6 Mill UF</td>
            <td>0,5 Mill UF</td>
            <td>0,5 Mill UF</td>
            <td>3,4 Mill UF</td>
            <td>8 Mill UF</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>103.61%</td>
            <td>99.52%</td>
            <td>99.47%</td>
            <td>109.51%</td>
            <td>93.02%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
            <td>100%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>04/01/2004</td>
            <td>03/01/1997</td>
            <td>03/01/1997</td>
            <td>10/19/2006</td>
            <td>06/01/2007</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>12/01/2027</td>
            <td>03/01/2018</td>
            <td>03/01/2018</td>
            <td>05/01/2031</td>
            <td>06/01/2032</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Fixed</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>6.00%</td>
            <td>6.50%</td>
            <td>6.50%</td>
            <td>5.00%</td>
            <td>3.50%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Convertible</td>
            <td>Convertible</td>
            <td>Convertible</td>
            <td>Convertible</td>
            <td>Convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>Effective assets 8%</td>
            <td>Effective assets 8%</td>
            <td>Effective assets 8%</td>
            <td>Effective assets 8%</td>
            <td>Effective assets 8%</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>Always Fully</td>
            <td>Always Fully</td>
            <td>Always Fully</td>
            <td>Always Fully</td>
            <td>Always Fully</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>1 to 1</td>
            <td>1 to 1</td>
            <td>1 to 1</td>
            <td>1 to 1</td>
            <td>1 to 1</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
            <td>Tier 1</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>BBVA Chile</td>
            <td>BBVA Chile</td>
            <td>BBVA Chile</td>
            <td>BBVA Chile</td>
            <td>BBVA Chile</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Senior Bonds</td>
            <td>Senior Bonds</td>
            <td>Senior Bonds</td>
            <td>Senior Bonds</td>
            <td>Senior Bonds</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="6">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA Colombia SA</td>
            <td>BBVA Colombia SA</td>
            <td>BBVA Colombia SA</td>
            <td>BBVA Colombia SA</td>
            <td>BBVA Colombia SA</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>BBVAIP190918</td>
            <td>BBVAIP190921</td>
            <td>BBVAIP190926</td>
            <td>BBVAIP190223</td>
            <td>BBVAIP190228</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Colombian</td>
            <td>Colombian</td>
            <td>Colombian</td>
            <td>Colombian</td>
            <td>Colombian</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>6.3</td>
            <td>26.1</td>
            <td>47.9</td>
            <td>61.5</td>
            <td>50.7</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>102,000 Mill COP</td>
            <td>106,000 Mill COP</td>
            <td>156,000 Mill COP</td>
            <td>200,000 Mill COP</td>
            <td>165,000 Mill COP</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>Bullet Bonds; 100%</td>
            <td>Bullet Bonds; 100%</td>
            <td>Bullet Bonds; 100%</td>
            <td>Bullet Bonds; 100%</td>
            <td>Bullet Bonds; 100%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>09/19/2011</td>
            <td>09/19/2011</td>
            <td>09/19/2011</td>
            <td>02/19/2013</td>
            <td>02/19/2013</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>09/19/2018</td>
            <td>09/19/2021</td>
            <td>09/19/2026</td>
            <td>02/19/2023</td>
            <td>02/19/2028</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>IPC + 4.28%</td>
            <td>IPC + 4.45%</td>
            <td>IPC + 4.70%</td>
            <td>IPC + 3.60%</td>
            <td>IPC + 3.89%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)


<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="6">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA Colombia SA</td>
            <td>BBVA Colombia SA</td>
            <td>BBVA Colombia SA</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>EK6295332</td>
            <td>COB13CBB0088</td>
            <td>USP1024TAN92</td>
            <td>BID Subordinado</td>
            <td>PEP11600D011</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Colombian</td>
            <td>Colombian</td>
            <td>Colombian</td>
            <td>New York</td>
            <td>Peruvian</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>49.2</td>
            <td>27.7</td>
            <td>369.1</td>
            <td>-</td>
            <td>11.3</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>160,000 Mill COP</td>
            <td>90,000 Mill COP</td>
            <td>400 Mill USD</td>
            <td>30 Mill USD </td>
            <td>40 Mill PEN </td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>99.91%</td>
            <td>100.00%</td>
            <td>99.25%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>Bullet Bonds; 100%</td>
            <td>Bullet Bonds; 100%</td>
            <td>1</td>
            <td>With the prior Authorization of the Peruvian Banking Regulatory Authority and pursuant to the Applicable Laws of Peru, with prepayment fee in each case in an amount equal to one and one-half percent (1.5%) of any and all amounts prepaid on the Loan;</td>
            <td>There is redemption option with additional paid 0%.</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>11/26/2014</td>
            <td>11/26/2014</td>
            <td>04/21/2015</td>
            <td>12/22/2006</td>
            <td>05/07/2007</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>11/26/2034</td>
            <td>11/26/2029</td>
            <td>04/21/2025</td>
            <td>02/15/2017</td>
            <td>05/07/2022</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>04/21/2020; Tax call</td>
            <td>Issuer call date: 02/15/2012, also subject to Regulatory call.</td>
            <td>Issuer call date: 05/07/2017, also subject to Regulatory call.</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>At any time on or after 04/21/2020</td>
            <td>At any time on or after the call date</td>
            <td>At any time on or after the call date</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Fixed</td>
            <td>Floating</td>
            <td>Fixed</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>IPC + 4.38%</td>
            <td>IPC + 4.50%</td>
            <td>4.88%</td>
            <td>LIBOR6M + 1.25% (increase of additional 1.25% from call date)</td>
            <td>5.85% (up to 20th coupon ) - (increase of 0.5% annually from the 21st coupon- call date)</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>Noncumulative</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>Non-convertible</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>NO</td>
            <td>NO</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
            <td>Subordinated liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>Subsidiary issuance not subject by UE CRD-IV</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="6">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>PEP11600D029</td>
            <td>PEP11600D037</td>
            <td>PEP11600D045</td>
            <td>PEP11600D052</td>
            <td>PEP11600D060</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Not admissible</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>19.0</td>
            <td>15.6</td>
            <td>-</td>
            <td>14.2</td>
            <td>19.0</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>20 Mill USD </td>
            <td>55 Mill PEN</td>
            <td>20 Mill USD</td>
            <td>50 Mill PEN</td>
            <td>20 Mill USD </td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>99.38%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>There is redemption option with additional paid 0%.</td>
            <td>No redemption option</td>
            <td>There is redemption option with additional paid 0%.</td>
            <td>No redemption option</td>
            <td>No redemption option</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>05/14/2007</td>
            <td>06/18/2007</td>
            <td>09/24/2007</td>
            <td>11/19/2007</td>
            <td>02/28/2008</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>05/14/2027</td>
            <td>06/18/2032</td>
            <td>09/24/2017</td>
            <td>11/19/2032</td>
            <td>02/28/2028</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>No</td>
            <td>Yes</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Issuer call date: 05/14/2022, also subject to Regulatory call.</td>
            <td>Subject to Regulatory call.</td>
            <td>Issuer call date: 09/24/2012, also subject to Regulatory call.</td>
            <td>Subject to Regulatory call.</td>
            <td>Subject to Regulatory call.</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>At any time on or after the call date</td>
            <td>N/A</td>
            <td>At any time on or after the call date</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Fixed</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>6% (up to 30th coupon) - (increase of 0.5% annually after 31st coupon- call date)</td>
            <td>VAC(semester)/VAC(initial)*3.4688%</td>
            <td>LIBOR(6M)+2.15625% (up to 10th coupon) - (increase of 1% from 11th coupon- call date)</td>
            <td>VAC(semester)/VAC(initial)*3.5625%</td>
            <td>6.47%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>Yes</td>
            <td>No</td>
            <td>Yes</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>Subsidiary issuance not subject by UE CRD-IV</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="6">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
            <td>BBVA Continental</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>PEP11600D078</td>
            <td>PEP11600D086</td>
            <td>PEP11600D094</td>
            <td>Credit Suisse TIER 1</td>
            <td>PEP11600D102</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
            <td>Peruvian</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>12.7</td>
            <td>14.2</td>
            <td>8.5</td>
            <td>189.7</td>
            <td>42.7</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>45 Mill PEN</td>
            <td>50 Mill PEN</td>
            <td>30 Mill PEN</td>
            <td>200 Mill USD</td>
            <td>45 Mill USD</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>No redemption option</td>
            <td>No redemption option</td>
            <td>No redemption option</td>
            <td>There is redemption option with additional paid 0%.</td>
            <td>There is redemption option with additional paid 0%.</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>07/08/2008</td>
            <td>09/09/2008</td>
            <td>12/15/2008</td>
            <td>10/07/2010</td>
            <td>10/02/2013</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>07/08/2023</td>
            <td>09/09/2023</td>
            <td>12/15/2033</td>
            <td>10/07/2040</td>
            <td>10/02/2028</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>Yes</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Subject to Regulatory call.</td>
            <td>Subject to Regulatory call.</td>
            <td>Subject to Regulatory call.</td>
            <td>Issuer call date: 10/07/2020, also subject to Regulatory call.</td>
            <td>Issuer call date: 10/02/2023, also subject to Regulatory call.</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>At any time on or after the call date</td>
            <td>At any time on or after the call date</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Floating</td>
            <td>Fixed to Floating</td>
            <td>Fixed</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>VAC(semester)/VAC(initial)*3.0625%</td>
            <td>VAC(semester)/VAC(initial)*3.0938%</td>
            <td>VAC(semester)/VAC(initial)*4.1875%</td>
            <td>7.375% (10 years), L3M + 6.802% (following 10 years)</td>
            <td>6.53%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>N/A</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>Yes</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>Noncumulative</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
            <td>NO</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="5">Capital instruments main features template</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1. Issuer</td>
            <td>BBVA Continental</td>
            <td>Banco Bilbao Vizcaya Argentaria Paraguay S.A.</td>
            <td>BBVA URUGUAY SA</td>
            <td>Banco Bilbao Vizcaya Argentaria Paraguay S.A.</td>
        </tr>
        <tr>
            <td>2, Identificador único (por ejemplo ISIN</td>
            <td>US05537GAD79-USP16236AG98</td>
            <td>PYBBV01F3798</td>
            <td>N/A</td>
            <td>PYBBV02F5511</td>
        </tr>
        <tr>
            <td>3. Governing law(s) of the instrument</td>
            <td>New York</td>
            <td>Paraguay</td>
            <td>Uruguay</td>
            <td>Paraguay</td>
        </tr>
        <tr>
            <td>*Regulatory treatment*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>4. Transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>5. Post-transitional CRR rules</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
            <td>Tier 2</td>
        </tr>
        <tr>
            <td>6. Eligible at solo/(sub-)consolidated/solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
            <td>At solo & (sub-)consolidated</td>
        </tr>
        <tr>
            <td>7. Instrument type (types to be specified by each jurisdiction)</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
            <td>Tier 2 instrument</td>
        </tr>
        <tr>
            <td>8. Amount recognised in regulatory capital (currency in million, as of most recent reporting date)</td>
            <td>284.6</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>9. Nominal amount of instrument</td>
            <td>300 Mill USD</td>
            <td>20 Mill USD</td>
            <td>15 Mill USD</td>
            <td>25 Mill USD</td>
        </tr>
        <tr>
            <td>9.a Issue price</td>
            <td>99.32%</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>9.b Redemption price</td>
            <td>BBVA may, with the prior approval of the SBS, redeem the Notes, in whole or in part, on the Reset Date, at a redemption price equal to 100% of the principal amount of the Notes being redeemed plus any accrued and unpaid interest on the principal amount of the Notes.</td>
            <td>100.00%</td>
            <td>100.00%</td>
            <td>100.00%</td>
        </tr>
        <tr>
            <td>10. Accounting classification</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
            <td>Liability – amortised cost</td>
        </tr>
        <tr>
            <td>11. Original date of issuance</td>
            <td>09/22/2014</td>
            <td>11/19/2014</td>
            <td>12/19/2014</td>
            <td>11/24/2015</td>
        </tr>
        <tr>
            <td>12. Perpeptual or dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
            <td>Dated</td>
        </tr>
        <tr>
            <td>13. Original maturity date</td>
            <td>09/22/2029</td>
            <td>05/11/2021</td>
            <td>12/19/2024</td>
            <td>11/18/2022</td>
        </tr>
        <tr>
            <td>14. Issuer call subjet to prior supervisory approval</td>
            <td>Yes</td>
            <td>N/A</td>
            <td>Yes</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>15. Optional call date, contingent call dates, and redemption amount</td>
            <td>Issuer call date: 09/22/2024, also subject to Regulatory call.</td>
            <td>N/A</td>
            <td>At issuer's discretion after 5 years from issue date, minimum USD 1MM</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>16. Subsequent call dates, if applicable</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>At issuer's discretion after 5 years from issue date, minimum USD 1MM</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>*Coupons / dividends*</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>17. Fixed or floating dividend/coupon</td>
            <td>Fixed</td>
            <td>Fixed</td>
            <td>Floating</td>
            <td>Fixed</td>
        </tr>
        <tr>
            <td>18. Coupon rate and any related index</td>
            <td>5.25%</td>
            <td>6.75%</td>
            <td>LIBOR 90d + 4.35%</td>
            <td>6.70%</td>
        </tr>
        <tr>
            <td>19. Existence of a dividend stopper</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>20.a Fully discretionary, partially discretionary or mandatory (in terms of timing</td>
            <td>N/A</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>20.b Fully discretionary, partially discretionary or mandatory (in terms of amount)</td>
            <td>N/A</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>21. Existence of step up or other incentive to redeem</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>22. Noncumulative or cumulative</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
            <td>NA</td>
        </tr>
        <tr>
            <td>23. Convertible or non-convertible</td>
            <td>N/A</td>
            <td>Convertible</td>
            <td>Non-convertible</td>
            <td>Convertible</td>
        </tr>
        <tr>
            <td>24. If convertible, conversion trigger (s)</td>
            <td>N/A</td>
            <td>TIER 1 <8% o TIER 2 <12% or Accumulated losses > Paid-in Capital</td>
            <td>N/A</td>
            <td>TIER 1 <8% o TIER 2 <12% or Accumulated losses > Paid-in Capital</td>
        </tr>
        <tr>
            <td>25. If convertible, fully or partially</td>
            <td>N/A</td>
            <td>Partially</td>
            <td>N/A</td>
            <td>Partially</td>
        </tr>
        <tr>
            <td>26. If convertible, conversion rate</td>
            <td>N/A</td>
            <td>100%</td>
            <td>N/A</td>
            <td>1</td>
        </tr>
        <tr>
            <td>27. If convertible, mandatory or optional conversion</td>
            <td>N/A</td>
            <td>Mandatory</td>
            <td>N/A</td>
            <td>Mandatory</td>
        </tr>
        <tr>
            <td>28. If convertible, specifiy instrument type convertible into</td>
            <td>N/A</td>
            <td>Tier 1</td>
            <td>N/A</td>
            <td>Tier 1</td>
        </tr>
        <tr>
            <td>29. If convertible, specifiy issuer of instrument it converts into</td>
            <td>N/A</td>
            <td>Banco Bilbao Vizcaya Argentaria Paraguay S.A.</td>
            <td>N/A</td>
            <td>Banco Bilbao Vizcaya Argentaria Paraguay S.A.</td>
        </tr>
        <tr>
            <td>30. Write-down features</td>
            <td>NO</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>31. If write-down, write-down trigger (s)</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>32. If write-down, full or partial</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>33. If write-down, permanent or temporary</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>34. If temporary write-down, description of write-up mechanism</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
        <tr>
            <td>35. Position in subordination hierachy in liquidation (specify instrument type immediately senior to instrument)</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
            <td>Senior liabilities other than parity securities rank immediately senior</td>
        </tr>
        <tr>
            <td>36. Non-compliant transitioned features</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
            <td>No</td>
        </tr>
        <tr>
            <td>37. If yes, specifiy non-compliant features</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
            <td>N/A</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<ul class="cita"><li>(4) Corresponds to the classification of the instrument from a regulatory or phased-in view as of December 31, 2016</li>

<li>(5) Corresponds to the classification of the instrument from a fully loaded view as of December 31, 2016</li></ul>

## Annex VII: Leverage ratio disclosure template

<table class="l">
    <thead>
       <tr class="m">
            <th colspan="6">Millions of euros</th>
        </tr>
        <tr class="tableizer-firstrow">
            <th colspan="2">Table disclosure of the leverage ratio</th>
            <th>12/31/2016 Phase-in</th>
            <th>12/31/2016 Fully-loaded</th>
            <th>12/31/2015 Phase-in</th>
            <th>12/31/2015 Fully-loaded</th>
        </tr>
    </thead>
    <tbody>
        <tr class="b2">
            <td colspan="6">On-balance sheet exposures (excluding derivatives and SFTs)</td>
        </tr>
        <tr>
            <td>1</td>
            <td>On-balance sheet items (excluding derivatives, SFTs and fiduciary assets, but including collateral)</td>
            <td>641,525</td>
            <td>641,525</td>
            <td>669,866</td>
            <td>669,866</td>
        </tr>
        <tr>
            <td>2</td>
            <td>(Asset amounts deducted in determining Tier 1 capital)</td>
            <td>(10,451)</td>
            <td>(10,961)</td>
            <td>(12,159)</td>
            <td>(12,746)</td>
        </tr>
        <tr class="b2">
            <td>3</td>
            <td>Total on-balance sheet exposures (excluding derivatives, SFTs and fiduciary assets) (sum of lines 1 and 2)</td>
            <td>631,074</td>
            <td>630,564</td>
            <td>657,707</td>
            <td>657,120</td>
        </tr>
        <tr class="b">
            <td colspan="6">Derivative exposures</td>
        </tr>
        <tr>
            <td>4</td>
            <td>Replacement cost associated with all derivatives transactions (ie net of eligible cash variation margin)</td>
            <td>13,487</td>
            <td>13,487</td>
            <td>11,030</td>
            <td>11,030</td>
        </tr>
        <tr>
            <td>5</td>
            <td>Add-on amounts for PFE associated with all derivatives transactions (mark-to-market method)</td>
            <td>15,629</td>
            <td>15,629</td>
            <td>14,523</td>
            <td>14,523</td>
        </tr>
        <tr>
            <td>EU-5a</td>
            <td>Exposure determined under Original Exposure Method</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>6</td>
            <td>Gross-up for derivatives collateral provided where deducted from the balance sheet assets pursuant to the applicable accounting framework</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>7</td>
            <td>(Deductions of receivables assets for cash variation margin provided in derivatives transactions)</td>
            <td>(4,822)</td>
            <td>(4,822)</td>
            <td>(6,097)</td>
            <td>(6,097)</td>
        </tr>
        <tr>
            <td>8</td>
            <td>(Exempted CCP leg of client-cleared trade exposures)</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>9</td>
            <td>Adjusted effective notional amount of written credit derivatives</td>
            <td>10,074</td>
            <td>10,074</td>
            <td>17,362</td>
            <td>17,362</td>
        </tr>
        <tr>
            <td>10</td>
            <td>(Adjusted effective notional offsets and add-on deductions for written credit derivatives)</td>
            <td>(5,143)</td>
            <td>(5,143)</td>
            <td>(13,199)</td>
            <td>(13,199)</td>
        </tr>
        <tr class="b2">
            <td>11</td>
            <td>Total derivative exposures (sum of lines 4 to 10)</td>
            <td>29,225</td>
            <td>29,225</td>
            <td>23,619</td>
            <td>23,619</td>
        </tr>
        <tr class="b">
            <td colspan="6">Securities financing transaction exposures</td>
        </tr>
        <tr>
            <td>12</td>
            <td>Gross SFT assets (with no recognition of netting), after adjusting for sales accounting transactions</td>
            <td>27,879</td>
            <td>27,879</td>
            <td>16,616</td>
            <td>16,616</td>
        </tr>
        <tr>
            <td>13</td>
            <td>(Netted amounts of cash payables and cash receivables of gross SFT assets)</td>
            <td>(10,300)</td>
            <td>(10,300)</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>14</td>
            <td>Counterparty credit risk exposure for SFT assets</td>
            <td>2,941</td>
            <td>2,941</td>
            <td>37</td>
            <td>37</td>
        </tr>
        <tr>
            <td>EU-14a</td>
            <td>Derogation for SFTs: Counterparty credit risk exposure in accordance with Article 429b (4) and 222 of Regulation (EU) No 575/2013</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>15</td>
            <td>Agent transaction exposures</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>EU-15A</td>
            <td>(Exempted CCP leg of client-cleared SFT exposure)</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr class="b2">
            <td>16</td>
            <td>Total securities financing transaction exposures (sum of lines 12 to 15a)</td>
            <td>20,520</td>
            <td>20,520</td>
            <td>16,654</td>
            <td>16,654</td>
        </tr>
        <tr class="b">
            <td colspan="6">Other off-balance sheet exposures</td>
        </tr>
        <tr>
            <td>17</td>
            <td>Off-balance sheet exposures at gross notional amount</td>
            <td>164,136</td>
            <td>164,136</td>
            <td>185,864</td>
            <td>185,864</td>
        </tr>
        <tr>
            <td>18</td>
            <td>(Adjustments for conversion to credit equivalent amounts)</td>
            <td>(97,740)</td>
            <td>(97,740)</td>
            <td>(117,255)</td>
            <td>(117,255)</td>
        </tr>
        <tr class="b2">
            <td>19</td>
            <td>Other off-balance sheet exposures (sum of lines 17 to 18)</td>
            <td>66,397</td>
            <td>66,397</td>
            <td>68,609</td>
            <td>68,609</td>
        </tr>
        <tr class="b">
            <td colspan="6">Exempted exposures in accordance with CRR Article 429 (7) and (14) (on and off balance sheet)</td>
        </tr>
        <tr>
            <td>EU-19a</td>
            <td>(Exemption of intragroup exposures (solo basis) in accordance with Article 429(7) of Regulation (EU) No 575/2013 (on and off balance sheet))</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr>
            <td>EU-19b</td>
            <td>(Exposures exempted in accordance with Article 429 (14) of Regulation (EU) No 575/2013 (on and off balance sheet))</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <tr class="b">
            <td colspan="6">Capital and total exposures</td>
        </tr>
        <tr>
            <td>20</td>
            <td>Tier 1 capital</td>
            <td>50,083</td>
            <td>48,459</td>
            <td>48,554</td>
            <td>45,796</td>
        </tr>
        <tr class="b2">
            <td>21</td>
            <td>Total leverage ratio exposures (sum of lines 3, 11, 16, 19, EU-19a and EU-19b)</td>
            <td>747,216</td>
            <td>746,706</td>
            <td>766,589</td>
            <td>766,001</td>
        </tr>
        <tr class="b">
            <td colspan="6">Leverage ratio</td>
        </tr>
        <tr class="b2">
            <td>22</td>
            <td>Leverage ratio</td>
            <td>6.70%</td>
            <td>6.49%</td>
            <td>6.33%</td>
            <td>5.98%</td>
        </tr>
        <tr>
            <td colspan="6">Choice on transitional arrangements and amount of derecognised fiduciary items</td>
        </tr>
        <tr>
            <td>EU-23</td>
            <td>Choice on transitional arrangements for the definition of the capital measure</td>
            <td>Transitional</td>
            <td>Fully phased in</td>
            <td>Transitional</td>
            <td>Fully phased in</td>
        </tr>
        <tr>
            <td>EU-24</td>
            <td>Amount of derecognised fiduciary items in accordance with Article 429(11) of Regulation (EU) NO 575/2013</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
    </tbody>
</table>
[Download table](#)

<table class="l">
    <thead>
        <tr class="tableizer-firstrow">
            <th colspan="2">Table LRSpl: Split-up of on balance sheet exposures (excluding derivatives, SFTs and exempted exposures)</th>
            <th>12/31/2016 Phase-in</th>
            <th>12/31/2016 Fully-loaded</th>
            <th>12/31/2015 Phase-in</th>
            <th>12/31/2015 Fully-loaded</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>EU-1</td>
            <td>Total on-balance sheet exposures (excluding derivatives, SFTs, and exempted exposures), of which:</td>
            <td>641,525</td>
            <td>641,525</td>
            <td>669,866</td>
            <td>669,866</td>
        </tr>
        <tr>
            <td>EU-2</td>
            <td>Trading book exposures</td>
            <td>91,030</td>
            <td>91,030</td>
            <td>61,886</td>
            <td>61,886</td>
        </tr>
        <tr>
            <td>EU-3</td>
            <td>Banking book exposures, of which:</td>
            <td>550,495</td>
            <td>550,495</td>
            <td>607,980</td>
            <td>607,980</td>
        </tr>
        <tr>
            <td>EU-4</td>
            <td>Covered bonds</td>
            <td>177</td>
            <td>177</td>
            <td>839,482</td>
            <td>839,482</td>
        </tr>
        <tr>
            <td>EU-5</td>
            <td>Exposures treated as sovereigns</td>
            <td>108,332</td>
            <td>108,332</td>
            <td>143,049</td>
            <td>143,049</td>
        </tr>
        <tr>
            <td>EU-6</td>
            <td>Exposures to regional governments, MDB, international organisations and PSE NOT treated as sovereigns</td>
            <td>9,993</td>
            <td>9,993</td>
            <td>2,501</td>
            <td>2,501</td>
        </tr>
        <tr>
            <td>EU-7</td>
            <td>Institutions</td>
            <td>26,786</td>
            <td>26,786</td>
            <td>44,368</td>
            <td>44,368</td>
        </tr>
        <tr>
            <td>EU-8</td>
            <td>Secured by mortgages of immovable properties</td>
            <td>134,063</td>
            <td>134,063</td>
            <td>138,222</td>
            <td>138,222</td>
        </tr>
        <tr>
            <td>EU-9</td>
            <td>Retail exposures</td>
            <td>72,635</td>
            <td>72,635</td>
            <td>63,514</td>
            <td>63,514</td>
        </tr>
        <tr>
            <td>EU-10</td>
            <td>Corporate</td>
            <td>147,336</td>
            <td>147,336</td>
            <td>151,965</td>
            <td>151,965</td>
        </tr>
        <tr>
            <td>EU-11</td>
            <td>Exposures in default</td>
            <td>12,704</td>
            <td>12,704</td>
            <td>19,574</td>
            <td>19,574</td>
        </tr>
        <tr>
            <td>EU-12</td>
            <td>Other exposures (eg equity, securitisations, and other non-credit obligation assets)</td>
            <td>38,468</td>
            <td>38,468</td>
            <td>43,948</td>
            <td>43,948</td>
        </tr>
    </tbody>
</table>
[Download table](#)

{% include download.html %}
