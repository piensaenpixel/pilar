---
layout: default
title: Resumen ejecutivo
lang: en
permalink: /resumen-ejecutivo/
submenu: resumen
---

Resumen ejecutivo